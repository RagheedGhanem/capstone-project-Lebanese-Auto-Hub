import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "email",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("Car Detail View", () => {
  it("should retrieve car by ID", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Create a test car first
    const createdCar = await caller.cars.create({
      brand: "Toyota",
      model: "Camry",
      carType: "sedan",
      year: 2022,
      color: "blue",
      price: 25000,
      kilometers: 15000,
      condition: "excellent",
      description: "Well-maintained Toyota Camry",
    });

    // Retrieve the car by ID
    const car = await caller.cars.getById({ id: createdCar.carId });

    expect(car).toBeDefined();
    expect(car?.brand).toBe("Toyota");
    expect(car?.model).toBe("Camry");
    expect(car?.year).toBe(2022);
    expect(car?.price).toBe("25000.00");
  });

  it("should return undefined for non-existent car", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const car = await caller.cars.getById({ id: 99999 });

    expect(car).toBeUndefined();
  });

  it("should create inquiry from car detail page", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Create a test car
    const createdCar = await caller.cars.create({
      brand: "Honda",
      model: "Civic",
      carType: "sedan",
      year: 2021,
      color: "red",
      price: 20000,
      kilometers: 25000,
      condition: "good",
      description: "Reliable Honda Civic",
    });

    // Create inquiry for the car
    const inquiryResult = await caller.inquiries.create({
      name: "John Buyer",
      email: "buyer@example.com",
      phone: "+961-1-234567",
      brand: "Honda",
      model: "Civic",
      carType: "sedan",
      year: 2021,
      color: "red",
      additionalNotes: "Interested in this car. Can you provide more details?",
    });

    expect(inquiryResult).toBeDefined();
    expect(inquiryResult).toHaveProperty("inquiryId");
  });

  it("should validate inquiry contact information", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Try to create inquiry with invalid email
    try {
      await caller.inquiries.create({
        name: "John Buyer",
        email: "invalid-email",
        phone: "+961-1-234567",
        brand: "Toyota",
        model: "Camry",
        additionalNotes: "Test",
      });
      expect.fail("Should have thrown validation error");
    } catch (error: any) {
      expect(error.message).toContain("email");
    }
  });

  it("should retrieve all cars with filters", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Create multiple cars
    await caller.cars.create({
      brand: "Toyota",
      model: "Camry",
      carType: "sedan",
      year: 2022,
      color: "blue",
      price: 25000,
    });

    await caller.cars.create({
      brand: "Honda",
      model: "Civic",
      carType: "sedan",
      year: 2021,
      color: "red",
      price: 20000,
    });

    await caller.cars.create({
      brand: "Toyota",
      model: "RAV4",
      carType: "suv",
      year: 2023,
      color: "black",
      price: 35000,
    });

    // List all cars
    const allCars = await caller.cars.list({});
    expect(allCars.length).toBeGreaterThanOrEqual(3);

    // Filter by brand
    const toyotas = await caller.cars.list({ brand: "Toyota" });
    expect(toyotas.every((car) => car.brand === "Toyota")).toBe(true);

    // Filter by type
    const sedans = await caller.cars.list({ carType: "sedan" });
    expect(sedans.every((car) => car.carType === "sedan")).toBe(true);
  });

  it("should handle inquiry with optional fields", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const inquiryId = await caller.inquiries.create({
      name: "Jane Buyer",
      email: "jane@example.com",
      // phone is optional
      brand: "BMW",
      model: "X5",
      // carType, year, color, minPrice, maxPrice are optional
      additionalNotes: "Looking for a luxury SUV",
    });

    expect(inquiryId).toBeDefined();
    expect(inquiryId).toHaveProperty("inquiryId");
  });
});
