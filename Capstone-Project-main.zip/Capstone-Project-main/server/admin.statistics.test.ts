import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { createCaller } from "./routers";
import * as db from "./db";

describe("Admin Statistics", () => {
  let adminUser: any;
  let regularUser: any;

  beforeAll(async () => {
    // Create test users
    adminUser = {
      id: 999,
      openId: "test-admin-999",
      name: "Test Admin",
      email: "admin@test.com",
      passwordHash: null,
      loginMethod: "google",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    };

    regularUser = {
      id: 998,
      openId: "test-user-998",
      name: "Test User",
      email: "user@test.com",
      passwordHash: null,
      loginMethod: "google",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    };
  });

  it("should return statistics with correct counts", async () => {
    const caller = createCaller({
      user: adminUser,
      req: {} as any,
      res: {} as any,
    });

    const stats = await caller.admin.getStatistics();

    expect(stats).toBeDefined();
    expect(stats.totalUsers).toBeGreaterThanOrEqual(0);
    expect(stats.activeListings).toBeGreaterThanOrEqual(0);
    expect(stats.adminCount).toBeGreaterThanOrEqual(1);
    expect(typeof stats.totalUsers).toBe("number");
    expect(typeof stats.activeListings).toBe("number");
    expect(typeof stats.adminCount).toBe("number");
  });

  it("should throw error if non-admin tries to access statistics", async () => {
    const caller = createCaller({
      user: regularUser,
      req: {} as any,
      res: {} as any,
    });

    try {
      await caller.admin.getStatistics();
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.message).toContain("Unauthorized");
    }
  });

  it("should throw error if unauthenticated user tries to access statistics", async () => {
    const caller = createCaller({
      user: null,
      req: {} as any,
      res: {} as any,
    });

    try {
      await caller.admin.getStatistics();
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.message).toContain("Unauthorized");
    }
  });

  it("should return statistics with adminCount matching actual admin count", async () => {
    const caller = createCaller({
      user: adminUser,
      req: {} as any,
      res: {} as any,
    });

    const stats = await caller.admin.getStatistics();
    const allUsers = await db.getAllUsers();
    const actualAdminCount = allUsers.filter(u => u.role === "admin").length;

    expect(stats.adminCount).toBe(actualAdminCount);
  });

  it("should return statistics with activeListings matching actual listings count", async () => {
    const caller = createCaller({
      user: adminUser,
      req: {} as any,
      res: {} as any,
    });

    const stats = await caller.admin.getStatistics();
    const allListings = await db.getAllCars();

    expect(stats.activeListings).toBe(allListings.length);
  });

  it("should return statistics with totalUsers matching actual users count", async () => {
    const caller = createCaller({
      user: adminUser,
      req: {} as any,
      res: {} as any,
    });

    const stats = await caller.admin.getStatistics();
    const allUsers = await db.getAllUsers();

    expect(stats.totalUsers).toBe(allUsers.length);
  });
});
