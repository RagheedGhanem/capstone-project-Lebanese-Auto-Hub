import { getDb } from "./db";
import { cars } from "../drizzle/schema";

async function testQuery() {
  const db = await getDb();
  if (!db) {
    console.log("Database not available");
    return;
  }

  try {
    const result = await db.select().from(cars).limit(15);
    console.log("=== Cars in Database ===");
    console.log(`Total cars found: ${result.length}\n`);
    
    result.forEach((car: any, i: number) => {
      console.log(`${i+1}. ${car.year} ${car.brand} ${car.model}`);
      console.log(`   Type: ${car.carType}, Status: ${car.status}`);
      console.log(`   Price: $${car.price}, Mileage: ${car.kilometers}km`);
      console.log(`   Transmission: ${car.transmission}, Fuel: ${car.fuelType}`);
      console.log(`   Color: ${car.color}, Seller: ${car.sellerName} (${car.sellerLocation})`);
      console.log("");
    });
  } catch (e: any) {
    console.error("Error querying database:", e.message);
  }
}

testQuery();
