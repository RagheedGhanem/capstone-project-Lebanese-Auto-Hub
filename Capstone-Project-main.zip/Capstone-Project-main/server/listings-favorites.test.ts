import { describe, it, expect, beforeAll, afterAll, vi } from "vitest";
import * as db from "./db";
import { getDb } from "./db";

describe("My Listings and Favorites Features", () => {
  let testUserId: number;
  let testCarId: number;
  let testCarId2: number;

  beforeAll(async () => {
    // Create test users
    await db.upsertUser({
      email: "listings-test@example.com",
      name: "Test User",
      loginMethod: "manual",
    });

    const testUser = await db.getUserByEmail("listings-test@example.com");
    testUserId = testUser?.id || 0;

    // Create test cars
    const carIdResult = await db.createCar({
      userId: testUserId,
      brand: "Toyota",
      model: "Camry",
      carType: "Sedan",
      year: 2022,
      color: "Blue",
      price: "25000",
      transmission: "Automatic",
      fuelType: "Gasoline",
      engineSize: "2.5L",
      description: "Well-maintained sedan",
      sellerName: "Test Seller",
      sellerPhone: "+961123456",
      sellerEmail: "seller@example.com",
      sellerLocation: "Beirut",
    });

    testCarId = carIdResult || 0;

    const carIdResult2 = await db.createCar({
      userId: testUserId,
      brand: "Honda",
      model: "Civic",
      carType: "Sedan",
      year: 2021,
      color: "Red",
      price: "22000",
      transmission: "Manual",
      fuelType: "Gasoline",
      engineSize: "1.8L",
      description: "Reliable sedan",
      sellerName: "Test Seller",
      sellerPhone: "+961123456",
      sellerEmail: "seller@example.com",
      sellerLocation: "Beirut",
    });

    testCarId2 = carIdResult2 || 0;
  });

  describe("My Listings", () => {
    it("should fetch user's listings", async () => {
      const listings = await db.getMyListings(testUserId);
      expect(listings).toBeInstanceOf(Array);
      expect(listings.length).toBeGreaterThanOrEqual(2);
      expect(listings.some((car: any) => car.id === testCarId)).toBe(true);
      expect(listings.some((car: any) => car.id === testCarId2)).toBe(true);
    });

    it("should update a listing", async () => {
      const updates = {
        price: "26000",
        color: "Silver",
        description: "Updated description",
      };

      const updated = await db.updateMyListing(testCarId, testUserId, updates);
      expect(updated).toBeDefined();
      expect(updated?.price).toMatch(/26000/);
      expect(updated?.color).toBe("Silver");
      expect(updated?.description).toBe("Updated description");
    });

    it("should prevent unauthorized users from updating listings", async () => {
      const otherUserId = testUserId + 999;
      const updates = { price: "30000" };

      await expect(
        db.updateMyListing(testCarId, otherUserId, updates)
      ).rejects.toThrow("Unauthorized");
    });

    it("should delete a listing", async () => {
      // Just verify the delete function works without errors
      // (actual deletion is tested in integration tests)
      const result = await db.deleteMyListing(testCarId2, testUserId);
      expect(result).toBe(true);
    });

    it("should prevent unauthorized users from deleting listings", async () => {
      const otherUserId = testUserId + 999;

      await expect(
        db.deleteMyListing(testCarId2, otherUserId)
      ).rejects.toThrow("Unauthorized");
    });
  });

  describe("My Favorites", () => {
    it("should add a car to favorites", async () => {
      await db.addFavorite(testUserId, testCarId);
      const isFavorited = await db.isFavorited(testUserId, testCarId);
      expect(isFavorited).toBe(true);
    });

    it("should not add duplicate favorites", async () => {
      // Try to add the same favorite again
      await db.addFavorite(testUserId, testCarId);
      const isFavorited = await db.isFavorited(testUserId, testCarId);
      expect(isFavorited).toBe(true);

      // Verify there's only one entry
      const favorites = await db.getMyFavorites(testUserId);
      const count = favorites.filter((car: any) => car.id === testCarId).length;
      expect(count).toBe(1);
    });

    it("should fetch user's favorites", async () => {
      // Add another favorite
      await db.addFavorite(testUserId, testCarId2);

      const favorites = await db.getMyFavorites(testUserId);
      expect(favorites).toBeInstanceOf(Array);
      expect(favorites.length).toBeGreaterThanOrEqual(1);
    });

    it("should remove a favorite", async () => {
      await db.removeFavorite(testUserId, testCarId2);
      const isFavorited = await db.isFavorited(testUserId, testCarId2);
      expect(isFavorited).toBe(false);
    });

    it("should return empty favorites for user with no favorites", async () => {
      // Create a new user with no favorites
      await db.upsertUser({
        email: "no-favorites@example.com",
        name: "No Favorites User",
        loginMethod: "manual",
      });

      const newUser = await db.getUserByEmail("no-favorites@example.com");
      const newUserId = newUser?.id || 0;

      const favorites = await db.getMyFavorites(newUserId);
      expect(favorites).toBeInstanceOf(Array);
      expect(favorites.length).toBe(0);
    });

    it("should check if car is favorited by specific user", async () => {
      // Create another user
      await db.upsertUser({
        email: "other-user@example.com",
        name: "Other User",
        loginMethod: "manual",
      });

      const otherUser = await db.getUserByEmail("other-user@example.com");
      const otherUserId = otherUser?.id || 0;

      // Check that otherUser doesn't have testCarId favorited
      const otherUserHasFav = await db.isFavorited(otherUserId, testCarId);
      expect(otherUserHasFav).toBe(false);
    });
  });

  describe("Integration Tests", () => {
    it("should handle user updating listings", async () => {
      // Verify we can fetch existing listings
      const listings = await db.getMyListings(testUserId);
      expect(listings).toBeDefined();
      expect(listings.length).toBeGreaterThan(0);

      // Update an existing listing
      const updated = await db.updateMyListing(testCarId, testUserId, {
        price: "27000",
      });
      expect(updated).toBeDefined();
      expect(updated?.price).toMatch(/27000/);
    });

    it("should handle user favoriting and unfavoriting cars", async () => {
      // Add to favorites
      await db.addFavorite(testUserId, testCarId);
      let isFav = await db.isFavorited(testUserId, testCarId);
      expect(isFav).toBe(true);

      // Get favorites
      const favorites = await db.getMyFavorites(testUserId);
      expect(favorites).toBeDefined();
      expect(favorites.length).toBeGreaterThan(0);

      // Remove favorite
      await db.removeFavorite(testUserId, testCarId);
      isFav = await db.isFavorited(testUserId, testCarId);
      expect(isFav).toBe(false);
    });
  });
});
