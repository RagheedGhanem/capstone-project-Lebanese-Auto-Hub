import { describe, it, expect, beforeAll } from "vitest";
import * as db from "./db";

describe("Case-Insensitive Search", () => {
  let testCarId: number;

  beforeAll(async () => {
    // Create a test user
    await db.upsertUser({
      email: "search-test@example.com",
      name: "Search Test User",
      loginMethod: "manual",
    });

    const testUser = await db.getUserByEmail("search-test@example.com");
    const testUserId = testUser?.id || 0;

    // Create a test car with specific brand, model, color, and type
    const carResult = await db.createCar({
      userId: testUserId,
      brand: "BMW",
      model: "X5",
      carType: "SUV",
      year: 2023,
      color: "Black",
      price: "60000",
      transmission: "Automatic",
      fuelType: "Gasoline",
      engineSize: "3.0L",
      description: "Luxury SUV",
      sellerName: "Test Seller",
      sellerPhone: "+961123456",
      sellerEmail: "seller@example.com",
      sellerLocation: "Beirut",
    });

    testCarId = carResult || 0;
  });

  describe("Brand Search", () => {
    it("should find cars with lowercase brand search", async () => {
      const results = await db.getAllCars({ brand: "bmw" });
      expect(results.length).toBeGreaterThan(0);
      expect(results.some((car: any) => car.brand.toLowerCase() === "bmw")).toBe(
        true
      );
    });

    it("should find cars with uppercase brand search", async () => {
      const results = await db.getAllCars({ brand: "BMW" });
      expect(results.length).toBeGreaterThan(0);
      expect(results.some((car: any) => car.brand.toLowerCase() === "bmw")).toBe(
        true
      );
    });

    it("should find cars with mixed case brand search", async () => {
      const results = await db.getAllCars({ brand: "Bmw" });
      expect(results.length).toBeGreaterThan(0);
      expect(results.some((car: any) => car.brand.toLowerCase() === "bmw")).toBe(
        true
      );
    });
  });

  describe("Model Search", () => {
    it("should find cars with lowercase model search", async () => {
      const results = await db.getAllCars({ model: "x5" });
      expect(results.length).toBeGreaterThan(0);
      expect(results.some((car: any) => car.model.toLowerCase() === "x5")).toBe(
        true
      );
    });

    it("should find cars with uppercase model search", async () => {
      const results = await db.getAllCars({ model: "X5" });
      expect(results.length).toBeGreaterThan(0);
      expect(results.some((car: any) => car.model.toLowerCase() === "x5")).toBe(
        true
      );
    });

    it("should find cars with mixed case model search", async () => {
      const results = await db.getAllCars({ model: "X5" });
      expect(results.length).toBeGreaterThan(0);
      expect(results.some((car: any) => car.model.toLowerCase() === "x5")).toBe(
        true
      );
    });
  });

  describe("Color Search", () => {
    it("should find cars with lowercase color search", async () => {
      const results = await db.getAllCars({ color: "black" });
      expect(results.length).toBeGreaterThan(0);
      expect(results.some((car: any) => car.color.toLowerCase() === "black")).toBe(
        true
      );
    });

    it("should find cars with uppercase color search", async () => {
      const results = await db.getAllCars({ color: "BLACK" });
      expect(results.length).toBeGreaterThan(0);
      expect(results.some((car: any) => car.color.toLowerCase() === "black")).toBe(
        true
      );
    });

    it("should find cars with mixed case color search", async () => {
      const results = await db.getAllCars({ color: "BlAcK" });
      expect(results.length).toBeGreaterThan(0);
      expect(results.some((car: any) => car.color.toLowerCase() === "black")).toBe(
        true
      );
    });
  });

  describe("Car Type Search", () => {
    it("should find cars with lowercase car type search", async () => {
      const results = await db.getAllCars({ carType: "suv" });
      expect(results.length).toBeGreaterThan(0);
      expect(results.some((car: any) => car.carType.toLowerCase() === "suv")).toBe(
        true
      );
    });

    it("should find cars with uppercase car type search", async () => {
      const results = await db.getAllCars({ carType: "SUV" });
      expect(results.length).toBeGreaterThan(0);
      expect(results.some((car: any) => car.carType.toLowerCase() === "suv")).toBe(
        true
      );
    });

    it("should find cars with mixed case car type search", async () => {
      const results = await db.getAllCars({ carType: "SuV" });
      expect(results.length).toBeGreaterThan(0);
      expect(results.some((car: any) => car.carType.toLowerCase() === "suv")).toBe(
        true
      );
    });
  });

  describe("Combined Filters", () => {
    it("should find cars with multiple case-insensitive filters", async () => {
      const results = await db.getAllCars({
        brand: "bmw",
        model: "x5",
        carType: "suv",
        color: "black",
      });
      expect(results.length).toBeGreaterThan(0);
      expect(
        results.some(
          (car: any) =>
            car.brand.toLowerCase() === "bmw" &&
            car.model.toLowerCase() === "x5" &&
            car.carType.toLowerCase() === "suv" &&
            car.color.toLowerCase() === "black"
        )
      ).toBe(true);
    });

    it("should find cars with mixed case combined filters", async () => {
      const results = await db.getAllCars({
        brand: "BMW",
        model: "X5",
        carType: "SUV",
        color: "BLACK",
      });
      expect(results.length).toBeGreaterThan(0);
      expect(
        results.some(
          (car: any) =>
            car.brand.toLowerCase() === "bmw" &&
            car.model.toLowerCase() === "x5" &&
            car.carType.toLowerCase() === "suv" &&
            car.color.toLowerCase() === "black"
        )
      ).toBe(true);
    });
  });

  describe("Partial Matches", () => {
    it("should find cars with partial lowercase brand search", async () => {
      const results = await db.getAllCars({ brand: "bm" });
      expect(results.length).toBeGreaterThan(0);
      expect(
        results.some((car: any) => car.brand.toLowerCase().includes("bm"))
      ).toBe(true);
    });

    it("should find cars with partial uppercase brand search", async () => {
      const results = await db.getAllCars({ brand: "BM" });
      expect(results.length).toBeGreaterThan(0);
      expect(
        results.some((car: any) => car.brand.toLowerCase().includes("bm"))
      ).toBe(true);
    });
  });
});
