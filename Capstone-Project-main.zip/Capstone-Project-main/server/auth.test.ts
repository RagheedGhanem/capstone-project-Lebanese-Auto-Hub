import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import { TrpcContext } from "./_core/context";
import { validatePassword, validateEmail, hashPassword, comparePassword } from "./auth-utils";

describe("Authentication System", () => {
  describe("Password Validation", () => {
    it("should reject password without uppercase letter", () => {
      const result = validatePassword("password123!");
      expect(result.valid).toBe(false);
      expect(result.errors).toContain("Password must contain at least one uppercase letter");
    });

    it("should reject password without lowercase letter", () => {
      const result = validatePassword("PASSWORD123!");
      expect(result.valid).toBe(false);
      expect(result.errors).toContain("Password must contain at least one lowercase letter");
    });

    it("should reject password without number", () => {
      const result = validatePassword("Password!");
      expect(result.valid).toBe(false);
      expect(result.errors).toContain("Password must contain at least one number");
    });

    it("should reject password without special character", () => {
      const result = validatePassword("Password123");
      expect(result.valid).toBe(false);
      expect(result.errors).toContain("Password must contain at least one special character");
    });

    it("should reject password shorter than 8 characters", () => {
      const result = validatePassword("Pass1!");
      expect(result.valid).toBe(false);
      expect(result.errors).toContain("Password must be at least 8 characters long");
    });

    it("should accept valid password", () => {
      const result = validatePassword("ValidPass123!");
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it("should accept password with multiple special characters", () => {
      const result = validatePassword("ValidPass@#$%123");
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });
  });

  describe("Email Validation", () => {
    it("should accept valid email", () => {
      expect(validateEmail("user@example.com")).toBe(true);
    });

    it("should accept email with subdomain", () => {
      expect(validateEmail("user@mail.example.com")).toBe(true);
    });

    it("should reject email without @", () => {
      expect(validateEmail("userexample.com")).toBe(false);
    });

    it("should reject email without domain", () => {
      expect(validateEmail("user@")).toBe(false);
    });

    it("should reject email without local part", () => {
      expect(validateEmail("@example.com")).toBe(false);
    });

    it("should reject email with spaces", () => {
      expect(validateEmail("user @example.com")).toBe(false);
    });
  });

  describe("Password Hashing", () => {
    it("should hash password", async () => {
      const password = "TestPass123!";
      const hash = await hashPassword(password);
      expect(hash).not.toBe(password);
      expect(hash.length).toBeGreaterThan(20);
    });

    it("should generate different hashes for same password", async () => {
      const password = "TestPass123!";
      const hash1 = await hashPassword(password);
      const hash2 = await hashPassword(password);
      expect(hash1).not.toBe(hash2);
    });

    it("should verify correct password", async () => {
      const password = "TestPass123!";
      const hash = await hashPassword(password);
      const isValid = await comparePassword(password, hash);
      expect(isValid).toBe(true);
    });

    it("should reject incorrect password", async () => {
      const password = "TestPass123!";
      const hash = await hashPassword(password);
      const isValid = await comparePassword("WrongPass123!", hash);
      expect(isValid).toBe(false);
    });
  });

  describe("Sign Up Procedure", () => {
    it("should reject sign up with invalid email", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: { protocol: "https", headers: {} } as any,
        res: { cookie: () => {}, clearCookie: () => {} } as any,
      });

      try {
        await caller.auth.signUpWithPassword({
          email: "invalid-email",
          name: "Test User",
          password: "ValidPass123!",
          confirmPassword: "ValidPass123!",
        });
        expect.fail("Should have thrown error");
      } catch (error: any) {
        expect(error.message).toContain("Invalid email address");
      }
    });

    it("should reject sign up with weak password", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: { protocol: "https", headers: {} } as any,
        res: { cookie: () => {}, clearCookie: () => {} } as any,
      });

      try {
        await caller.auth.signUpWithPassword({
          email: "test@example.com",
          name: "Test User",
          password: "weak",
          confirmPassword: "weak",
        });
        expect.fail("Should have thrown error");
      } catch (error: any) {
        expect(error.message).toContain("Password must be");
      }
    });

    it("should reject sign up with mismatched passwords", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: { protocol: "https", headers: {} } as any,
        res: { cookie: () => {}, clearCookie: () => {} } as any,
      });

      try {
        await caller.auth.signUpWithPassword({
          email: "test@example.com",
          name: "Test User",
          password: "ValidPass123!",
          confirmPassword: "DifferentPass123!",
        });
        expect.fail("Should have thrown error");
      } catch (error: any) {
        expect(error.message).toContain("don't match");
      }
    });

    it("should reject sign up with short name", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: { protocol: "https", headers: {} } as any,
        res: { cookie: () => {}, clearCookie: () => {} } as any,
      });

      try {
        await caller.auth.signUpWithPassword({
          email: "test@example.com",
          name: "A",
          password: "ValidPass123!",
          confirmPassword: "ValidPass123!",
        });
        expect.fail("Should have thrown error");
      } catch (error: any) {
        expect(error.message).toContain("at least 2 characters");
      }
    });
  });

  describe("Sign In Procedure", () => {
    it("should reject sign in with invalid email format", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: { protocol: "https", headers: {} } as any,
        res: { cookie: () => {}, clearCookie: () => {} } as any,
      });

      try {
        await caller.auth.signInWithPassword({
          email: "invalid-email",
          password: "ValidPass123!",
        });
        expect.fail("Should have thrown error");
      } catch (error: any) {
        expect(error.message).toContain("Invalid email address");
      }
    });

    it("should reject sign in with non-existent email", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: { protocol: "https", headers: {} } as any,
        res: { cookie: () => {}, clearCookie: () => {} } as any,
      });

      try {
        await caller.auth.signInWithPassword({
          email: "nonexistent@example.com",
          password: "ValidPass123!",
        });
        expect.fail("Should have thrown error");
      } catch (error: any) {
        expect(error.message).toContain("Invalid email or password");
      }
    });
  });

  describe("Logout Procedure", () => {
    it("should clear session cookie on logout", async () => {
      const clearedCookies: any[] = [];

      const ctx: TrpcContext = {
        user: {
          id: 1,
          openId: "test-user",
          email: "test@example.com",
          name: "Test User",
          loginMethod: "email",
          role: "user",
          createdAt: new Date(),
          updatedAt: new Date(),
          lastSignedIn: new Date(),
        },
        req: {
          protocol: "https",
          headers: {},
        } as any,
        res: {
          clearCookie: (name: string, options: any) => {
            clearedCookies.push({ name, options });
          },
        } as any,
      };

      const caller = appRouter.createCaller(ctx);
      const result = await caller.auth.logout();

      expect(result.success).toBe(true);
      expect(clearedCookies).toHaveLength(1);
      expect(clearedCookies[0].name).toBe("app_session_id");
      expect(clearedCookies[0].options.maxAge).toBe(-1);
    });
  });
});
