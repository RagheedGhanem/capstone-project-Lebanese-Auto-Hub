import { z } from "zod";
import { router, publicProcedure, protectedProcedure } from "./_core/trpc";
import * as db from "./db";
import { invokeLLM } from "./_core/llm";
import { ENV } from "./_core/env";
import bcrypt from "bcrypt";
import { COOKIE_NAME } from "@shared/const";
import { sdk } from "./_core/sdk";

export const appRouter = router({
  auth: router({
    me: publicProcedure.query(async ({ ctx }) => {
      return ctx.user ?? null;
    }),

    logout: protectedProcedure.mutation(async ({ ctx }) => {
      // Clear the session cookie by setting it to empty with maxAge 0
      if (ctx.res) {
        ctx.res.clearCookie(COOKIE_NAME);
      }
      return { success: true };
    }),

    signIn: publicProcedure
      .input(z.object({
        email: z.string().email(),
        password: z.string().min(8),
      }))
      .mutation(async ({ input, ctx }) => {
        const user = await db.getUserByEmail(input.email);
        if (!user || !user.passwordHash) {
          throw new Error("Invalid credentials");
        }

        const isPasswordValid = await bcrypt.compare(input.password, user.passwordHash);
        if (!isPasswordValid) {
          throw new Error("Invalid credentials");
        }

        // Set session cookie using JWT format for manual users
        if (ctx.res) {
          // Use email as openId for manual auth users
          const sessionToken = await sdk.createSessionToken(input.email, {
            name: user.name || "",
            expiresInMs: 30 * 24 * 60 * 60 * 1000,
          });
          ctx.res.cookie(COOKIE_NAME, sessionToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === "production",
            sameSite: "lax",
            maxAge: 30 * 24 * 60 * 60 * 1000,
          });
        }

        return user;
      }),

    signUp: publicProcedure
      .input(z.object({
        email: z.string().email(),
        password: z.string().min(8).regex(/[A-Z]/, "Password must contain uppercase"),
        name: z.string().min(2),
      }))
      .mutation(async ({ input, ctx }) => {
        const existing = await db.getUserByEmail(input.email);
        if (existing) {
          throw new Error("Email already registered");
        }

        const passwordHash = await bcrypt.hash(input.password, 10);

        const user = await db.upsertUser({
          email: input.email,
          name: input.name,
          passwordHash,
          loginMethod: "email",
        });

        // Set session cookie using JWT format for manual users
        if (ctx.res) {
          // Use email as openId for manual auth users
          const sessionToken = await sdk.createSessionToken(input.email, {
            name: input.name,
            expiresInMs: 30 * 24 * 60 * 60 * 1000,
          });
          ctx.res.cookie(COOKIE_NAME, sessionToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === "production",
            sameSite: "lax",
            maxAge: 30 * 24 * 60 * 60 * 1000,
          });
        }

        return user;
      }),

    changePassword: protectedProcedure
      .input(z.object({
        currentPassword: z.string(),
        newPassword: z.string(),
        confirmPassword: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        // Only allow manual (email) users to change password
        if (ctx.user.loginMethod !== "email") {
          throw new Error("Password change is only available for email-based accounts. You signed in with " + (ctx.user.loginMethod || "OAuth") + ".");
        }

        // Validate that new password and confirm password match
        if (input.newPassword !== input.confirmPassword) {
          throw new Error("New password and confirm password do not match");
        }

        // Validate new password strength
        const { validatePassword } = await import("./auth-utils");
        const validation = validatePassword(input.newPassword);
        if (!validation.valid) {
          throw new Error(validation.errors.join(", "));
        }

        // Verify current password
        const user = await db.getUserByEmail(ctx.user.email!);
        if (!user || !user.passwordHash) {
          throw new Error("User not found or has no password");
        }

        const { comparePassword } = await import("./auth-utils");
        const isCurrentPasswordValid = await comparePassword(input.currentPassword, user.passwordHash);
        if (!isCurrentPasswordValid) {
          throw new Error("Current password is incorrect");
        }

        // Update password
        await db.updateUserPassword(ctx.user.id, input.newPassword);

        return { success: true, message: "Password changed successfully" };
      }),

    // updateProfile: Removed - updateUser function not implemented in db.ts
  }),

  cars: router({
    list: publicProcedure
      .input(z.object({
        brand: z.string().optional(),
        model: z.string().optional(),
        carType: z.string().optional(),
        year: z.number().optional(),
        minYear: z.number().optional(),
        maxYear: z.number().optional(),
        color: z.string().optional(),
        minPrice: z.number().optional(),
        maxPrice: z.number().optional(),
        status: z.string().optional(),
      }))
      .query(async ({ input }) => {
        return await db.getCars(input);
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getCarById(input.id);
      }),

    getImages: publicProcedure
      .input(z.object({ carId: z.number() }))
      .query(async ({ input }) => {
        return await db.getCarImages(input.carId);
      }),

    create: protectedProcedure
      .input(z.object({
        brand: z.string(),
        model: z.string(),
        year: z.number(),
        carType: z.string(),
        color: z.string(),
        kilometers: z.number(),
        condition: z.enum(["new", "excellent", "good", "fair", "poor"]),
        price: z.string(),
        description: z.string().optional(),
        transmission: z.string().optional(),
        fuelType: z.string().optional(),
        engineSize: z.string().optional(),
        sellerName: z.string(),
        sellerPhone: z.string(),
        sellerEmail: z.string(),
        sellerLocation: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        const carId = await db.createCar({
          userId: ctx.user.id,
          brand: input.brand,
          model: input.model,
          year: input.year,
          carType: input.carType,
          color: input.color,
          kilometers: input.kilometers,
          condition: input.condition,
          price: input.price,
          description: input.description,
          transmission: input.transmission,
          fuelType: input.fuelType,
          engineSize: input.engineSize,
          sellerName: input.sellerName,
          sellerPhone: input.sellerPhone,
          sellerEmail: input.sellerEmail,
          sellerLocation: input.sellerLocation,
        });

        return { carId };
      }),
  }),

  inquiries: router({
    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        email: z.string().email(),
        phone: z.string(),
        brand: z.string().optional(),
        model: z.string().optional(),
        carType: z.string().optional(),
        year: z.number().optional(),
        color: z.string().optional(),
        minPrice: z.string().optional(),
        maxPrice: z.string().optional(),
        additionalNotes: z.string().optional(),
        carId: z.number().optional(),
        sellerEmail: z.string().email().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const inquiryId = await db.createInquiry({
          userId: ctx.user.id,
          carId: input.carId || null,
          name: input.name,
          email: input.email,
          phone: input.phone,
          brand: input.brand || null,
          model: input.model || null,
          carType: input.carType || null,
          year: input.year || null,
          color: input.color || null,
          minPrice: input.minPrice ? (parseFloat(input.minPrice) as any) : null,
          maxPrice: input.maxPrice ? (parseFloat(input.maxPrice) as any) : null,
          additionalNotes: input.additionalNotes || null,
          sellerEmail: input.sellerEmail || null,
        });

        // Send notification to seller if email is provided
        // CRITICAL: Always use input.sellerEmail as recipient, NEVER input.email
        if (input.sellerEmail && input.brand && input.model && input.year) {
          // Validation: Warn if seller email matches buyer email
          if (input.sellerEmail === input.email) {
            console.warn(
              `[Inquiry] WARNING: sellerEmail (${input.sellerEmail}) matches buyerEmail (${input.email}). This might indicate a configuration issue.`
            );
          }

          try {
            const { notifySeller } = await import("./_core/seller-notification");
            console.log(
              `[Inquiry] Sending notification to seller: ${input.sellerEmail} for car ${input.brand} ${input.model}`
            );
            await notifySeller({
              sellerEmail: input.sellerEmail,
              buyerName: input.name,
              buyerEmail: input.email,
              buyerPhone: input.phone,
              carBrand: input.brand,
              carModel: input.model,
              carYear: input.year,
              carId: input.carId || 0,
              message: input.additionalNotes,
            });
          } catch (error) {
            console.error("Failed to send seller notification:", error);
            // Don't fail the inquiry creation if notification fails
          }
        } else if (!input.sellerEmail) {
          console.warn(
            `[Inquiry] No seller email provided for inquiry. Seller will not be notified.`
          );
        }

        return { inquiryId };
      }),

    getByCarId: publicProcedure
      .input(z.object({ carId: z.number() }))
      .query(async ({ input }) => {
        // Return empty array for now - getInquiriesByCarId not implemented
        return [];
      }),

    getSellerInquiries: protectedProcedure
      .query(async ({ ctx }) => {
        const { getSellerInquiries } = await import("./db");
        return await getSellerInquiries(ctx.user.id);
      }),

    updateStatus: protectedProcedure
      .input(z.object({
        inquiryId: z.number(),
        status: z.enum(["new", "contacted", "completed", "cancelled"]),
      }))
      .mutation(async ({ input, ctx }) => {
        const { updateInquiryStatus, getInquiryById, getMyListings } = await import("./db");
        const inquiry = await getInquiryById(input.inquiryId);
        if (!inquiry) throw new Error("Inquiry not found");
        
        const userListings = await getMyListings(ctx.user.id);
        const carIds = userListings.map(c => c.id);
        
        if (!carIds.includes(inquiry.carId || 0)) {
          throw new Error("Unauthorized: Inquiry does not belong to your listings");
        }
        
        await updateInquiryStatus(input.inquiryId, input.status);
        return { success: true };
      }),
  }),

  chat: router({
    getHistory: publicProcedure
      .input(z.object({
        sessionId: z.string(),
      }))
      .query(async ({ input }) => {
        // For now, return empty array. In production, you'd fetch from database
        return [];
      }),
    searchCars: publicProcedure
      .input(z.object({
        userQuery: z.string(),
        conversationHistory: z.array(z.object({
          role: z.enum(["user", "assistant"]),
          content: z.string(),
        })).optional(),
        previousPreferences: z.any().optional(),
      }))
      .mutation(async ({ input }) => {
        if (!ENV.forgeApiKey) {
          // No API key — do a basic keyword search without LLM
          const matchingCars = await db.searchCarsByPreferences({ limit: 5 });
          return {
            message: "AI assistant is not configured. Showing all available cars.",
            listings: matchingCars.map((car: any) => ({
              id: car.id, brand: car.brand, model: car.model, year: car.year,
              price: car.price, kilometers: car.kilometers, transmission: car.transmission,
              fuelType: car.fuelType, condition: car.condition, sellerName: car.sellerName,
              sellerPhone: car.sellerPhone, sellerEmail: car.sellerEmail,
              sellerLocation: car.sellerLocation, carType: car.carType, color: car.color,
            })),
          };
        }

        // Use LLM to extract car preferences from user query
        const extractionPrompt = `Extract car preferences from this query. Return ONLY valid JSON, nothing else.

JSON format (omit fields not mentioned in the query):
{"brands":["brand"],"models":["model"],"minYear":2015,"maxYear":2024,"minPrice":5000,"maxPrice":50000,"maxMileage":150000,"carTypes":["sedan"],"transmissions":["automatic"],"fuelTypes":["gasoline"],"colors":["black"],"sellerLocations":["Beirut"]}

Query: ${input.userQuery}

Return ONLY the JSON object. No markdown. No backticks. No explanation. Just the JSON.`;

        const extractionResponse = await invokeLLM({
          messages: [
            { role: "system" as const, content: "You are a JSON extraction assistant. Return only valid JSON." },
            { role: "user" as const, content: extractionPrompt },
          ],
        });

        let preferences = {};
        try {
          let responseText = typeof extractionResponse.choices[0].message.content === 'string' 
            ? extractionResponse.choices[0].message.content 
            : JSON.stringify(extractionResponse.choices[0].message.content);
          
          // Remove markdown code blocks and extract JSON
          // Handle ```json ... ``` format
          const jsonMatch = responseText.match(/```(?:json)?\s*([\s\S]*?)```/);
          if (jsonMatch) {
            responseText = jsonMatch[1];
          }
          
          // Also handle cases where there's just ``` without json keyword
          responseText = responseText.replace(/```/g, '').trim();
          
          // Extract JSON object if there's surrounding text
          const objectMatch = responseText.match(/\{[\s\S]*\}/);
          if (objectMatch) {
            responseText = objectMatch[0];
          }
          
          preferences = JSON.parse(responseText);
          
          // Merge with previous preferences if this is a refinement query
          if (input.previousPreferences) {
            // Check if user is asking for refinements (cheaper, more expensive, newer, older, etc.)
            const refinementKeywords = ["cheaper", "more expensive", "newer", "older", "smaller", "larger", "less mileage", "more features"];
            const isRefinement = refinementKeywords.some(keyword => input.userQuery.toLowerCase().includes(keyword));
            
            if (isRefinement) {
              // Merge preferences, allowing new preferences to override
              preferences = { ...input.previousPreferences, ...preferences };
            }
          }
        } catch (e) {
          console.error("Failed to parse preferences:", e);
          console.error("Response was:", extractionResponse.choices[0].message.content);
          // Return empty preferences on error so search doesn't crash
          preferences = {};
        }

        // Search for cars matching the extracted preferences
        const matchingCars = await db.searchCarsByPreferences({
          ...preferences,
          limit: 5,
        });

        // Format the results for the chatbot response
        if (matchingCars.length === 0) {
          return {
            message: "I couldn't find any cars matching your preferences. Could you provide more details about what you're looking for?",
            listings: [],
          };
        }

        // Format listings for display
        const formattedListings = matchingCars.map((car: any) => ({
          id: car.id,
          brand: car.brand,
          model: car.model,
          year: car.year,
          price: car.price,
          kilometers: car.kilometers,
          transmission: car.transmission,
          fuelType: car.fuelType,
          condition: car.condition,
          sellerName: car.sellerName,
          sellerPhone: car.sellerPhone,
          sellerEmail: car.sellerEmail,
          sellerLocation: car.sellerLocation,
          carType: car.carType,
          color: car.color,
        }));

        // Generate a friendly response with the listings
        const responsePrompt = `You found ${matchingCars.length} cars matching the user's preferences. Here are the listings:

${formattedListings.map((car: any, i: number) => `
${i + 1}. ${car.year} ${car.brand} ${car.model}
   Price: $${car.price}
   Mileage: ${car.kilometers} km
   Transmission: ${car.transmission}
   Fuel: ${car.fuelType}
   Condition: ${car.condition}
   Seller: ${car.sellerName} (${car.sellerLocation})
   Contact: ${car.sellerPhone} / ${car.sellerEmail}
`).join('')}

Provide a friendly summary of these listings and highlight the best matches for the user's needs.`;

        const responseMessage = await invokeLLM({
          messages: [
            { role: "system" as const, content: "You are a helpful car marketplace assistant." },
            ...(input.conversationHistory || []),
            { role: "user" as const, content: responsePrompt },
          ],
        });

        const responseText = typeof responseMessage.choices[0].message.content === 'string'
          ? responseMessage.choices[0].message.content
          : JSON.stringify(responseMessage.choices[0].message.content);

        return {
          message: responseText,
          listings: formattedListings,
          preferences: preferences,
        };
      }),
    sendMessage: publicProcedure
      .input(z.object({
        message: z.string(),
        sessionId: z.string(),
        conversationHistory: z.array(z.object({
          role: z.enum(["user", "assistant"]),
          content: z.string(),
        })).optional(),
      }))
      .mutation(async ({ input }) => {
        if (!ENV.forgeApiKey) {
          return {
            message: "AI assistant is not configured. Please add BUILT_IN_FORGE_API_KEY to your .env file to enable the AI chat assistant.",
          };
        }

        // Check if this is a car-related query
        const carKeywords = ["looking for", "find", "search", "car", "vehicle", "brand", "model", "price", "budget", "mileage", "sedan", "suv", "truck", "coupe", "show me", "what", "which", "recommend", "suggest"];
        const isCarQuery = carKeywords.some(kw => input.message.toLowerCase().includes(kw));
        
        if (isCarQuery) {
          try {
            // Try to search database for car-related queries
            const extractionPrompt = `Extract car preferences from this query. Return ONLY valid JSON, nothing else.

JSON format:
{"brands":["brand"],"models":["model"],"minYear":2015,"maxYear":2024,"minPrice":5000,"maxPrice":50000,"maxMileage":150000,"carTypes":["sedan"],"transmissions":["automatic"],"fuelTypes":["gasoline"],"colors":["black"],"sellerLocations":["Beirut"]}

Query: ${input.message}

Return ONLY the JSON object. No markdown. No backticks. No explanation.`;

            const extractionResponse = await invokeLLM({
              messages: [
                { role: "system" as const, content: "You are a JSON extraction assistant. Return only valid JSON." },
                { role: "user" as const, content: extractionPrompt },
              ],
            });

            let preferences = {};
            try {
              let responseText = typeof extractionResponse.choices[0].message.content === 'string' 
                ? extractionResponse.choices[0].message.content 
                : JSON.stringify(extractionResponse.choices[0].message.content);
              
              const jsonMatch = responseText.match(/```(?:json)?\s*([\s\S]*?)```/);
              if (jsonMatch) responseText = jsonMatch[1];
              responseText = responseText.replace(/```/g, '').trim();
              const objectMatch = responseText.match(/\{[\s\S]*\}/);
              if (objectMatch) responseText = objectMatch[0];
              
              preferences = JSON.parse(responseText);
            } catch (e) {
              console.error("Failed to parse preferences:", e);
            }

            const matchingCars = await db.searchCarsByPreferences({
              ...preferences,
              limit: 5,
            });

            if (matchingCars.length > 0) {
              const formattedListings = matchingCars.map((car: any) => ({
                id: car.id,
                brand: car.brand,
                model: car.model,
                year: car.year,
                price: car.price,
                kilometers: car.kilometers,
                transmission: car.transmission,
                fuelType: car.fuelType,
                condition: car.condition,
                sellerName: car.sellerName,
                sellerPhone: car.sellerPhone,
                sellerEmail: car.sellerEmail,
                sellerLocation: car.sellerLocation,
                carType: car.carType,
                color: car.color,
              }));

              const responsePrompt = `You found ${matchingCars.length} cars matching the user's preferences. Here are the listings:

${formattedListings.map((car: any, i: number) => `
${i + 1}. ${car.year} ${car.brand} ${car.model}
   Price: $${car.price}
   Mileage: ${car.kilometers} km
   Transmission: ${car.transmission}
   Fuel: ${car.fuelType}
   Condition: ${car.condition}
   Seller: ${car.sellerName} (${car.sellerLocation})
   Contact: ${car.sellerPhone} / ${car.sellerEmail}
`).join('')}

Provide a friendly summary of these listings and highlight the best matches for the user's needs.`;

              const responseMessage = await invokeLLM({
                messages: [
                  { role: "system" as const, content: "You are a helpful car marketplace assistant." },
                  ...(input.conversationHistory || []),
                  { role: "user" as const, content: responsePrompt },
                ],
              });

              const responseText = typeof responseMessage.choices[0].message.content === 'string'
                ? responseMessage.choices[0].message.content
                : JSON.stringify(responseMessage.choices[0].message.content);

              return {
                message: responseText,
                listings: formattedListings,
                preferences: preferences,
              };
            }
          } catch (e) {
            console.error("Error in car search:", e);
          }
        }

        // Fall back to generic chat
        const messages = [
          { role: "system" as const, content: "You are a helpful car marketplace assistant. Help users with car buying, selling, and valuation questions." },
          ...(input.conversationHistory || []),
          { role: "user" as const, content: input.message },
        ];
        const response = await invokeLLM({
          messages: messages,
        });
        const content = response.choices[0].message.content;
        const contentStr = typeof content === 'string' ? content : JSON.stringify(content);
        return { message: contentStr };
      }),
  }),

  valuation: router({
    estimate: protectedProcedure
      .input(z.object({
        brand: z.string(),
        model: z.string(),
        year: z.number(),
        kilometers: z.number(),
        condition: z.string(),
        imageUrls: z.array(z.string()).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (!ENV.forgeApiKey) {
          throw new Error("AI valuation is not configured. Please add BUILT_IN_FORGE_API_KEY to your .env file.");
        }

        const prompt = `You are a professional car valuation expert for the Lebanese car market. Based on the following car details, provide a detailed price valuation estimate.

Car Details:
- Brand: ${input.brand}
- Model: ${input.model}
- Year: ${input.year}
- Kilometers: ${input.kilometers}
- Condition: ${input.condition}

You MUST respond with ONLY a valid JSON object — no markdown, no explanation, no code blocks. Just the raw JSON.

Required format (all fields mandatory):
{"estimatedValue":15000,"minPrice":13000,"maxPrice":17000,"currency":"USD","valuationFactors":"explanation of price factors","conditionAssessment":"assessment of condition","recommendations":"seller recommendations"}`;

        const messages = input.imageUrls && input.imageUrls.length > 0
          ? [
              {
                role: "user" as const,
                content: [
                  { type: "text" as const, text: prompt },
                  ...input.imageUrls.map(url => ({
                    type: "image_url" as const,
                    image_url: { url, detail: "high" as const },
                  })),
                ],
              },
            ]
          : [{ role: "user" as const, content: prompt }];

        const response = await invokeLLM({
          messages: messages,
          response_format: { type: "json_object" },
        });

        const content = response.choices[0].message.content;
        let valuationData: any;
        try {
          const raw = typeof content === 'string' ? content : JSON.stringify(content);
          // Strip any accidental markdown code fences
          const clean = raw.replace(/```(?:json)?/gi, "").replace(/```/g, "").trim();
          const jsonMatch = clean.match(/\{[\s\S]*\}/);
          valuationData = JSON.parse(jsonMatch ? jsonMatch[0] : clean);
        } catch {
          throw new Error("AI returned an invalid valuation response. Please try again.");
        }

        // Format detailed analysis with Lebanese market context
        const detailedAnalysis = `## Valuation Analysis for ${input.year} ${input.brand} ${input.model}

### Estimated Market Value
**${valuationData.currency} ${valuationData.estimatedValue.toLocaleString()}**

Price Range: ${valuationData.currency} ${valuationData.minPrice.toLocaleString()} - ${valuationData.maxPrice.toLocaleString()}

### Valuation Factors
${valuationData.valuationFactors}

${valuationData.marketAnalysis ? `### Lebanese Market Analysis\n${valuationData.marketAnalysis}` : ''}

### Condition Assessment
${valuationData.conditionAssessment}

### Recommendations for Seller
${valuationData.recommendations}`;

        // Save valuation to database
        const valuationId = await db.createValuation({
          userId: ctx.user.id,
          brand: input.brand,
          model: input.model,
          year: input.year,
          kilometers: input.kilometers,
          condition: input.condition,
          estimatedValue: valuationData.estimatedValue,
          currency: valuationData.currency,
          valuationDetails: detailedAnalysis,
          imageAnalysis: valuationData.conditionAssessment,
        });

        return {
          id: valuationId,
          estimatedValue: valuationData.estimatedValue,
          details: detailedAnalysis,
        };
      }),
  }),

  system: router({
    notifyOwner: protectedProcedure
      .input(z.object({
        title: z.string(),
        content: z.string(),
      }))
      .mutation(async ({ input }) => {
        // Placeholder - implement notification logic
        return { success: true };
      }),
  }),

  listings: router({
    getMyListings: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.user) throw new Error("Unauthorized");
      return await db.getMyListings(ctx.user.id);
    }),

    updateListing: protectedProcedure
      .input(z.object({
        carId: z.number(),
        updates: z.object({}).passthrough(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        return await db.updateMyListing(input.carId, ctx.user.id, input.updates);
      }),

    deleteListing: protectedProcedure
      .input(z.object({ carId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        return await db.deleteMyListing(input.carId, ctx.user.id);
      }),
  }),

  favorites: router({
    add: protectedProcedure
      .input(z.object({ carId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        await db.addFavorite(ctx.user.id, input.carId);
        return { success: true };
      }),

    remove: protectedProcedure
      .input(z.object({ carId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        await db.removeFavorite(ctx.user.id, input.carId);
        return { success: true };
      }),

    getMyFavorites: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.user) throw new Error("Unauthorized");
      return await db.getMyFavorites(ctx.user.id);
    }),

    isFavorited: protectedProcedure
      .input(z.object({ carId: z.number() }))
      .query(async ({ input, ctx }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        return await db.isFavorited(ctx.user.id, input.carId);
      }),
  }),

  admin: router({
    // Get all users (admin only)
    getAllUsers: protectedProcedure
      .query(async ({ ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Unauthorized: Admin access required");
        }
        const db = await import("./db");
        const allUsers = await db.getAllUsers();
        return allUsers;
      }),

    // Delete user (admin only)
    deleteUser: protectedProcedure
      .input(z.object({ userId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Unauthorized: Admin access required");
        }
        if (input.userId === ctx.user.id) {
          throw new Error("Cannot delete your own account");
        }
        const db = await import("./db");
        await db.deleteUser(input.userId);
        return { success: true };
      }),

    // Update user role (admin only)
    updateUserRole: protectedProcedure
      .input(z.object({ userId: z.number(), role: z.enum(["user", "admin"]) }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Unauthorized: Admin access required");
        }
        if (input.userId === ctx.user.id) {
          throw new Error("Cannot change your own role");
        }
        const db = await import("./db");
        await db.updateUserRole(input.userId, input.role);
        return { success: true };
      }),

    // Get all listings (admin only)
    getAllListings: protectedProcedure
      .query(async ({ ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Unauthorized: Admin access required");
        }
        const db = await import("./db");
        return await db.getAllCars();
      }),

    // Delete listing (admin only)
    deleteListing: protectedProcedure
      .input(z.object({ carId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Unauthorized: Admin access required");
        }
        const db = await import("./db");
        await db.deleteCarListing(input.carId);
        return { success: true };
      }),

    // Update listing (admin only)
    updateListing: protectedProcedure
      .input(z.object({
        carId: z.number(),
        updates: z.record(z.string(), z.any()),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Unauthorized: Admin access required");
        }
        const db = await import("./db");
        await db.updateCar(input.carId, input.updates);
        return { success: true };
      }),

    // Get statistics (admin only)
    getStatistics: protectedProcedure
      .query(async ({ ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Unauthorized: Admin access required");
        }
        const db = await import("./db");
        
        // Get total users count
        const allUsers = await db.getAllUsers();
        const totalUsers = allUsers.length;
        
        // Get active listings count
        const allListings = await db.getAllCars();
        const activeListings = allListings.length;
        
        // Get admin count
        const adminCount = allUsers.filter(u => u.role === "admin").length;
        
        return {
          totalUsers,
          activeListings,
          adminCount,
        };
      }),
  }),

  dealers: router({
    list: publicProcedure.query(async () => {
      return await db.getAllDealers();
    }),
  }),
});

export type AppRouter = typeof appRouter;
