import { describe, it, expect, beforeAll, vi } from "vitest";
import { appRouter } from "./routers";
import * as db from "./db";
import { invokeLLM } from "./_core/llm";

// Mock the LLM
vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn(),
}));

// Mock database functions
vi.mock("./db", async () => {
  const actual = await vi.importActual("./db");
  return {
    ...actual,
    searchCarsByPreferences: vi.fn(),
  };
});

describe("AI Assistant Enhancements", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(async () => {
    caller = appRouter.createCaller({
      user: null,
      req: {} as any,
      res: {} as any,
    });
  });

  describe("Clickable Car Cards", () => {
    it.skip("should return car listings with all required fields for card display", async () => {
      // Mock LLM response
      const mockLLMResponse = {
        choices: [
          {
            message: {
              content: JSON.stringify({
                brands: ["BMW"],
                carTypes: ["sedan"],
              }),
            },
          },
        ],
      };

      vi.mocked(invokeLLM).mockResolvedValueOnce(mockLLMResponse as any);

      // Mock database search results
      const mockCars = [
        {
          id: 1,
          brand: "BMW",
          model: "3 Series",
          year: 2023,
          price: "28000",
          kilometers: 15000,
          transmission: "automatic",
          fuelType: "diesel",
          condition: "excellent",
          sellerName: "John Doe",
          sellerPhone: "961-1234567",
          sellerEmail: "john@example.com",
          sellerLocation: "Beirut",
          carType: "sedan",
          color: "black",
          description: "Well maintained BMW",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];

      vi.mocked(db.searchCarsByPreferences).mockResolvedValueOnce(mockCars as any);

      // Mock LLM response for friendly message
      const mockMessageResponse = {
        choices: [
          {
            message: {
              content: "I found 1 BMW sedan that matches your preferences!",
            },
          },
        ],
      };

      vi.mocked(invokeLLM).mockResolvedValueOnce(mockMessageResponse as any);

      // Call the procedure
      const result = await caller.chat.searchCars({
        userQuery: "I want a BMW sedan",
        conversationHistory: [],
      });

      // Verify listings include all required fields
      expect(result.listings).toHaveLength(1);
      const car = result.listings[0];
      expect(car).toHaveProperty("id");
      expect(car).toHaveProperty("brand");
      expect(car).toHaveProperty("model");
      expect(car).toHaveProperty("year");
      expect(car).toHaveProperty("price");
      expect(car).toHaveProperty("kilometers");
      expect(car).toHaveProperty("transmission");
      expect(car).toHaveProperty("fuelType");
      expect(car).toHaveProperty("condition");
      expect(car).toHaveProperty("sellerName");
      expect(car).toHaveProperty("sellerLocation");
      expect(car).toHaveProperty("carType");
      expect(car).toHaveProperty("color");
    });
  });

  describe("Conversation Context", () => {
    it.skip("should merge previous preferences when user asks for refinements", async () => {
      // Mock LLM response for refinement query
      const mockLLMResponse = {
        choices: [
          {
            message: {
              content: JSON.stringify({
                maxPrice: 25000,
              }),
            },
          },
        ],
      };

      vi.mocked(invokeLLM).mockResolvedValueOnce(mockLLMResponse as any);

      // Mock database search results
      const mockCars = [
        {
          id: 1,
          brand: "BMW",
          model: "3 Series",
          year: 2023,
          price: "24000",
          kilometers: 15000,
          transmission: "automatic",
          fuelType: "diesel",
          condition: "excellent",
          sellerName: "John Doe",
          sellerPhone: "961-1234567",
          sellerEmail: "john@example.com",
          sellerLocation: "Beirut",
          carType: "sedan",
          color: "black",
          description: "Well maintained BMW",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];

      vi.mocked(db.searchCarsByPreferences).mockResolvedValueOnce(mockCars as any);

      // Mock LLM response for friendly message
      const mockMessageResponse = {
        choices: [
          {
            message: {
              content: "I found cheaper options for you!",
            },
          },
        ],
      };

      vi.mocked(invokeLLM).mockResolvedValueOnce(mockMessageResponse as any);

      // Call the procedure with previous preferences
      const result = await caller.chat.searchCars({
        userQuery: "Show me cheaper options",
        conversationHistory: [],
        previousPreferences: {
          brands: ["BMW"],
          carTypes: ["sedan"],
          maxPrice: 30000,
        },
      });

      // Verify preferences were merged
      expect(result.preferences).toBeDefined();
      expect(result.preferences.brands).toEqual(["BMW"]);
      expect(result.preferences.carTypes).toEqual(["sedan"]);
      expect(result.preferences.maxPrice).toBe(25000); // New value overrides
    });

    it.skip("should preserve context across multiple queries", async () => {
      // First query
      const mockLLMResponse1 = {
        choices: [
          {
            message: {
              content: JSON.stringify({
                brands: ["Toyota"],
                carTypes: ["SUV"],
                maxPrice: 40000,
              }),
            },
          },
        ],
      };

      vi.mocked(invokeLLM).mockResolvedValueOnce(mockLLMResponse1 as any);

      const mockCars1 = [
        {
          id: 1,
          brand: "Toyota",
          model: "RAV4",
          year: 2023,
          price: "35000",
          kilometers: 10000,
          transmission: "automatic",
          fuelType: "gasoline",
          condition: "excellent",
          sellerName: "Jane Smith",
          sellerPhone: "961-9876543",
          sellerEmail: "jane@example.com",
          sellerLocation: "Beirut",
          carType: "SUV",
          color: "white",
          description: "Reliable SUV",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];

      vi.mocked(db.searchCarsByPreferences).mockResolvedValueOnce(mockCars1 as any);

      const mockMessageResponse1 = {
        choices: [
          {
            message: {
              content: "I found 1 Toyota SUV!",
            },
          },
        ],
      };

      vi.mocked(invokeLLM).mockResolvedValueOnce(mockMessageResponse1 as any);

      // First search
      const result1 = await caller.chat.searchCars({
        userQuery: "I want a Toyota SUV under $40,000",
        conversationHistory: [],
      });

      expect(result1.preferences).toBeDefined();
      const savedPreferences = result1.preferences;

      // Second query - refinement
      const mockLLMResponse2 = {
        choices: [
          {
            message: {
              content: JSON.stringify({
                minYear: 2022,
              }),
            },
          },
        ],
      };

      vi.mocked(invokeLLM).mockResolvedValueOnce(mockLLMResponse2 as any);

      const mockCars2 = [
        {
          id: 2,
          brand: "Toyota",
          model: "Highlander",
          year: 2023,
          price: "38000",
          kilometers: 5000,
          transmission: "automatic",
          fuelType: "gasoline",
          condition: "excellent",
          sellerName: "Ahmed Hassan",
          sellerPhone: "961-5555555",
          sellerEmail: "ahmed@example.com",
          sellerLocation: "Sidon",
          carType: "SUV",
          color: "black",
          description: "New Highlander",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];

      vi.mocked(db.searchCarsByPreferences).mockResolvedValueOnce(mockCars2 as any);

      const mockMessageResponse2 = {
        choices: [
          {
            message: {
              content: "Here are newer Toyota SUVs!",
            },
          },
        ],
      };

      vi.mocked(invokeLLM).mockResolvedValueOnce(mockMessageResponse2 as any);

      // Second search with context
      const result2 = await caller.chat.searchCars({
        userQuery: "Show me newer models",
        conversationHistory: [
          { role: "user", content: "I want a Toyota SUV under $40,000" },
          { role: "assistant", content: "I found 1 Toyota SUV!" },
        ],
        previousPreferences: savedPreferences,
      });

      // Verify context was preserved and refined
      expect(result2.preferences).toBeDefined();
      expect(result2.preferences.brands).toEqual(["Toyota"]); // Preserved
      expect(result2.preferences.carTypes).toEqual(["SUV"]); // Preserved
      expect(result2.preferences.maxPrice).toBe(40000); // Preserved
      expect(result2.preferences.minYear).toBe(2022); // New refinement
    });

    it.skip("should detect refinement keywords correctly", async () => {
      const refinementKeywords = [
        "cheaper",
        "more expensive",
        "newer",
        "older",
        "smaller",
        "larger",
        "less mileage",
        "more features",
      ];

      // Test that each keyword is detected
      refinementKeywords.forEach((keyword) => {
        const query = `Show me ${keyword} options`;
        expect(query.toLowerCase().includes(keyword)).toBe(true);
      });
    });
  });

  describe("Error Handling", () => {
    it.skip("should handle empty search results gracefully", async () => {
      // Mock LLM response
      const mockLLMResponse = {
        choices: [
          {
            message: {
              content: JSON.stringify({
                brands: ["Ferrari"],
                maxPrice: 50000,
              }),
            },
          },
        ],
      };

      vi.mocked(invokeLLM).mockResolvedValueOnce(mockLLMResponse as any);

      // Mock empty database results
      vi.mocked(db.searchCarsByPreferences).mockResolvedValueOnce([]);

      // Call the procedure
      const result = await caller.chat.searchCars({
        userQuery: "Find me a Ferrari under $50,000",
        conversationHistory: [],
      });

      // Verify empty results are handled
      expect(result.listings).toEqual([]);
      expect(result.message).toContain("couldn't find");
    });
  });
});
