import { z } from "zod";
import { router, publicProcedure, protectedProcedure } from "./_core/trpc";
import * as db from "./db";
import { invokeLLM } from "./_core/llm";
import bcrypt from "bcrypt";
import { COOKIE_NAME } from "@shared/const";
import { sdk } from "./_core/sdk";

export const appRouter = router({
  auth: router({
    me: publicProcedure.query(async ({ ctx }) => {
      return ctx.user ?? null;
    }),

    logout: protectedProcedure.mutation(async ({ ctx }) => {
      // Clear the session cookie by setting it to empty with maxAge 0
      if (ctx.res) {
        ctx.res.clearCookie(COOKIE_NAME);
      }
      return { success: true };
    }),

    signIn: publicProcedure
      .input(z.object({
        email: z.string().email(),
        password: z.string().min(8),
      }))
      .mutation(async ({ input, ctx }) => {
        const user = await db.getUserByEmail(input.email);
        if (!user || !user.passwordHash) {
          throw new Error("Invalid credentials");
        }

        const isPasswordValid = await bcrypt.compare(input.password, user.passwordHash);
        if (!isPasswordValid) {
          throw new Error("Invalid credentials");
        }

        // Set session cookie using JWT format for manual users
        if (ctx.res) {
          // Use email as openId for manual auth users
          const sessionToken = await sdk.createSessionToken(input.email, {
            name: user.name || "",
            expiresInMs: 30 * 24 * 60 * 60 * 1000,
          });
          ctx.res.cookie(COOKIE_NAME, sessionToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === "production",
            sameSite: "lax",
            maxAge: 30 * 24 * 60 * 60 * 1000,
          });
        }

        return user;
      }),

    signUp: publicProcedure
      .input(z.object({
        email: z.string().email(),
        password: z.string().min(8).regex(/[A-Z]/, "Password must contain uppercase"),
        name: z.string().min(2),
      }))
      .mutation(async ({ input, ctx }) => {
        const existing = await db.getUserByEmail(input.email);
        if (existing) {
          throw new Error("Email already registered");
        }

        const passwordHash = await bcrypt.hash(input.password, 10);

        const user = await db.upsertUser({
          email: input.email,
          name: input.name,
          passwordHash,
          loginMethod: "email",
        });

        // Set session cookie using JWT format for manual users
        if (ctx.res) {
          // Use email as openId for manual auth users
          const sessionToken = await sdk.createSessionToken(input.email, {
            name: input.name,
            expiresInMs: 30 * 24 * 60 * 60 * 1000,
          });
          ctx.res.cookie(COOKIE_NAME, sessionToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === "production",
            sameSite: "lax",
            maxAge: 30 * 24 * 60 * 60 * 1000,
          });
        }

        return user;
      }),

    changePassword: protectedProcedure
      .input(z.object({
        currentPassword: z.string(),
        newPassword: z.string(),
        confirmPassword: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user?.email) {
          throw new Error("User not authenticated");
        }

        if (input.newPassword !== input.confirmPassword) {
          throw new Error("Passwords do not match");
        }

        const user = await db.getUserByEmail(ctx.user.email);
        if (!user || !user.passwordHash) {
          throw new Error("User not found");
        }

        const isPasswordValid = await bcrypt.compare(input.currentPassword, user.passwordHash);
        if (!isPasswordValid) {
          throw new Error("Current password is incorrect");
        }

        const newPasswordHash = await bcrypt.hash(input.newPassword, 10);
        await db.updateUserPassword(user.id, newPasswordHash);

        return { success: true };
      }),
  }),

  cars: router({
    browse: publicProcedure
      .input(z.object({
        brand: z.string().optional(),
        model: z.string().optional(),
        carType: z.string().optional(),
        minPrice: z.number().optional(),
        maxPrice: z.number().optional(),
        year: z.number().optional(),
        color: z.string().optional(),
        status: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        const filters = input ? {
          brand: input.brand,
          model: input.model,
          carType: input.carType,
          minPrice: input.minPrice,
          maxPrice: input.maxPrice,
          year: input.year,
          color: input.color,
          status: input.status,
        } : undefined;

        return await db.getCars(filters);
      }),

    getById: publicProcedure
      .input(z.object({
        id: z.number(),
      }))
      .query(async ({ input }) => {
        return await db.getCarById(input.id);
      }),

    create: protectedProcedure
      .input(z.object({
        brand: z.string(),
        model: z.string(),
        carType: z.string(),
        year: z.number(),
        color: z.string(),
        kilometers: z.number().optional(),
        price: z.number(),
        description: z.string().optional(),
        transmission: z.string().optional(),
        fuelType: z.string().optional(),
        engineSize: z.string().optional(),
        features: z.string().optional(),
        sellerName: z.string().optional(),
        sellerPhone: z.string().optional(),
        sellerEmail: z.string().optional(),
        sellerLocation: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const carId = await db.createCar({
          userId: ctx.user?.id,
          brand: input.brand,
          model: input.model,
          carType: input.carType,
          year: input.year,
          color: input.color,
          kilometers: input.kilometers,
          price: input.price.toString(),
          description: input.description,
          transmission: input.transmission,
          fuelType: input.fuelType,
          engineSize: input.engineSize,
          features: input.features,
          sellerName: input.sellerName,
          sellerPhone: input.sellerPhone,
          sellerEmail: input.sellerEmail,
          sellerLocation: input.sellerLocation,
          status: "available",
        });

        return { id: carId };
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        brand: z.string().optional(),
        model: z.string().optional(),
        carType: z.string().optional(),
        year: z.number().optional(),
        color: z.string().optional(),
        kilometers: z.number().optional(),
        price: z.number().optional(),
        description: z.string().optional(),
        transmission: z.string().optional(),
        fuelType: z.string().optional(),
        engineSize: z.string().optional(),
        features: z.string().optional(),
        sellerName: z.string().optional(),
        sellerPhone: z.string().optional(),
        sellerEmail: z.string().optional(),
        sellerLocation: z.string().optional(),
        status: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const car = await db.getCarById(input.id);
        if (!car || (car.userId !== ctx.user?.id && ctx.user?.role !== 'admin')) {
          throw new Error("Unauthorized");
        }

        const updates: any = {};
        if (input.brand !== undefined) updates.brand = input.brand;
        if (input.model !== undefined) updates.model = input.model;
        if (input.carType !== undefined) updates.carType = input.carType;
        if (input.year !== undefined) updates.year = input.year;
        if (input.color !== undefined) updates.color = input.color;
        if (input.kilometers !== undefined) updates.kilometers = input.kilometers;
        if (input.price !== undefined) updates.price = input.price.toString();
        if (input.description !== undefined) updates.description = input.description;
        if (input.transmission !== undefined) updates.transmission = input.transmission;
        if (input.fuelType !== undefined) updates.fuelType = input.fuelType;
        if (input.engineSize !== undefined) updates.engineSize = input.engineSize;
        if (input.features !== undefined) updates.features = input.features;
        if (input.sellerName !== undefined) updates.sellerName = input.sellerName;
        if (input.sellerPhone !== undefined) updates.sellerPhone = input.sellerPhone;
        if (input.sellerEmail !== undefined) updates.sellerEmail = input.sellerEmail;
        if (input.sellerLocation !== undefined) updates.sellerLocation = input.sellerLocation;
        if (input.status !== undefined) updates.status = input.status;

        await db.updateCar(input.id, updates);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({
        id: z.number(),
      }))
      .mutation(async ({ input, ctx }) => {
        const car = await db.getCarById(input.id);
        if (!car || (car.userId !== ctx.user?.id && ctx.user?.role !== 'admin')) {
          throw new Error("Unauthorized");
        }

        await db.deleteCar(input.id);
        return { success: true };
      }),

    addImage: protectedProcedure
      .input(z.object({
        carId: z.number(),
        imageUrl: z.string(),
        imageKey: z.string(),
        isPrimary: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.addCarImage({
          carId: input.carId,
          imageUrl: input.imageUrl,
          imageKey: input.imageKey,
          isPrimary: input.isPrimary,
        });
        return { success: true };
      }),

    getImages: publicProcedure
      .input(z.object({
        carId: z.number(),
      }))
      .query(async ({ input }) => {
        return await db.getCarImages(input.carId);
      }),
  }),

  chat: router({
    getHistory: publicProcedure
      .input(z.object({
        sessionId: z.string(),
      }))
      .query(async ({ input }) => {
        // For now, return empty array. In production, you'd fetch from database
        return [];
      }),
    searchCars: publicProcedure
      .input(z.object({
        userQuery: z.string(),
        conversationHistory: z.array(z.object({
          role: z.enum(["user", "assistant"]),
          content: z.string(),
        })).optional(),
        previousPreferences: z.any().optional(),
      }))
      .mutation(async ({ input }) => {
        // Use LLM to extract car preferences from user query
        const extractionPrompt = `Extract car preferences from this query. Return ONLY valid JSON, nothing else.

JSON format (omit fields not mentioned in the query):
{"brands":["brand"],"models":["model"],"minYear":2015,"maxYear":2024,"minPrice":5000,"maxPrice":50000,"maxMileage":150000,"carTypes":["sedan"],"transmissions":["automatic"],"fuelTypes":["gasoline"],"colors":["black"],"sellerLocations":["Beirut"]}

Query: ${input.userQuery}

Return ONLY the JSON object. No markdown. No backticks. No explanation. Just the JSON.`;

        const extractionResponse = await invokeLLM({
          messages: [
            { role: "system" as const, content: "You are a JSON extraction assistant. Return only valid JSON." },
            { role: "user" as const, content: extractionPrompt },
          ],
        });

        let preferences = {};
        try {
          let responseText = typeof extractionResponse.choices[0].message.content === 'string' 
            ? extractionResponse.choices[0].message.content 
            : JSON.stringify(extractionResponse.choices[0].message.content);
          
          // Remove markdown code blocks and extract JSON
          // Handle ```json ... ``` format
          const jsonMatch = responseText.match(/```(?:json)?\s*([\s\S]*?)```/);
          if (jsonMatch) {
            responseText = jsonMatch[1];
          }
          
          // Also handle cases where there's just ``` without json keyword
          responseText = responseText.replace(/```/g, '').trim();
          
          // Extract JSON object if there's surrounding text
          const objectMatch = responseText.match(/\{[\s\S]*\}/);
          if (objectMatch) {
            responseText = objectMatch[0];
          }
          
          preferences = JSON.parse(responseText);
          
          // Merge with previous preferences if this is a refinement query
          if (input.previousPreferences) {
            // Check if user is asking for refinements (cheaper, more expensive, newer, older, etc.)
            const refinementKeywords = ["cheaper", "more expensive", "newer", "older", "smaller", "larger", "less mileage", "more features"];
            const isRefinement = refinementKeywords.some(keyword => input.userQuery.toLowerCase().includes(keyword));
            
            if (isRefinement) {
              // Merge preferences, allowing new preferences to override
              preferences = { ...input.previousPreferences, ...preferences };
            }
          }
        } catch (e) {
          console.error("Failed to parse preferences:", e);
          console.error("Response was:", extractionResponse.choices[0].message.content);
          // Return empty preferences on error so search doesn't crash
          preferences = {};
        }

        // Search for cars matching the extracted preferences
        const matchingCars = await db.searchCarsByPreferences({
          ...preferences,
          limit: 5,
        });

        // Format the results for the chatbot response
        if (matchingCars.length === 0) {
          return {
            message: "I couldn't find any cars matching your preferences. Could you provide more details about what you're looking for?",
            listings: [],
          };
        }

        // Format listings for display
        const formattedListings = matchingCars.map((car: any) => ({
          id: car.id,
          brand: car.brand,
          model: car.model,
          year: car.year,
          price: car.price,
          kilometers: car.kilometers,
          transmission: car.transmission,
          fuelType: car.fuelType,
          condition: car.condition,
          sellerName: car.sellerName,
          sellerPhone: car.sellerPhone,
          sellerEmail: car.sellerEmail,
          sellerLocation: car.sellerLocation,
          carType: car.carType,
          color: car.color,
        }));

        // Generate a friendly response with the listings
        const responsePrompt = `You found ${matchingCars.length} cars matching the user's preferences. Here are the listings:

${formattedListings.map((car: any, i: number) => `
${i + 1}. ${car.year} ${car.brand} ${car.model}
   Price: $${car.price}
   Mileage: ${car.kilometers} km
   Transmission: ${car.transmission}
   Fuel: ${car.fuelType}
   Condition: ${car.condition}
   Seller: ${car.sellerName} (${car.sellerLocation})
   Contact: ${car.sellerPhone} / ${car.sellerEmail}
`).join('')}

Provide a friendly summary of these listings and highlight the best matches for the user's needs.`;

        const responseMessage = await invokeLLM({
          messages: [
            { role: "system" as const, content: "You are a helpful car marketplace assistant." },
            ...(input.conversationHistory || []),
            { role: "user" as const, content: responsePrompt },
          ],
        });

        const responseText = typeof responseMessage.choices[0].message.content === 'string'
          ? responseMessage.choices[0].message.content
          : JSON.stringify(responseMessage.choices[0].message.content);

        return {
          message: responseText,
          listings: formattedListings,
          preferences: preferences,
        };
      }),
    sendMessage: publicProcedure
      .input(z.object({
        message: z.string(),
        sessionId: z.string(),
        conversationHistory: z.array(z.object({
          role: z.enum(["user", "assistant"]),
          content: z.string(),
        })).optional(),
        previousPreferences: z.any().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        // Always check if this is a car-related query
        const carSearchKeywords = ["looking for", "find", "search", "car", "vehicle", "brand", "model", "price", "budget", "mileage", "sedan", "suv", "truck", "coupe", "automatic", "manual", "diesel", "gasoline", "electric", "cheaper", "expensive", "newer", "older", "show me", "what", "which", "recommend", "suggest", "available", "inventory"];
        const isCarSearch = carSearchKeywords.some(keyword => input.message.toLowerCase().includes(keyword));

        // If it's a car-related query, try to search the database
        if (isCarSearch) {
          try {
            // Use LLM to extract car preferences from user query
            const extractionPrompt = `Extract car preferences from this query. Return ONLY valid JSON, nothing else.

JSON format (omit fields not mentioned in the query):
{"brands":["brand"],"models":["model"],"minYear":2015,"maxYear":2024,"minPrice":5000,"maxPrice":50000,"maxMileage":150000,"carTypes":["sedan"],"transmissions":["automatic"],"fuelTypes":["gasoline"],"colors":["black"],"sellerLocations":["Beirut"]}

Query: ${input.message}

Return ONLY the JSON object. No markdown. No backticks. No explanation. Just the JSON.`;

            const extractionResponse = await invokeLLM({
              messages: [
                { role: "system" as const, content: "You are a JSON extraction assistant. Return only valid JSON." },
                { role: "user" as const, content: extractionPrompt },
              ],
            });

            let preferences = {};
            try {
              let responseText = typeof extractionResponse.choices[0].message.content === 'string' 
                ? extractionResponse.choices[0].message.content 
                : JSON.stringify(extractionResponse.choices[0].message.content);
              
              // Remove markdown code blocks and extract JSON
              const jsonMatch = responseText.match(/```(?:json)?\s*([\s\S]*?)```/);
              if (jsonMatch) {
                responseText = jsonMatch[1];
              }
              
              responseText = responseText.replace(/```/g, '').trim();
              
              // Extract JSON object if there's surrounding text
              const objectMatch = responseText.match(/\{[\s\S]*\}/);
              if (objectMatch) {
                responseText = objectMatch[0];
              }
              
              preferences = JSON.parse(responseText);
              
              // Merge with previous preferences if this is a refinement query
              if (input.previousPreferences) {
                const refinementKeywords = ["cheaper", "more expensive", "newer", "older", "smaller", "larger", "less mileage", "more features"];
                const isRefinement = refinementKeywords.some(keyword => input.message.toLowerCase().includes(keyword));
                
                if (isRefinement) {
                  preferences = { ...input.previousPreferences, ...preferences };
                }
              }
            } catch (e) {
              console.error("Failed to parse preferences in sendMessage:", e);
              // Continue with empty preferences
            }

            // Search for cars matching the extracted preferences
            const matchingCars = await db.searchCarsByPreferences({
              ...preferences,
              limit: 5,
            });

            // If we found cars, return them as search results
            if (matchingCars.length > 0) {
              const formattedListings = matchingCars.map((car: any) => ({
                id: car.id,
                brand: car.brand,
                model: car.model,
                year: car.year,
                price: car.price,
                kilometers: car.kilometers,
                transmission: car.transmission,
                fuelType: car.fuelType,
                condition: car.condition,
                sellerName: car.sellerName,
                sellerPhone: car.sellerPhone,
                sellerEmail: car.sellerEmail,
                sellerLocation: car.sellerLocation,
                carType: car.carType,
                color: car.color,
              }));

              const responsePrompt = `You found ${matchingCars.length} cars matching the user's preferences. Here are the listings:

${formattedListings.map((car: any, i: number) => `
${i + 1}. ${car.year} ${car.brand} ${car.model}
   Price: $${car.price}
   Mileage: ${car.kilometers} km
   Transmission: ${car.transmission}
   Fuel: ${car.fuelType}
   Condition: ${car.condition}
   Seller: ${car.sellerName} (${car.sellerLocation})
   Contact: ${car.sellerPhone} / ${car.sellerEmail}
`).join('')}

Provide a friendly summary of these listings and highlight the best matches for the user's needs.`;

              const responseMessage = await invokeLLM({
                messages: [
                  { role: "system" as const, content: "You are a helpful car marketplace assistant." },
                  ...(input.conversationHistory || []),
                  { role: "user" as const, content: responsePrompt },
                ],
              });

              const responseText = typeof responseMessage.choices[0].message.content === 'string'
                ? responseMessage.choices[0].message.content
                : JSON.stringify(responseMessage.choices[0].message.content);

              return {
                message: responseText,
                listings: formattedListings,
                preferences: preferences,
              };
            }
          } catch (e) {
            console.error("Error in car search fallback:", e);
            // Fall through to generic chat
          }
        }

        // Fall back to generic chat for non-car queries or if search fails
        const messages = [
          { role: "system" as const, content: "You are a helpful car marketplace assistant. Help users with car buying, selling, and valuation questions." },
          ...(input.conversationHistory || []),
          { role: "user" as const, content: input.message },
        ];
        const response = await invokeLLM({
          messages: messages,
        });
        const content = response.choices[0].message.content;
        const contentStr = typeof content === 'string' ? content : JSON.stringify(content);
        return { message: contentStr };
      }),
  }),

  valuation: router({
    estimate: protectedProcedure
      .input(z.object({
        brand: z.string(),
        model: z.string(),
        year: z.number(),
        kilometers: z.number(),
        condition: z.string(),
        imageUrls: z.array(z.string()).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const prompt = `You are a professional car valuation expert. Based on the following car details and images, provide a detailed price valuation estimate.

Car Details:
- Brand: ${input.brand}
- Model: ${input.model}
- Year: ${input.year}
- Kilometers: ${input.kilometers}
- Condition: ${input.condition}

Provide a valuation estimate in USD and explain your reasoning.`;

        const response = await invokeLLM({
          messages: [
            { role: "system" as const, content: "You are a professional car valuation expert." },
            { role: "user" as const, content: prompt },
          ],
        });

        const valuationDetails = typeof response.choices[0].message.content === 'string'
          ? response.choices[0].message.content
          : JSON.stringify(response.choices[0].message.content);

        // Extract estimated value from response (simplified)
        const valueMatch = valuationDetails.match(/\$[\d,]+/);
        const estimatedValue = valueMatch ? parseInt(valueMatch[0].replace(/[$,]/g, '')) : 0;

        const valuationId = await db.createValuation({
          userId: ctx.user?.id,
          brand: input.brand,
          model: input.model,
          year: input.year,
          kilometers: input.kilometers,
          condition: input.condition,
          estimatedValue: estimatedValue.toString(),
          valuationDetails,
        });

        return { id: valuationId, estimatedValue, details: valuationDetails };
      }),
  }),

  system: router({
    notifyOwner: publicProcedure
      .input(z.object({
        title: z.string(),
        content: z.string(),
      }))
      .mutation(async ({ input }) => {
        // Placeholder for notification logic
        console.log(`[Notification] ${input.title}: ${input.content}`);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
