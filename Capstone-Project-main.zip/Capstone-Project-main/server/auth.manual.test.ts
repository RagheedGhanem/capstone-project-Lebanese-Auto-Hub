import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import * as db from "./db";
import bcrypt from "bcrypt";
import { sdk } from "./_core/sdk";
import { COOKIE_NAME } from "@shared/const";

// Mock the database functions
vi.mock("./db", () => ({
  getUserByEmail: vi.fn(),
  getUserByOpenId: vi.fn(),
  upsertUser: vi.fn(),
}));

describe("Manual Authentication Flow", () => {
  const testEmail = "test@example.com";
  const testPassword = "TestPassword123";
  const testName = "Test User";

  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  describe("Session Token Creation", () => {
    it("should create a valid JWT session token for manual users", async () => {
      const token = await sdk.createSessionToken(testEmail, {
        name: testName,
        expiresInMs: 30 * 24 * 60 * 60 * 1000,
      });

      expect(token).toBeDefined();
      expect(typeof token).toBe("string");
      expect(token.split(".").length).toBe(3); // JWT has 3 parts
    });

    it("should verify a valid session token", async () => {
      const token = await sdk.createSessionToken(testEmail, {
        name: testName,
        expiresInMs: 30 * 24 * 60 * 60 * 1000,
      });

      const verified = await sdk.verifySession(token);

      expect(verified).toBeDefined();
      expect(verified?.openId).toBe(testEmail);
      expect(verified?.name).toBe(testName);
      expect(verified?.appId).toBeDefined();
    });

    it("should reject an invalid session token", async () => {
      const verified = await sdk.verifySession("invalid.token.here");

      expect(verified).toBeNull();
    });

    it("should reject an expired session token", async () => {
      // Create a token that expires immediately
      const token = await sdk.createSessionToken(testEmail, {
        name: testName,
        expiresInMs: 1, // 1ms expiration
      });

      // Wait a bit to ensure expiration
      await new Promise((resolve) => setTimeout(resolve, 10));

      const verified = await sdk.verifySession(token);

      expect(verified).toBeNull();
    });
  });

  describe("Authentication Request with Manual Users", () => {
    it("should authenticate a manual user by email when openId lookup fails", async () => {
      const mockUser = {
        id: 1,
        email: testEmail,
        name: testName,
        openId: null,
        passwordHash: "hashed",
        loginMethod: "email",
        lastSignedIn: new Date(),
        createdAt: new Date(),
      };

      // Create a valid session token using email as openId
      const sessionToken = await sdk.createSessionToken(testEmail, {
        name: testName,
        expiresInMs: 30 * 24 * 60 * 60 * 1000,
      });

      // Mock the database calls
      (db.getUserByOpenId as any).mockResolvedValueOnce(null); // First lookup by openId fails
      (db.getUserByEmail as any).mockResolvedValueOnce(mockUser); // Second lookup by email succeeds
      (db.upsertUser as any).mockResolvedValueOnce(mockUser); // Update lastSignedIn

      // Create a mock Express request with the session cookie
      const mockReq = {
        headers: {
          cookie: `${COOKIE_NAME}=${sessionToken}`,
        },
      } as any;

      const user = await sdk.authenticateRequest(mockReq);

      expect(user).toBeDefined();
      expect(user.email).toBe(testEmail);
      expect(db.getUserByOpenId).toHaveBeenCalledWith(testEmail);
      expect(db.getUserByEmail).toHaveBeenCalledWith(testEmail);
      expect(db.upsertUser).toHaveBeenCalled();
    });

    it("should fail authentication with missing session cookie", async () => {
      const mockReq = {
        headers: {},
      } as any;

      await expect(sdk.authenticateRequest(mockReq)).rejects.toThrow(
        "Invalid session cookie"
      );
    });

    it("should fail authentication with invalid session token", async () => {
      const mockReq = {
        headers: {
          cookie: `${COOKIE_NAME}=invalid.token.here`,
        },
      } as any;

      await expect(sdk.authenticateRequest(mockReq)).rejects.toThrow(
        "Invalid session cookie"
      );
    });
  });

  describe("Password Hashing", () => {
    it("should hash passwords correctly", async () => {
      const hash = await bcrypt.hash(testPassword, 10);

      expect(hash).toBeDefined();
      expect(hash).not.toBe(testPassword);
      expect(hash.length).toBeGreaterThan(20);
    });

    it("should verify correct passwords", async () => {
      const hash = await bcrypt.hash(testPassword, 10);
      const isValid = await bcrypt.compare(testPassword, hash);

      expect(isValid).toBe(true);
    });

    it("should reject incorrect passwords", async () => {
      const hash = await bcrypt.hash(testPassword, 10);
      const isValid = await bcrypt.compare("WrongPassword123", hash);

      expect(isValid).toBe(false);
    });
  });
});
