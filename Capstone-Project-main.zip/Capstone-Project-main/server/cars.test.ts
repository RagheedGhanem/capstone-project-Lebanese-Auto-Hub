import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "oauth",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

describe("cars.list", () => {
  it("returns empty array when no filters provided", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.cars.list();

    expect(Array.isArray(result)).toBe(true);
  });

  it("accepts filter parameters", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.cars.list({
      brand: "Toyota",
      model: "Camry",
      year: 2020,
    });

    expect(Array.isArray(result)).toBe(true);
  });
});

describe("cars.create", () => {
  it("creates a car with required fields", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.cars.create({
      brand: "Toyota",
      model: "Camry",
      carType: "sedan",
      year: 2020,
      color: "Black",
      kilometers: 50000,
      condition: "good",
      price: 25000,
      description: "Well maintained car",
    });

    expect(result).toHaveProperty("carId");
    expect(typeof result.carId).toBe("number");
  });
});

describe("dealers.list", () => {
  it("returns array of dealers", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.dealers.list();

    expect(Array.isArray(result)).toBe(true);
  });

  it("filters active dealers by default", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.dealers.list({ activeOnly: true });

    expect(Array.isArray(result)).toBe(true);
  });
});

describe("inquiries.create", () => {
  it("creates an inquiry with contact information", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.inquiries.create({
      name: "John Doe",
      email: "john@example.com",
      phone: "+961 XX XXX XXX",
      brand: "Toyota",
      model: "Camry",
      minPrice: 20000,
      maxPrice: 30000,
    });

    expect(result).toHaveProperty("inquiryId");
    expect(typeof result.inquiryId).toBe("number");
  });
});

describe("chat.sendMessage", () => {
  it("sends a message and receives response", { timeout: 30000 }, async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const sessionId = `test-session-${Date.now()}`;

    const result = await caller.chat.sendMessage({
      sessionId,
      message: "I'm looking for a family SUV",
    });

    expect(result).toHaveProperty("message");
    expect(result).toHaveProperty("conversationId");
    expect(typeof result.message).toBe("string");
    expect(result.message.length).toBeGreaterThan(0);
  });
});
