import { ENV } from "./env";

export interface SendEmailOptions {
  to: string;
  subject: string;
  html: string;
  replyTo?: string;
}

/**
 * Send email using Forge API
 */
export async function sendEmail(options: SendEmailOptions): Promise<boolean> {
  try {
    // Use notification API which supports email sending
    const response = await fetch(`${ENV.forgeApiUrl}/notification/send`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${ENV.forgeApiKey}`,
      },
      body: JSON.stringify({
        to: options.to,
        subject: options.subject,
        html: options.html,
        replyTo: options.replyTo,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`Email API error: ${response.status} ${response.statusText} - ${errorText}`);
      return false;
    }

    return true;
  } catch (error) {
    console.error("Failed to send email:", error);
    return false;
  }
}

/**
 * Generate inquiry email HTML
 */
export function generateInquiryEmailHTML(options: {
  buyerName: string;
  buyerEmail: string;
  buyerPhone: string;
  additionalNotes?: string;
  carBrand: string;
  carModel: string;
  carYear: number;
  carId: number;
}): string {
  return `
    <!DOCTYPE html>
    <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #f5a623; color: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; }
          .section { margin-bottom: 20px; }
          .section-title { font-weight: bold; font-size: 14px; color: #666; margin-bottom: 10px; }
          .info-row { margin-bottom: 10px; }
          .label { font-weight: bold; color: #666; }
          .value { color: #333; }
          .footer { color: #999; font-size: 12px; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h2>New Car Inquiry</h2>
            <p>You have received a new inquiry for your car listing</p>
          </div>

          <div class="section">
            <div class="section-title">CAR DETAILS</div>
            <div class="info-row">
              <span class="label">Listing:</span>
              <span class="value">${options.carYear} ${options.carBrand} ${options.carModel} (ID: ${options.carId})</span>
            </div>
          </div>

          <div class="section">
            <div class="section-title">BUYER INFORMATION</div>
            <div class="info-row">
              <span class="label">Name:</span>
              <span class="value">${options.buyerName}</span>
            </div>
            <div class="info-row">
              <span class="label">Email:</span>
              <span class="value"><a href="mailto:${options.buyerEmail}">${options.buyerEmail}</a></span>
            </div>
            <div class="info-row">
              <span class="label">Phone:</span>
              <span class="value">${options.buyerPhone}</span>
            </div>
          </div>

          ${
            options.additionalNotes
              ? `
          <div class="section">
            <div class="section-title">MESSAGE</div>
            <div class="info-row">
              <span class="value">${options.additionalNotes.replace(/\n/g, "<br>")}</span>
            </div>
          </div>
          `
              : ""
          }

          <div class="footer">
            <p>This is an automated email from Lebanese Auto Hub. Please reply directly to the buyer's email address.</p>
          </div>
        </div>
      </body>
    </html>
  `;
}
