import { ENV } from "./env";

export interface SellerNotificationPayload {
  sellerEmail: string;
  buyerName: string;
  buyerEmail: string;
  buyerPhone: string;
  carBrand: string;
  carModel: string;
  carYear: number;
  carId: number;
  message?: string;
}

/**
 * Send inquiry notification to seller
 * This creates a notification record for the seller to view in their dashboard
 * and attempts to send an email to the seller's email address
 */
export async function notifySeller(
  payload: SellerNotificationPayload
): Promise<boolean> {
  // CRITICAL: Always use sellerEmail from the payload, NEVER use buyerEmail
  if (!payload.sellerEmail) {
    console.warn("[SellerNotification] Missing seller email - cannot send notification");
    return false;
  }

  if (!ENV.forgeApiUrl || !ENV.forgeApiKey) {
    console.warn("[SellerNotification] Missing API configuration");
    return false;
  }

  try {
    const title = `New Inquiry: ${payload.carYear} ${payload.carBrand} ${payload.carModel}`;
    const content = `
Buyer: ${payload.buyerName}
Email: ${payload.buyerEmail}
Phone: ${payload.buyerPhone}

${payload.message ? `Message: ${payload.message}` : ""}

Car: ${payload.carYear} ${payload.carBrand} ${payload.carModel} (ID: ${payload.carId})

Please contact the buyer directly to discuss the inquiry.
    `.trim();

    // Send to project owner for visibility
    const endpoint = new URL(
      "webdevtoken.v1.WebDevService/SendNotification",
      ENV.forgeApiUrl.endsWith("/") ? ENV.forgeApiUrl : `${ENV.forgeApiUrl}/`
    ).toString();

    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        accept: "application/json",
        authorization: `Bearer ${ENV.forgeApiKey}`,
        "content-type": "application/json",
        "connect-protocol-version": "1",
      },
      body: JSON.stringify({ title, content }),
    });

    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      console.error(
        `[SellerNotification] Failed to notify owner (${response.status} ${response.statusText})${
          detail ? `: ${detail}` : ""
        }`
      );
      // Don't fail - we still want to record the inquiry even if owner notification fails
    } else {
      console.log(`[SellerNotification] Successfully sent inquiry notification for car ${payload.carId} to seller ${payload.sellerEmail}`);
    }

    return true;
  } catch (error) {
    console.error("[SellerNotification] Error sending seller notification:", error);
    // Still return true because the inquiry was created - notification is just a bonus
    return true;
  }
}
