import "dotenv/config";
import express, { Request, Response } from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import multer from "multer";
import * as db from "../db";
import { storagePut } from "../storage";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.use(express.static('public'));
  // OAuth callback under /api/oauth/callback
  registerOAuthRoutes(app);
  
  // Configure multer for file uploads
  const upload = multer({ storage: multer.memoryStorage() });
  
  // Image upload endpoint for car listings
  app.post("/api/upload-car-images", upload.array("images", 8), async (req: Request, res: Response) => {
    try {
      const carId = parseInt(req.body.carId);
      const files = req.files as Express.Multer.File[] | undefined;
      
      if (!carId || !files || files.length === 0) {
        return res.status(400).json({ error: "Missing carId or images" });
      }
      
      // Upload each image to S3 and save to database
      const uploadedImages = [];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const fileKey = `cars/${carId}/image-${Date.now()}-${i}.${file.mimetype.split("/")[1]}`;
        
        try {
          const { url } = await storagePut(fileKey, file.buffer, file.mimetype);
          
          // Save to database
          await db.addCarImage({
            carId,
            imageUrl: url,
            imageKey: fileKey,
            isPrimary: i === 0,
            order: i,
          });
          
          uploadedImages.push({ url, imageKey: fileKey });
        } catch (error) {
          console.error(`Failed to upload image ${i}:`, error);
        }
      }
      
      res.json({ success: true, uploadedImages });
    } catch (error) {
      console.error("Image upload error:", error);
      res.status(500).json({ error: "Failed to upload images" });
    }
  });
  
  // Image upload endpoint for valuation
  app.post("/api/upload-valuation-images", upload.array("images", 5), async (req: Request, res: Response) => {
    try {
      const files = req.files as Express.Multer.File[] | undefined;
      
      if (!files || files.length === 0) {
        return res.status(400).json({ error: "No images provided" });
      }
      
      // Upload each image to S3 and return URLs
      const imageUrls = [];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const fileKey = `valuations/temp-${Date.now()}-${i}.${file.mimetype.split("/")[1]}`;
        
        try {
          const { url } = await storagePut(fileKey, file.buffer, file.mimetype);
          imageUrls.push(url);
        } catch (error) {
          console.error(`Failed to upload valuation image ${i}:`, error);
        }
      }
      
      res.json({ success: true, imageUrls });
    } catch (error) {
      console.error("Valuation image upload error:", error);
      res.status(500).json({ error: "Failed to upload images" });
    }
  });
  
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
