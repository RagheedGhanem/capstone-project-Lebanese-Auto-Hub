import { eq, and, or, gte, lte, like, desc, sql, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users, 
  cars, InsertCar, Car,
  dealers, InsertDealer, Dealer,
  carImages, InsertCarImage, CarImage,
  inquiries, InsertInquiry, Inquiry,
  valuations, InsertValuation, Valuation,
  tradeInRecommendations, InsertTradeInRecommendation, TradeInRecommendation,
  chatConversations, InsertChatConversation, ChatConversation,
  chatMessages, InsertChatMessage, ChatMessage,
  favorites, InsertFavorite, Favorite
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============= USER FUNCTIONS =============

export async function upsertUser(user: InsertUser): Promise<void> {
  // Support both OAuth (with openId) and manual auth (with email/password)
  if (!user.openId && !user.email) {
    throw new Error("Either openId or email is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {};
    const updateSet: Record<string, unknown> = {};

    // Set openId if provided (OAuth users)
    if (user.openId) {
      values.openId = user.openId;
    }

    const textFields = ["name", "email", "loginMethod", "passwordHash"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============= CAR FUNCTIONS =============

export async function createCar(car: InsertCar) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(cars).values(car);
  return result[0].insertId;
}

export async function getCarById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(cars).where(eq(cars.id, id)).limit(1);
  return result[0];
}

export async function getCars(filters?: {
  brand?: string;
  model?: string;
  carType?: string;
  year?: number;
  minYear?: number;
  maxYear?: number;
  color?: string;
  minPrice?: number;
  maxPrice?: number;
  status?: string;
}) {
  return getAllCars(filters);
}

export async function getAllCars(filters?: {
  brand?: string;
  model?: string;
  carType?: string;
  year?: number;
  minYear?: number;
  maxYear?: number;
  color?: string;
  minPrice?: number;
  maxPrice?: number;
  status?: string;
}) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(cars);
  const conditions = [];

  if (filters?.brand) conditions.push(like(cars.brand, `%${filters.brand}%`));
  if (filters?.model) conditions.push(like(cars.model, `%${filters.model}%`));
  if (filters?.carType) conditions.push(like(cars.carType, `%${filters.carType}%`));
  if (filters?.year) conditions.push(eq(cars.year, filters.year));
  if (filters?.minYear) conditions.push(gte(cars.year, filters.minYear));
  if (filters?.maxYear) conditions.push(lte(cars.year, filters.maxYear));
  if (filters?.color) conditions.push(like(cars.color, `%${filters.color}%`));
  if (filters?.minPrice) conditions.push(gte(cars.price, filters.minPrice.toString()));
  if (filters?.maxPrice) conditions.push(lte(cars.price, filters.maxPrice.toString()));
  if (filters?.status) conditions.push(eq(cars.status, filters.status as any));

  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }

  return await query.orderBy(desc(cars.createdAt));
}

export async function updateCar(id: number, updates: Partial<InsertCar>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(cars).set(updates).where(eq(cars.id, id));
}

export async function deleteCar(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(cars).where(eq(cars.id, id));
}

// ============= CAR IMAGE FUNCTIONS =============

export async function addCarImage(image: InsertCarImage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(carImages).values(image);
}

export async function getCarImages(carId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(carImages).where(eq(carImages.carId, carId)).orderBy(carImages.order);
}

export async function deleteCarImage(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(carImages).where(eq(carImages.id, id));
}

// ============= DEALER FUNCTIONS =============

export async function createDealer(dealer: InsertDealer) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(dealers).values(dealer);
  return result[0].insertId;
}

export async function getAllDealers(activeOnly: boolean = true) {
  const db = await getDb();
  if (!db) return [];
  
  let query = db.select().from(dealers);
  
  if (activeOnly) {
    query = query.where(eq(dealers.isActive, true)) as any;
  }
  
  return await query.orderBy(dealers.name);
}

export async function getDealerById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(dealers).where(eq(dealers.id, id)).limit(1);
  return result[0];
}

export async function updateDealer(id: number, updates: Partial<InsertDealer>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(dealers).set(updates).where(eq(dealers.id, id));
}

// ============= INQUIRY FUNCTIONS =============

export async function createInquiry(inquiry: InsertInquiry) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(inquiries).values(inquiry);
  return result[0].insertId;
}

export async function getAllInquiries() {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(inquiries).orderBy(desc(inquiries.createdAt));
}

export async function getInquiryById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(inquiries).where(eq(inquiries.id, id)).limit(1);
  return result[0];
}

export async function updateInquiryStatus(id: number, status: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(inquiries).set({ status: status as any }).where(eq(inquiries.id, id));
}

// ============= VALUATION FUNCTIONS =============

export async function createValuation(valuation: InsertValuation) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(valuations).values(valuation);
  return result[0].insertId;
}

export async function getValuationById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(valuations).where(eq(valuations.id, id)).limit(1);
  return result[0];
}

export async function getUserValuations(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(valuations).where(eq(valuations.userId, userId)).orderBy(desc(valuations.createdAt));
}

// ============= TRADE-IN RECOMMENDATION FUNCTIONS =============

export async function createTradeInRecommendation(recommendation: InsertTradeInRecommendation) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(tradeInRecommendations).values(recommendation);
}

export async function getTradeInRecommendations(valuationId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(tradeInRecommendations).where(eq(tradeInRecommendations.valuationId, valuationId));
}

// ============= CHAT FUNCTIONS =============

export async function createChatConversation(conversation: InsertChatConversation) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(chatConversations).values(conversation);
  return result[0].insertId;
}

export async function getChatConversation(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(chatConversations).where(eq(chatConversations.id, id)).limit(1);
  return result[0];
}

export async function getChatConversationBySessionId(sessionId: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(chatConversations).where(eq(chatConversations.sessionId, sessionId)).limit(1);
  return result[0];
}

export async function addChatMessage(message: InsertChatMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(chatMessages).values(message);
}

export async function getChatMessages(conversationId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(chatMessages).where(eq(chatMessages.conversationId, conversationId)).orderBy(chatMessages.createdAt);
}

export async function updateChatConversationStatus(id: number, status: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(chatConversations).set({ status: status as any }).where(eq(chatConversations.id, id));
}


// ============= EMAIL/PASSWORD AUTHENTICATION =============

import { hashPassword, comparePassword } from "./auth-utils";

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return result[0];
}

export async function createUserWithPassword(email: string, name: string, password: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const passwordHash = await hashPassword(password);
  
  const result = await db.insert(users).values({
    email,
    name,
    passwordHash,
    loginMethod: "email",
    role: "user",
  });
  
  return result[0].insertId;
}

export async function verifyUserPassword(email: string, password: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  const user = await getUserByEmail(email);
  if (!user || !user.passwordHash) return undefined;
  
  const isValid = await comparePassword(password, user.passwordHash);
  if (!isValid) return undefined;
  
  // Update lastSignedIn
  await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, user.id));
  
  // Return user without password hash
  const { passwordHash, ...userWithoutPassword } = user;
  return userWithoutPassword;
}


export async function updateUserPassword(userId: number, newPassword: string) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const { hashPassword } = await import("./auth-utils");
  const passwordHash = await hashPassword(newPassword);

  await db.update(users).set({ passwordHash }).where(eq(users.id, userId));
}


// ============= MY LISTINGS FUNCTIONS =============

export async function getMyListings(userId: number): Promise<Car[]> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const listings = await db.select().from(cars).where(eq(cars.userId, userId));
  return listings;
}

export async function updateMyListing(carId: number, userId: number, updates: Partial<Car>): Promise<Car | undefined> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // Verify the car belongs to the user
  const car = await db.select().from(cars).where(eq(cars.id, carId));
  if (!car || car.length === 0 || car[0].userId !== userId) {
    throw new Error("Unauthorized: Car does not belong to this user");
  }

  // Update the car
  await db.update(cars).set(updates).where(eq(cars.id, carId));

  // Return updated car
  const updated = await db.select().from(cars).where(eq(cars.id, carId));
  return updated[0];
}

export async function deleteMyListing(carId: number, userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // Verify the car belongs to the user
  const car = await db.select().from(cars).where(eq(cars.id, carId));
  if (!car || car.length === 0 || car[0].userId !== userId) {
    throw new Error("Unauthorized: Car does not belong to this user");
  }

  // Delete associated images first
  await db.delete(carImages).where(eq(carImages.carId, carId));

  // Delete the car
  await db.delete(cars).where(eq(cars.id, carId));

  return true;
}

// ============= MY FAVORITES FUNCTIONS =============

export async function addFavorite(userId: number, carId: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // Check if already favorited
  const existing = await db.select().from(favorites).where(
    and(eq(favorites.userId, userId), eq(favorites.carId, carId))
  );

  if (existing && existing.length > 0) {
    return; // Already favorited
  }

  // Add favorite
  await db.insert(favorites).values({ userId, carId });
}

export async function removeFavorite(userId: number, carId: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.delete(favorites).where(
    and(eq(favorites.userId, userId), eq(favorites.carId, carId))
  );
}

export async function getMyFavorites(userId: number): Promise<Car[]> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const favoriteRecords = await db.select().from(favorites).where(eq(favorites.userId, userId));
  const carIds = favoriteRecords.map(f => f.carId);

  if (carIds.length === 0) {
    return [];
  }

  const favoriteCars = await db.select().from(cars).where(inArray(cars.id, carIds));
  return favoriteCars;
}

export async function isFavorited(userId: number, carId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const favorite = await db.select().from(favorites).where(
    and(eq(favorites.userId, userId), eq(favorites.carId, carId))
  );

  return favorite && favorite.length > 0;
}


// ============= SELLER INQUIRIES FUNCTIONS =============

export async function getSellerInquiries(userId: number): Promise<(Inquiry & { carDetails?: Car })[]> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // Get all cars owned by this user
  const userCars = await db.select().from(cars).where(eq(cars.userId, userId));
  const carIds = userCars.map(c => c.id);

  if (carIds.length === 0) {
    return [];
  }

  // Get all inquiries for those cars
  const inquiriesList = await db.select().from(inquiries).where(inArray(inquiries.carId, carIds)).orderBy(desc(inquiries.createdAt));
  
  // Enrich inquiries with car details
  const enrichedInquiries = inquiriesList.map(inquiry => {
    const carDetail = userCars.find(c => c.id === inquiry.carId);
    return {
      ...inquiry,
      carDetails: carDetail,
    };
  });

  return enrichedInquiries;
}


// ============= ADMIN FUNCTIONS =============

export async function getAllUsers() {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const allUsers = await db.select().from(users).orderBy(desc(users.createdAt));
  
  // Remove sensitive data
  return allUsers.map(user => ({
    ...user,
    passwordHash: undefined, // Don't expose password hashes
  }));
}

export async function deleteUser(userId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.delete(users).where(eq(users.id, userId));
}

export async function updateUserRole(userId: number, role: "user" | "admin") {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.update(users).set({ role }).where(eq(users.id, userId));
}

export async function deleteCarListing(carId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // Delete associated images first
  await db.delete(carImages).where(eq(carImages.carId, carId));
  
  // Delete the car
  await db.delete(cars).where(eq(cars.id, carId));
}

export async function searchCarsByPreferences(preferences: {
  brands?: string[];
  models?: string[];
  minYear?: number;
  maxYear?: number;
  minPrice?: number;
  maxPrice?: number;
  maxMileage?: number;
  carTypes?: string[];
  transmissions?: string[];
  fuelTypes?: string[];
  colors?: string[];
  sellerLocations?: string[];
  limit?: number;
}) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(cars);
  const conditions: any[] = [];
  
  // Always filter by available status
  conditions.push(eq(cars.status, 'available'));
  
  // Use case-insensitive matching for brands
  if (preferences.brands && preferences.brands.length > 0) {
    const brandConditions = preferences.brands.map(brand => 
      like(cars.brand, `%${brand}%`)
    );
    if (brandConditions.length === 1) {
      conditions.push(brandConditions[0]);
    } else {
      conditions.push(or(...brandConditions));
    }
  }

  // Use case-insensitive matching for models
  if (preferences.models && preferences.models.length > 0) {
    const modelConditions = preferences.models.map(model => 
      like(cars.model, `%${model}%`)
    );
    if (modelConditions.length === 1) {
      conditions.push(modelConditions[0]);
    } else {
      conditions.push(or(...modelConditions));
    }
  }

  if (preferences.minYear !== undefined) {
    conditions.push(gte(cars.year, preferences.minYear));
  }

  if (preferences.maxYear !== undefined) {
    conditions.push(lte(cars.year, preferences.maxYear));
  }

  if (preferences.minPrice !== undefined) {
    conditions.push(gte(cars.price, preferences.minPrice.toString()));
  }

  if (preferences.maxPrice !== undefined) {
    conditions.push(lte(cars.price, preferences.maxPrice.toString()));
  }

  if (preferences.maxMileage !== undefined) {
    conditions.push(lte(cars.kilometers, preferences.maxMileage));
  }

  // Use case-insensitive matching for car types
  if (preferences.carTypes && preferences.carTypes.length > 0) {
    const typeConditions = preferences.carTypes.map(type => 
      like(cars.carType, `%${type}%`)
    );
    if (typeConditions.length === 1) {
      conditions.push(typeConditions[0]);
    } else {
      conditions.push(or(...typeConditions));
    }
  }

  // Use case-insensitive matching for transmissions
  if (preferences.transmissions && preferences.transmissions.length > 0) {
    const transmissionConditions = preferences.transmissions.map(trans => 
      like(cars.transmission, `%${trans}%`)
    );
    if (transmissionConditions.length === 1) {
      conditions.push(transmissionConditions[0]);
    } else {
      conditions.push(or(...transmissionConditions));
    }
  }

  // Use case-insensitive matching for fuel types
  if (preferences.fuelTypes && preferences.fuelTypes.length > 0) {
    const fuelConditions = preferences.fuelTypes.map(fuel => 
      like(cars.fuelType, `%${fuel}%`)
    );
    if (fuelConditions.length === 1) {
      conditions.push(fuelConditions[0]);
    } else {
      conditions.push(or(...fuelConditions));
    }
  }

  // Use case-insensitive matching for colors
  if (preferences.colors && preferences.colors.length > 0) {
    const colorConditions = preferences.colors.map(color => 
      like(cars.color, `%${color}%`)
    );
    if (colorConditions.length === 1) {
      conditions.push(colorConditions[0]);
    } else {
      conditions.push(or(...colorConditions));
    }
  }

  // Use case-insensitive matching for seller locations
  if (preferences.sellerLocations && preferences.sellerLocations.length > 0) {
    const locationConditions = preferences.sellerLocations.map(location => 
      like(cars.sellerLocation, `%${location}%`)
    );
    if (locationConditions.length === 1) {
      conditions.push(locationConditions[0]);
    } else {
      conditions.push(or(...locationConditions));
    }
  }

  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }

  const limit = preferences.limit || 10;
  const results = await query.limit(limit).orderBy(desc(cars.createdAt));

  return results;
}


