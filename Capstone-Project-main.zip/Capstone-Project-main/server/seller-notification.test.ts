import { describe, it, expect, vi, beforeEach } from "vitest";
import { notifySeller } from "./_core/seller-notification";

// Mock fetch
global.fetch = vi.fn();

describe("Seller Notification Service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should successfully send seller notification", async () => {
    (global.fetch as any).mockResolvedValueOnce({
      ok: true,
      status: 200,
      text: async () => "",
    });

    const result = await notifySeller({
      sellerEmail: "seller@example.com",
      buyerName: "John Doe",
      buyerEmail: "buyer@example.com",
      buyerPhone: "+961-1-234567",
      carBrand: "BMW",
      carModel: "X5",
      carYear: 2022,
      carId: 1,
      message: "I'm interested in this car",
    });

    expect(result).toBe(true);
    expect(global.fetch).toHaveBeenCalled();
  });

  it("should handle API errors gracefully", async () => {
    (global.fetch as any).mockResolvedValueOnce({
      ok: false,
      status: 500,
      statusText: "Internal Server Error",
      text: async () => "Server error",
    });

    const result = await notifySeller({
      sellerEmail: "seller@example.com",
      buyerName: "John Doe",
      buyerEmail: "buyer@example.com",
      buyerPhone: "+961-1-234567",
      carBrand: "BMW",
      carModel: "X5",
      carYear: 2022,
      carId: 1,
      message: "I'm interested in this car",
    });

    expect(result).toBe(false);
  });

  it("should handle network errors gracefully", async () => {
    (global.fetch as any).mockRejectedValueOnce(new Error("Network error"));

    const result = await notifySeller({
      sellerEmail: "seller@example.com",
      buyerName: "John Doe",
      buyerEmail: "buyer@example.com",
      buyerPhone: "+961-1-234567",
      carBrand: "BMW",
      carModel: "X5",
      carYear: 2022,
      carId: 1,
      message: "I'm interested in this car",
    });

    expect(result).toBe(false);
  });

  it("should include all required information in notification", async () => {
    (global.fetch as any).mockResolvedValueOnce({
      ok: true,
      status: 200,
      text: async () => "",
    });

    await notifySeller({
      sellerEmail: "seller@example.com",
      buyerName: "John Doe",
      buyerEmail: "buyer@example.com",
      buyerPhone: "+961-1-234567",
      carBrand: "BMW",
      carModel: "X5",
      carYear: 2022,
      carId: 1,
      message: "I'm interested in this car",
    });

    const callArgs = (global.fetch as any).mock.calls[0];
    const body = JSON.parse(callArgs[1].body);

    expect(body.title).toContain("2022 BMW X5");
    expect(body.content).toContain("John Doe");
    expect(body.content).toContain("buyer@example.com");
    expect(body.content).toContain("+961-1-234567");
  });

  it("should work without optional message", async () => {
    (global.fetch as any).mockResolvedValueOnce({
      ok: true,
      status: 200,
      text: async () => "",
    });

    const result = await notifySeller({
      sellerEmail: "seller@example.com",
      buyerName: "John Doe",
      buyerEmail: "buyer@example.com",
      buyerPhone: "+961-1-234567",
      carBrand: "BMW",
      carModel: "X5",
      carYear: 2022,
      carId: 1,
    });

    expect(result).toBe(true);
  });
});
