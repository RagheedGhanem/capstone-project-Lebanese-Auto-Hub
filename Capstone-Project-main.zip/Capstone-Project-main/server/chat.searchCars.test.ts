import { describe, it, expect, beforeAll, afterAll, vi } from "vitest";
import { appRouter } from "./routers";
import * as db from "./db";
import { invokeLLM } from "./_core/llm";

// Mock the LLM
vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn(),
}));

// Mock database functions
vi.mock("./db", async () => {
  const actual = await vi.importActual("./db");
  return {
    ...actual,
    searchCarsByPreferences: vi.fn(),
  };
});

describe("chat.searchCars", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(async () => {
    caller = appRouter.createCaller({
      user: null,
      req: {} as any,
      res: {} as any,
    });
  });

  it.skip("should extract car preferences from natural language and search database", async () => {
    // Mock LLM response with extracted preferences
    const mockLLMResponse = {
      choices: [
        {
          message: {
            content: JSON.stringify({
              brands: ["BMW"],
              carTypes: ["sedan"],
              maxPrice: 30000,
              maxYear: 2024,
            }),
          },
        },
      ],
    };

    vi.mocked(invokeLLM).mockResolvedValueOnce(mockLLMResponse as any);

    // Mock database search results
    const mockCars = [
      {
        id: 1,
        brand: "BMW",
        model: "3 Series",
        year: 2023,
        price: "28000",
        kilometers: 15000,
        transmission: "automatic",
        fuelType: "diesel",
        condition: "excellent",
        sellerName: "John Doe",
        sellerPhone: "961-1234567",
        sellerEmail: "john@example.com",
        sellerLocation: "Beirut",
        carType: "sedan",
        color: "black",
        description: "Well maintained BMW",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    vi.mocked(db.searchCarsByPreferences).mockResolvedValueOnce(mockCars as any);

    // Call the procedure
    const result = await caller.chat.searchCars({
      userQuery: "I want a red BMW sedan under $30,000",
      conversationHistory: [],
    });

    // Verify the result
    expect(result).toBeDefined();
    expect(result.message).toBeDefined();
    expect(result.message).toContain("BMW");
    expect(result.message).toContain("3 Series");

    // Verify LLM was called to extract preferences
    expect(invokeLLM).toHaveBeenCalled();

    // Verify database search was called
    expect(db.searchCarsByPreferences).toHaveBeenCalled();
  });

  it.skip("should handle case when no cars are found", async () => {
    // Mock LLM response
    const mockLLMResponse = {
      choices: [
        {
          message: {
            content: JSON.stringify({
              brands: ["Ferrari"],
              maxPrice: 50000,
            }),
          },
        },
      ],
    };

    vi.mocked(invokeLLM).mockResolvedValueOnce(mockLLMResponse as any);

    // Mock empty database search results
    vi.mocked(db.searchCarsByPreferences).mockResolvedValueOnce([]);

    // Call the procedure
    const result = await caller.chat.searchCars({
      userQuery: "Find me a Ferrari under $50,000",
      conversationHistory: [],
    });

    // Verify the result
    expect(result).toBeDefined();
    expect(result.message).toContain("couldn't find");
    expect(result.listings).toEqual([]);
  });

  it.skip("should extract multiple car preferences correctly", async () => {
    // Mock LLM response with multiple preferences
    const mockLLMResponse = {
      choices: [
        {
          message: {
            content: JSON.stringify({
              brands: ["Toyota", "Honda"],
              carTypes: ["SUV"],
              minYear: 2020,
              maxYear: 2024,
              minPrice: 15000,
              maxPrice: 35000,
              colors: ["white", "black"],
            }),
          },
        },
      ],
    };

    vi.mocked(invokeLLM).mockResolvedValueOnce(mockLLMResponse as any);

    // Mock database search results
    const mockCars = [
      {
        id: 1,
        brand: "Toyota",
        model: "RAV4",
        year: 2022,
        price: "25000",
        kilometers: 20000,
        transmission: "automatic",
        fuelType: "gasoline",
        condition: "good",
        sellerName: "Jane Smith",
        sellerPhone: "961-9876543",
        sellerEmail: "jane@example.com",
        sellerLocation: "Tripoli",
        carType: "SUV",
        color: "white",
        description: "Reliable SUV",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: 2,
        brand: "Honda",
        model: "CR-V",
        year: 2021,
        price: "28000",
        kilometers: 30000,
        transmission: "automatic",
        fuelType: "gasoline",
        condition: "good",
        sellerName: "Ahmed Hassan",
        sellerPhone: "961-5555555",
        sellerEmail: "ahmed@example.com",
        sellerLocation: "Sidon",
        carType: "SUV",
        color: "black",
        description: "Well maintained CR-V",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    vi.mocked(db.searchCarsByPreferences).mockResolvedValueOnce(mockCars as any);

    // Call the procedure
    const result = await caller.chat.searchCars({
      userQuery: "I'm looking for a Toyota or Honda SUV between 2020 and 2024, white or black, under $35,000",
      conversationHistory: [],
    });

    // Verify the result
    expect(result).toBeDefined();
    expect(result.message).toContain("2");
    expect(result.message).toContain("RAV4");
    expect(result.message).toContain("CR-V");
  });

  it.skip("should format car listings with all required details", async () => {
    // Mock LLM response
    const mockLLMResponse = {
      choices: [
        {
          message: {
            content: JSON.stringify({
              brands: ["Mercedes"],
              carTypes: ["sedan"],
            }),
          },
        },
      ],
    };

    vi.mocked(invokeLLM).mockResolvedValueOnce(mockLLMResponse as any);

    // Mock database search results
    const mockCars = [
      {
        id: 1,
        brand: "Mercedes",
        model: "C-Class",
        year: 2023,
        price: "45000",
        kilometers: 5000,
        transmission: "automatic",
        fuelType: "diesel",
        condition: "excellent",
        sellerName: "Luxury Cars Ltd",
        sellerPhone: "961-1111111",
        sellerEmail: "luxury@example.com",
        sellerLocation: "Beirut",
        carType: "sedan",
        color: "silver",
        description: "Pristine condition Mercedes",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    vi.mocked(db.searchCarsByPreferences).mockResolvedValueOnce(mockCars as any);

    // Call the procedure
    const result = await caller.chat.searchCars({
      userQuery: "Show me luxury sedans",
      conversationHistory: [],
    });

    // Verify the result contains all required details
    expect(result.message).toContain("2023");
    expect(result.message).toContain("Mercedes");
    expect(result.message).toContain("C-Class");
    expect(result.message).toContain("45000");
    expect(result.message).toContain("5000");
    expect(result.message).toContain("automatic");
    expect(result.message).toContain("diesel");
    expect(result.message).toContain("excellent");
    expect(result.message).toContain("Luxury Cars Ltd");
    expect(result.message).toContain("Beirut");
  });

  it.skip("should handle LLM errors gracefully", async () => {
    // Mock LLM error
    vi.mocked(invokeLLM).mockRejectedValueOnce(new Error("LLM service unavailable"));

    // Call the procedure - should throw or handle gracefully
    try {
      await caller.chat.searchCars({
        userQuery: "Find me a car",
        conversationHistory: [],
      });
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it.skip("should limit results to 5 cars maximum", async () => {
    // Mock LLM response
    const mockLLMResponse = {
      choices: [
        {
          message: {
            content: JSON.stringify({
              brands: ["Toyota"],
            }),
          },
        },
      ],
    };

    vi.mocked(invokeLLM).mockResolvedValueOnce(mockLLMResponse as any);

    // Mock database search results with many cars
    const mockCars = Array.from({ length: 10 }, (_, i) => ({
      id: i + 1,
      brand: "Toyota",
      model: `Model ${i + 1}`,
      year: 2023,
      price: "20000",
      kilometers: 10000,
      transmission: "automatic",
      fuelType: "gasoline",
      condition: "good",
      sellerName: `Seller ${i + 1}`,
      sellerPhone: "961-1234567",
      sellerEmail: `seller${i}@example.com`,
      sellerLocation: "Beirut",
      carType: "sedan",
      color: "white",
      description: "Toyota car",
      createdAt: new Date(),
      updatedAt: new Date(),
    }));

    vi.mocked(db.searchCarsByPreferences).mockResolvedValueOnce(mockCars as any);

    // Call the procedure
    const result = await caller.chat.searchCars({
      userQuery: "Show me all Toyota cars",
      conversationHistory: [],
    });

    // Verify the result
    expect(result).toBeDefined();
    // The response should mention the number of cars found
    expect(result.message).toContain("10");
  });
});
