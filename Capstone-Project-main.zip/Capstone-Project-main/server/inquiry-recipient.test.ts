import { describe, it, expect, vi, beforeEach } from "vitest";
import { notifySeller } from "./_core/seller-notification";

// Mock fetch
global.fetch = vi.fn();

describe("Inquiry Email Recipient Validation", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should use sellerEmail as recipient, not buyerEmail", async () => {
    (global.fetch as any).mockResolvedValueOnce({
      ok: true,
      status: 200,
      text: async () => "",
    });

    const sellerEmail = "seller@example.com";
    const buyerEmail = "buyer@example.com";

    // These should be different
    expect(sellerEmail).not.toBe(buyerEmail);

    const result = await notifySeller({
      sellerEmail,
      buyerName: "John Buyer",
      buyerEmail,
      buyerPhone: "+961-1-234567",
      carBrand: "BMW",
      carModel: "X5",
      carYear: 2022,
      carId: 1,
      message: "I'm interested",
    });

    expect(result).toBe(true);
  });

  it("should reject if sellerEmail is missing", async () => {
    const result = await notifySeller({
      sellerEmail: "", // Empty seller email
      buyerName: "John Buyer",
      buyerEmail: "buyer@example.com",
      buyerPhone: "+961-1-234567",
      carBrand: "BMW",
      carModel: "X5",
      carYear: 2022,
      carId: 1,
    });

    expect(result).toBe(false);
  });

  it("should work when sellerEmail and buyerEmail are different (Google user)", async () => {
    (global.fetch as any).mockResolvedValueOnce({
      ok: true,
      status: 200,
      text: async () => "",
    });

    const result = await notifySeller({
      sellerEmail: "seller@gmail.com", // Google seller
      buyerName: "John Buyer",
      buyerEmail: "buyer@hotmail.com", // Different buyer
      buyerPhone: "+961-1-234567",
      carBrand: "BMW",
      carModel: "X5",
      carYear: 2022,
      carId: 1,
    });

    expect(result).toBe(true);
  });

  it("should work when sellerEmail and buyerEmail are different (manual signup)", async () => {
    (global.fetch as any).mockResolvedValueOnce({
      ok: true,
      status: 200,
      text: async () => "",
    });

    const result = await notifySeller({
      sellerEmail: "seller@example.com", // Manual signup seller
      buyerName: "Jane Buyer",
      buyerEmail: "jane@buyer.com", // Different buyer
      buyerPhone: "+961-1-555555",
      carBrand: "Mercedes",
      carModel: "C-Class",
      carYear: 2023,
      carId: 2,
    });

    expect(result).toBe(true);
  });

  it("should still work even if sellerEmail accidentally matches buyerEmail", async () => {
    (global.fetch as any).mockResolvedValueOnce({
      ok: true,
      status: 200,
      text: async () => "",
    });

    // Edge case: same email (should still work, just send to that email)
    const sameEmail = "same@example.com";

    const result = await notifySeller({
      sellerEmail: sameEmail,
      buyerName: "John",
      buyerEmail: sameEmail,
      buyerPhone: "+961-1-234567",
      carBrand: "BMW",
      carModel: "X5",
      carYear: 2022,
      carId: 1,
    });

    expect(result).toBe(true);
  });

  it("should include all buyer contact info in notification content", async () => {
    (global.fetch as any).mockResolvedValueOnce({
      ok: true,
      status: 200,
      text: async () => "",
    });

    const buyerName = "John Buyer";
    const buyerEmail = "john@buyer.com";
    const buyerPhone = "+961-1-234567";

    await notifySeller({
      sellerEmail: "seller@example.com",
      buyerName,
      buyerEmail,
      buyerPhone,
      carBrand: "BMW",
      carModel: "X5",
      carYear: 2022,
      carId: 1,
      message: "Very interested in this car",
    });

    const callArgs = (global.fetch as any).mock.calls[0];
    const body = JSON.parse(callArgs[1].body);

    // Verify buyer contact info is in the content
    expect(body.content).toContain(buyerName);
    expect(body.content).toContain(buyerEmail);
    expect(body.content).toContain(buyerPhone);
  });
});
