import { describe, it, expect, beforeAll } from "vitest";
import * as db from "./db";

describe("Car Features Display (Transmission, Fuel Type, Engine Size)", () => {
  let testUserId: number;
  let testCarId: number;

  beforeAll(async () => {
    // Create a test user
    await db.upsertUser({
      email: "car-features-test@example.com",
      name: "Car Features Test User",
      loginMethod: "manual",
    });

    const testUser = await db.getUserByEmail("car-features-test@example.com");
    testUserId = testUser?.id || 0;

    // Create a test car with all features
    const carResult = await db.createCar({
      userId: testUserId,
      brand: "Toyota",
      model: "Camry",
      carType: "Sedan",
      year: 2023,
      color: "Silver",
      price: "35000",
      transmission: "Automatic",
      fuelType: "Gasoline",
      engineSize: "2.5L",
      kilometers: 5000,
      condition: "excellent",
      description: "Well-maintained sedan",
      sellerName: "Test Seller",
      sellerPhone: "+961123456",
      sellerEmail: "seller@example.com",
      sellerLocation: "Beirut",
    });

    testCarId = carResult || 0;
  });

  describe("Create Car with Features", () => {
    it("should save transmission field", async () => {
      const car = await db.getCarById(testCarId);
      expect(car).toBeDefined();
      expect(car?.transmission).toBe("Automatic");
    });

    it("should save fuelType field", async () => {
      const car = await db.getCarById(testCarId);
      expect(car).toBeDefined();
      expect(car?.fuelType).toBe("Gasoline");
    });

    it("should save engineSize field", async () => {
      const car = await db.getCarById(testCarId);
      expect(car).toBeDefined();
      expect(car?.engineSize).toBe("2.5L");
    });

    it("should retrieve all car features together", async () => {
      const car = await db.getCarById(testCarId);
      expect(car).toBeDefined();
      expect(car?.transmission).toBe("Automatic");
      expect(car?.fuelType).toBe("Gasoline");
      expect(car?.engineSize).toBe("2.5L");
      expect(car?.brand).toBe("Toyota");
      expect(car?.model).toBe("Camry");
    });
  });

  describe("Update Car Features", () => {
    it("should update transmission", async () => {
      await db.updateMyListing(testCarId, testUserId, {
        transmission: "Manual",
      });

      const car = await db.getCarById(testCarId);
      expect(car?.transmission).toBe("Manual");
    });

    it("should update fuelType", async () => {
      await db.updateMyListing(testCarId, testUserId, {
        fuelType: "Diesel",
      });

      const car = await db.getCarById(testCarId);
      expect(car?.fuelType).toBe("Diesel");
    });

    it("should update engineSize", async () => {
      await db.updateMyListing(testCarId, testUserId, {
        engineSize: "3.0L",
      });

      const car = await db.getCarById(testCarId);
      expect(car?.engineSize).toBe("3.0L");
    });

    it("should update multiple features at once", async () => {
      await db.updateMyListing(testCarId, testUserId, {
        transmission: "Automatic",
        fuelType: "Hybrid",
        engineSize: "2.0L",
      });

      const car = await db.getCarById(testCarId);
      expect(car?.transmission).toBe("Automatic");
      expect(car?.fuelType).toBe("Hybrid");
      expect(car?.engineSize).toBe("2.0L");
    });
  });

  describe("List Cars with Features", () => {
    it("should include features in getAllCars", async () => {
      const cars = await db.getAllCars();
      const testCar = cars.find((c: any) => c.id === testCarId);
      
      expect(testCar).toBeDefined();
      expect(testCar?.transmission).toBeDefined();
      expect(testCar?.fuelType).toBeDefined();
      expect(testCar?.engineSize).toBeDefined();
    });

    it("should include features in getMyListings", async () => {
      const listings = await db.getMyListings(testUserId);
      const testCar = listings.find((c: any) => c.id === testCarId);
      
      expect(testCar).toBeDefined();
      expect(testCar?.transmission).toBeDefined();
      expect(testCar?.fuelType).toBeDefined();
      expect(testCar?.engineSize).toBeDefined();
    });
  });

  describe("Handle Missing Features", () => {
    it("should handle cars without transmission", async () => {
      const carResult = await db.createCar({
        userId: testUserId,
        brand: "Honda",
        model: "Civic",
        carType: "Sedan",
        year: 2022,
        color: "Blue",
        price: "28000",
        kilometers: 10000,
        condition: "good",
        description: "Test car without transmission",
        sellerName: "Test Seller",
        sellerPhone: "+961123456",
        sellerEmail: "seller@example.com",
        sellerLocation: "Beirut",
      });

      const car = await db.getCarById(carResult || 0);
      expect(car?.transmission).toBeNull();
      expect(car?.fuelType).toBeNull();
      expect(car?.engineSize).toBeNull();
    });
  });
});
