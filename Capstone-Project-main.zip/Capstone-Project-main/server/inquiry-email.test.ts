import { describe, it, expect, vi, beforeEach } from "vitest";
import { generateInquiryEmailHTML } from "./_core/email";

describe("Inquiry Email Functionality", () => {
  describe("generateInquiryEmailHTML", () => {
    it("should generate HTML email with all required fields", () => {
      const html = generateInquiryEmailHTML({
        buyerName: "John Doe",
        buyerEmail: "john@example.com",
        buyerPhone: "961-1-234567",
        additionalNotes: "I'm very interested in this car!",
        carBrand: "BMW",
        carModel: "X5",
        carYear: 2022,
        carId: 123,
      });

      expect(html).toContain("New Car Inquiry");
      expect(html).toContain("John Doe");
      expect(html).toContain("john@example.com");
      expect(html).toContain("961-1-234567");
      expect(html).toContain("I'm very interested in this car!");
      expect(html).toContain("2022 BMW X5");
      expect(html).toContain("ID: 123");
    });

    it("should handle optional additional notes", () => {
      const html = generateInquiryEmailHTML({
        buyerName: "Jane Smith",
        buyerEmail: "jane@example.com",
        buyerPhone: "961-3-456789",
        carBrand: "Mercedes",
        carModel: "C-Class",
        carYear: 2023,
        carId: 456,
      });

      expect(html).toContain("Jane Smith");
      expect(html).toContain("Mercedes");
      expect(html).toContain("2023");
      // Should not fail without additionalNotes
      expect(html).toBeTruthy();
    });

    it("should escape HTML special characters in buyer name", () => {
      const html = generateInquiryEmailHTML({
        buyerName: "John <script>alert('xss')</script>",
        buyerEmail: "john@example.com",
        buyerPhone: "961-1-234567",
        carBrand: "BMW",
        carModel: "X5",
        carYear: 2022,
        carId: 123,
      });

      // The name should be in the HTML but script tags should be visible as text
      expect(html).toContain("John");
    });

    it("should format multiline notes with line breaks", () => {
      const html = generateInquiryEmailHTML({
        buyerName: "Test User",
        buyerEmail: "test@example.com",
        buyerPhone: "961-1-111111",
        additionalNotes: "Line 1\nLine 2\nLine 3",
        carBrand: "Toyota",
        carModel: "Camry",
        carYear: 2021,
        carId: 789,
      });

      expect(html).toContain("Line 1<br>Line 2<br>Line 3");
    });

    it("should include seller contact instructions", () => {
      const html = generateInquiryEmailHTML({
        buyerName: "Test",
        buyerEmail: "test@example.com",
        buyerPhone: "961-1-111111",
        carBrand: "BMW",
        carModel: "X5",
        carYear: 2022,
        carId: 123,
      });

      expect(html).toContain("Lebanese Auto Hub");
      expect(html).toContain("reply directly to the buyer");
    });
  });

  describe("Email HTML structure", () => {
    it("should have proper HTML structure", () => {
      const html = generateInquiryEmailHTML({
        buyerName: "Test",
        buyerEmail: "test@example.com",
        buyerPhone: "961-1-111111",
        carBrand: "BMW",
        carModel: "X5",
        carYear: 2022,
        carId: 123,
      });

      expect(html).toContain("<!DOCTYPE html>");
      expect(html).toContain("<html>");
      expect(html).toContain("</html>");
      expect(html).toContain("<head>");
      expect(html).toContain("</head>");
      expect(html).toContain("<body>");
      expect(html).toContain("</body>");
    });

    it("should include CSS styling", () => {
      const html = generateInquiryEmailHTML({
        buyerName: "Test",
        buyerEmail: "test@example.com",
        buyerPhone: "961-1-111111",
        carBrand: "BMW",
        carModel: "X5",
        carYear: 2022,
        carId: 123,
      });

      expect(html).toContain("<style>");
      expect(html).toContain("font-family");
      expect(html).toContain("color");
    });

    it("should include all required sections", () => {
      const html = generateInquiryEmailHTML({
        buyerName: "Test",
        buyerEmail: "test@example.com",
        buyerPhone: "961-1-111111",
        additionalNotes: "Test message",
        carBrand: "BMW",
        carModel: "X5",
        carYear: 2022,
        carId: 123,
      });

      expect(html).toContain("CAR DETAILS");
      expect(html).toContain("BUYER INFORMATION");
      expect(html).toContain("MESSAGE");
    });
  });
});
