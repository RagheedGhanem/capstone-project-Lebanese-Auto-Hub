import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { db as drizzleDb } from "../drizzle";
import { users, cars } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import * as db from "./db";

describe("Car Details Navigation - From Favorites", () => {
  let testUserId: number;
  let testCarId: number;

  beforeAll(async () => {
    // Create test user
    const userResult = await drizzleDb
      .insert(users)
      .values({
        email: "car-nav-test@example.com",
        name: "Car Navigation Test User",
        passwordHash: "hashed_password",
        role: "user",
      })
      .returning();
    testUserId = userResult[0].id;

    // Create test car
    const carResult = await drizzleDb
      .insert(cars)
      .values({
        brand: "Honda",
        model: "Civic",
        year: 2023,
        carType: "Sedan",
        color: "Silver",
        kilometers: 5000,
        condition: "Excellent",
        price: "28000",
        transmission: "Automatic",
        fuelType: "Petrol",
        engineSize: "1.8L",
        description: "Brand new car",
        userId: testUserId,
        status: "active",
      })
      .returning();
    testCarId = carResult[0].id;
  });

  afterAll(async () => {
    // Cleanup
    await drizzleDb.delete(cars).where(eq(cars.id, testCarId));
    await drizzleDb.delete(users).where(eq(users.id, testUserId));
  });

  it("should retrieve car by ID successfully", async () => {
    const car = await db.getCarById(testCarId);
    
    expect(car).toBeDefined();
    expect(car?.id).toBe(testCarId);
    expect(car?.brand).toBe("Honda");
    expect(car?.model).toBe("Civic");
  });

  it("should return undefined for non-existent car ID", async () => {
    const car = await db.getCarById(999999);
    
    expect(car).toBeUndefined();
  });

  it("should handle car ID as number correctly", async () => {
    // Simulate what happens when car ID is extracted from URL
    const carIdFromUrl = parseInt(String(testCarId));
    
    expect(typeof carIdFromUrl).toBe("number");
    expect(carIdFromUrl).toBe(testCarId);
    
    const car = await db.getCarById(carIdFromUrl);
    expect(car).toBeDefined();
    expect(car?.id).toBe(testCarId);
  });

  it("should retrieve all car details needed for display", async () => {
    const car = await db.getCarById(testCarId);
    
    expect(car).toBeDefined();
    expect(car?.id).toBeDefined();
    expect(car?.brand).toBeDefined();
    expect(car?.model).toBeDefined();
    expect(car?.year).toBeDefined();
    expect(car?.carType).toBeDefined();
    expect(car?.color).toBeDefined();
    expect(car?.price).toBeDefined();
    expect(car?.transmission).toBeDefined();
    expect(car?.fuelType).toBeDefined();
    expect(car?.engineSize).toBeDefined();
    expect(car?.description).toBeDefined();
  });

  it("should handle car lookup after adding to favorites", async () => {
    // Add to favorites
    await db.addFavorite(testUserId, testCarId);

    // Get favorites
    const favoriteCars = await db.getMyFavorites(testUserId);
    expect(favoriteCars).toHaveLength(1);

    // Get the car ID from favorites
    const favoriteCarId = favoriteCars[0].id;
    
    // Now look up the car details using the ID from favorites
    const carDetails = await db.getCarById(favoriteCarId);
    
    expect(carDetails).toBeDefined();
    expect(carDetails?.id).toBe(testCarId);
    expect(carDetails?.brand).toBe("Honda");
  });
});
