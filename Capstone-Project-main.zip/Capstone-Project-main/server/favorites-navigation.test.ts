import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { db as drizzleDb } from "../drizzle";
import { users, cars, favorites } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import * as db from "./db";

describe("My Favorites - Car Details Navigation", () => {
  let testUserId: number;
  let testCarId: number;

  beforeAll(async () => {
    // Create test user
    const userResult = await drizzleDb
      .insert(users)
      .values({
        email: "favorites-test@example.com",
        name: "Favorites Test User",
        passwordHash: "hashed_password",
        role: "user",
      })
      .returning();
    testUserId = userResult[0].id;

    // Create test car
    const carResult = await drizzleDb
      .insert(cars)
      .values({
        brand: "Toyota",
        model: "Camry",
        year: 2022,
        carType: "Sedan",
        color: "Blue",
        kilometers: 15000,
        condition: "Excellent",
        price: "25000",
        transmission: "Automatic",
        fuelType: "Petrol",
        engineSize: "2.5L",
        description: "Well maintained car",
        userId: testUserId,
        status: "active",
      })
      .returning();
    testCarId = carResult[0].id;
  });

  afterAll(async () => {
    // Cleanup
    await drizzleDb.delete(favorites).where(eq(favorites.userId, testUserId));
    await drizzleDb.delete(cars).where(eq(cars.id, testCarId));
    await drizzleDb.delete(users).where(eq(users.id, testUserId));
  });

  it("should add car to favorites and retrieve it with correct ID", async () => {
    // Add to favorites
    await db.addFavorite(testUserId, testCarId);

    // Get favorites
    const favoriteCars = await db.getMyFavorites(testUserId);

    expect(favoriteCars).toHaveLength(1);
    expect(favoriteCars[0].id).toBe(testCarId);
    expect(favoriteCars[0].brand).toBe("Toyota");
    expect(favoriteCars[0].model).toBe("Camry");
  });

  it("should retrieve car by ID after adding to favorites", async () => {
    // Add to favorites
    await db.addFavorite(testUserId, testCarId);

    // Get favorites
    const favoriteCars = await db.getMyFavorites(testUserId);
    const favoriteCarId = favoriteCars[0].id;

    // Retrieve car by ID (simulating car details page lookup)
    const carDetails = await db.getCarById(favoriteCarId);

    expect(carDetails).toBeDefined();
    expect(carDetails?.id).toBe(testCarId);
    expect(carDetails?.brand).toBe("Toyota");
    expect(carDetails?.model).toBe("Camry");
    expect(carDetails?.year).toBe(2022);
  });

  it("should have correct car ID for navigation", async () => {
    // Add to favorites
    await db.addFavorite(testUserId, testCarId);

    // Get favorites
    const favoriteCars = await db.getMyFavorites(testUserId);

    // Verify the ID can be used for navigation (/car/:id)
    expect(favoriteCars[0].id).toBe(testCarId);
    expect(typeof favoriteCars[0].id).toBe("number");

    // Simulate navigation by fetching car details with the ID
    const navigatedCar = await db.getCarById(favoriteCars[0].id);
    expect(navigatedCar).toBeDefined();
    expect(navigatedCar?.id).toBe(testCarId);
  });

  it("should maintain car details after removing and re-adding favorite", async () => {
    // Add to favorites
    await db.addFavorite(testUserId, testCarId);

    // Remove from favorites
    await db.removeFavorite(testUserId, testCarId);

    // Add back to favorites
    await db.addFavorite(testUserId, testCarId);

    // Get favorites
    const favoriteCars = await db.getMyFavorites(testUserId);

    // Verify car details are still correct
    expect(favoriteCars).toHaveLength(1);
    expect(favoriteCars[0].id).toBe(testCarId);
    expect(favoriteCars[0].brand).toBe("Toyota");
    expect(favoriteCars[0].model).toBe("Camry");
  });
});
