import { searchCarsByPreferences } from "./db";

async function testSearch() {
  console.log("=== Testing searchCarsByPreferences Fix ===\n");

  // Test 1: Search for Honda SUV
  console.log("Test 1: Search for Honda SUV");
  const result1 = await searchCarsByPreferences({
    brands: ["Honda"],
    carTypes: ["SUV"],
  });
  console.log(`Found ${result1.length} cars`);
  result1.forEach((car: any) => {
    console.log(`  - ${car.year} ${car.brand} ${car.model} (${car.carType})`);
  });

  // Test 2: Search for Toyota
  console.log("\nTest 2: Search for Toyota");
  const result2 = await searchCarsByPreferences({
    brands: ["Toyota"],
  });
  console.log(`Found ${result2.length} cars`);
  result2.forEach((car: any) => {
    console.log(`  - ${car.year} ${car.brand} ${car.model}`);
  });

  // Test 3: Search for cars under $15,000
  console.log("\nTest 3: Search for cars under $15,000");
  const result3 = await searchCarsByPreferences({
    maxPrice: 15000,
  });
  console.log(`Found ${result3.length} cars`);
  result3.forEach((car: any) => {
    console.log(`  - ${car.year} ${car.brand} ${car.model} - $${car.price}`);
  });

  // Test 4: Search for Sedan
  console.log("\nTest 4: Search for Sedan");
  const result4 = await searchCarsByPreferences({
    carTypes: ["sedan"],
  });
  console.log(`Found ${result4.length} cars`);
  result4.forEach((car: any) => {
    console.log(`  - ${car.year} ${car.brand} ${car.model} (${car.carType})`);
  });

  // Test 5: Search for SUV with Automatic transmission
  console.log("\nTest 5: Search for SUV with Automatic transmission");
  const result5 = await searchCarsByPreferences({
    carTypes: ["SUV"],
    transmissions: ["Automatic"],
  });
  console.log(`Found ${result5.length} cars`);
  result5.forEach((car: any) => {
    console.log(`  - ${car.year} ${car.brand} ${car.model} - ${car.transmission}`);
  });
}

testSearch().catch(console.error);
