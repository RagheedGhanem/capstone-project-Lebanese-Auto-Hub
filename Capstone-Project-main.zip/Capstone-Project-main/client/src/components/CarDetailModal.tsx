import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { X, ChevronLeft, ChevronRight, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";

interface CarDetailModalProps {
  car: any | null;
  isOpen: boolean;
  onClose: () => void;
}

export function CarDetailModal({ car, isOpen, onClose }: CarDetailModalProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showInquiryForm, setShowInquiryForm] = useState(false);
  const [inquiryData, setInquiryData] = useState({
    name: "",
    email: "",
    phone: "",
    additionalNotes: "",
  });

  const { data: images } = trpc.cars.getImages.useQuery(
    { carId: car?.id || 0 },
    { enabled: !!car?.id }
  );

  const createInquiry = trpc.inquiries.create.useMutation({
    onSuccess: () => {
      setInquiryData({ name: "", email: "", phone: "", additionalNotes: "" });
      setShowInquiryForm(false);
      alert("Inquiry submitted successfully! The seller will contact you soon.");
    },
    onError: (error) => {
      alert(`Error submitting inquiry: ${error.message}`);
    },
  });

  if (!car) return null;

  const handlePreviousImage = () => {
    setCurrentImageIndex((prev) =>
      prev === 0 ? (images?.length || 1) - 1 : prev - 1
    );
  };

  const handleNextImage = () => {
    setCurrentImageIndex((prev) =>
      prev === (images?.length || 1) - 1 ? 0 : prev + 1
    );
  };

  const handleSubmitInquiry = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!inquiryData.name || !inquiryData.email) {
      alert("Please fill in name and email");
      return;
    }

    await createInquiry.mutateAsync({
      name: inquiryData.name,
      email: inquiryData.email,
      phone: inquiryData.phone || "",
      brand: car.brand,
      model: car.model,
      carType: car.carType,
      year: car.year,
      color: car.color,
      additionalNotes: inquiryData.additionalNotes,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">
            {car.brand} {car.model}
          </DialogTitle>
        </DialogHeader>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Image Gallery */}
          <div className="space-y-4">
            <div className="relative bg-muted rounded-lg overflow-hidden aspect-video flex items-center justify-center">
              {images && images.length > 0 ? (
                <img
                  src={images[currentImageIndex]?.imageUrl || ""}
                  alt={`${car.brand} ${car.model}`}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="text-muted-foreground text-center">
                  <p>No images available</p>
                </div>
              )}

              {/* Image Navigation */}
              {images && images.length > 1 && (
                <>
                  <button
                    onClick={handlePreviousImage}
                    className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors"
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </button>
                  <button
                    onClick={handleNextImage}
                    className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors"
                  >
                    <ChevronRight className="h-5 w-5" />
                  </button>
                  <div className="absolute bottom-2 left-1/2 -translate-x-1/2 bg-black/50 text-white px-3 py-1 rounded-full text-sm">
                    {currentImageIndex + 1} / {images.length}
                  </div>
                </>
              )}
            </div>

            {/* Image Thumbnails */}
            {images && images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto">
                {images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 transition-colors ${
                      index === currentImageIndex
                        ? "border-primary"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <img
                      src={image.imageUrl}
                      alt={`Thumbnail ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Car Details */}
          <div className="space-y-6">
            {/* Price and Basic Info */}
            <div>
              <p className="text-4xl font-bold text-primary mb-2">
                ${parseFloat(car.price || "0").toLocaleString()}
              </p>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Year</p>
                  <p className="font-semibold">{car.year}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Type</p>
                  <p className="font-semibold capitalize">{car.carType}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Color</p>
                  <p className="font-semibold capitalize">{car.color}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Kilometers</p>
                  <p className="font-semibold">
                    {car.kilometers?.toLocaleString() || "N/A"} km
                  </p>
                </div>
              </div>
            </div>

            {/* Condition and Specifications */}
            <Card className="glass">
              <CardHeader>
                <CardTitle className="text-lg">Specifications</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {car.condition && (
                  <div>
                    <p className="text-sm text-muted-foreground">Condition</p>
                    <p className="font-semibold capitalize">{car.condition}</p>
                  </div>
                )}
                {car.transmission && (
                  <div>
                    <p className="text-sm text-muted-foreground">Transmission</p>
                    <p className="font-semibold">{car.transmission}</p>
                  </div>
                )}
                {car.fuelType && (
                  <div>
                    <p className="text-sm text-muted-foreground">Fuel Type</p>
                    <p className="font-semibold">{car.fuelType}</p>
                  </div>
                )}
                {car.engineSize && (
                  <div>
                    <p className="text-sm text-muted-foreground">Engine Size</p>
                    <p className="font-semibold">{car.engineSize}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Description */}
            {car.description && (
              <div>
                <p className="text-sm text-muted-foreground mb-2">Description</p>
                <p className="text-sm leading-relaxed">{car.description}</p>
              </div>
            )}

            {/* Features */}
            {car.features && (
              <div>
                <p className="text-sm text-muted-foreground mb-2">Features</p>
                <p className="text-sm leading-relaxed">{car.features}</p>
              </div>
            )}

            {/* Action Buttons */}
            {!showInquiryForm ? (
              <Button
                onClick={() => setShowInquiryForm(true)}
                className="w-full gradient-gold text-lg py-6"
              >
                Contact Seller
              </Button>
            ) : (
              <form onSubmit={handleSubmitInquiry} className="space-y-4">
                <div>
                  <Label htmlFor="inquiry-name">Name *</Label>
                  <Input
                    id="inquiry-name"
                    placeholder="Your name"
                    value={inquiryData.name}
                    onChange={(e) =>
                      setInquiryData({ ...inquiryData, name: e.target.value })
                    }
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="inquiry-email">Email *</Label>
                  <Input
                    id="inquiry-email"
                    type="email"
                    placeholder="your@email.com"
                    value={inquiryData.email}
                    onChange={(e) =>
                      setInquiryData({ ...inquiryData, email: e.target.value })
                    }
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="inquiry-phone">Phone</Label>
                  <Input
                    id="inquiry-phone"
                    placeholder="+961-1-234567"
                    value={inquiryData.phone}
                    onChange={(e) =>
                      setInquiryData({ ...inquiryData, phone: e.target.value })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="inquiry-notes">Additional Notes</Label>
                  <Textarea
                    id="inquiry-notes"
                    placeholder="Any questions or additional information..."
                    value={inquiryData.additionalNotes}
                    onChange={(e) =>
                      setInquiryData({
                        ...inquiryData,
                        additionalNotes: e.target.value,
                      })
                    }
                    rows={3}
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    type="submit"
                    disabled={createInquiry.isPending}
                    className="flex-1 gradient-gold"
                  >
                    {createInquiry.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Submitting...
                      </>
                    ) : (
                      "Submit Inquiry"
                    )}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowInquiryForm(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
