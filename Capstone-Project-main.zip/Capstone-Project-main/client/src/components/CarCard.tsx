import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronRight, MapPin, Gauge } from "lucide-react";
import { useLocation } from "wouter";

interface CarCardProps {
  id: number;
  brand: string;
  model: string;
  year: number;
  price: string;
  kilometers: number;
  transmission: string;
  fuelType: string;
  condition: string;
  sellerName: string;
  sellerPhone: string;
  sellerEmail: string;
  sellerLocation: string;
  carType: string;
  color: string;
  compact?: boolean; // For chat display
}

export default function CarCard({
  id,
  brand,
  model,
  year,
  price,
  kilometers,
  transmission,
  fuelType,
  condition,
  sellerName,
  sellerLocation,
  carType,
  color,
  compact = false,
}: CarCardProps) {
  const [, navigate] = useLocation();

  const handleViewDetails = () => {
    navigate(`/car/${id}`);
  };

  if (compact) {
    // Compact card for chat display
    return (
      <Card
        className="cursor-pointer hover:shadow-lg transition-shadow bg-card hover:bg-card/80 border-border"
        onClick={handleViewDetails}
      >
        <CardContent className="p-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-baseline gap-2 mb-2">
                <h3 className="font-semibold text-lg text-foreground truncate">
                  {year} {brand} {model}
                </h3>
                <span className="text-sm px-2 py-1 rounded bg-primary/10 text-primary whitespace-nowrap">
                  {carType}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 mb-3 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <span className="font-semibold text-foreground">${price}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Gauge className="h-4 w-4" />
                  <span>{kilometers.toLocaleString()} km</span>
                </div>
                <div>{transmission}</div>
                <div>{fuelType}</div>
              </div>

              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <MapPin className="h-3 w-3" />
                <span>{sellerLocation}</span>
              </div>
            </div>

            <Button
              size="sm"
              variant="outline"
              onClick={(e) => {
                e.stopPropagation();
                handleViewDetails();
              }}
              className="flex-shrink-0"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Full card for detail view
  return (
    <Card className="bg-card border-border">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h2 className="text-2xl font-bold text-foreground">
              {year} {brand} {model}
            </h2>
            <p className="text-muted-foreground">{color} • {condition}</p>
          </div>
          <div className="text-right">
            <p className="text-3xl font-bold text-primary">${price}</p>
            <p className="text-sm text-muted-foreground">Listed by {sellerName}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Type</p>
            <p className="font-semibold text-foreground">{carType}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Transmission</p>
            <p className="font-semibold text-foreground">{transmission}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Fuel</p>
            <p className="font-semibold text-foreground">{fuelType}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Mileage</p>
            <p className="font-semibold text-foreground">{kilometers.toLocaleString()} km</p>
          </div>
        </div>

        <div className="flex items-center gap-1 text-muted-foreground mb-4">
          <MapPin className="h-4 w-4" />
          <span>{sellerLocation}</span>
        </div>

        <Button onClick={handleViewDetails} className="w-full gradient-gold">
          View Full Details
        </Button>
      </CardContent>
    </Card>
  );
}
