import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

declare global {
  interface Window {
    L?: any;
  }
}

function loadLeaflet(): Promise<void> {
  return new Promise((resolve, reject) => {
    if (window.L) { resolve(); return; }
    if (!document.querySelector('link[href*="leaflet"]')) {
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
      document.head.appendChild(link);
    }
    const script = document.createElement("script");
    script.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("Failed to load Leaflet"));
    document.head.appendChild(script);
  });
}

export interface MarkerDef {
  id?: string | number;
  lat: number;
  lng: number;
  title?: string;
  onClick?: () => void;
}

interface MapViewProps {
  className?: string;
  initialCenter?: { lat: number; lng: number };
  initialZoom?: number;
  markers?: MarkerDef[];
  selectedId?: string | number | null;
}

function makeIcon(L: any, selected: boolean) {
  const size = selected ? 26 : 20;
  const color = selected ? "#3B82F6" : "#D4AF37";
  const shadow = selected ? "0 2px 10px rgba(59,130,246,.6)" : "0 2px 6px rgba(0,0,0,.4)";
  return L.divIcon({
    className: "",
    html: `<div style="width:${size}px;height:${size}px;border-radius:50%;background:${color};border:3px solid #fff;box-shadow:${shadow};cursor:pointer;transition:all .2s;"></div>`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  });
}

export function MapView({
  className,
  initialCenter = { lat: 33.8938, lng: 35.5018 },
  initialZoom = 10,
  markers = [],
  selectedId = null,
}: MapViewProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  // keyed by marker id (falls back to "lat,lng")
  const markerObjsRef = useRef<Map<string | number, any>>(new Map());
  const markerDefsRef = useRef<MarkerDef[]>([]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        await loadLeaflet();
        if (cancelled || !containerRef.current || mapRef.current) return;
        const L = window.L;
        const map = L.map(containerRef.current, {
          center: [initialCenter.lat, initialCenter.lng],
          zoom: initialZoom,
          zoomControl: true,
        });
        L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/">CARTO</a>',
          subdomains: "abcd",
          maxZoom: 19,
        }).addTo(map);
        mapRef.current = map;

        // Add initial markers
        markers.forEach((m) => {
          const key = m.id ?? `${m.lat},${m.lng}`;
          if (markerObjsRef.current.has(key)) return;
          const isSelected = selectedId != null && m.id === selectedId;
          const obj = L.marker([m.lat, m.lng], { icon: makeIcon(L, isSelected), title: m.title ?? "" }).addTo(map);
          if (m.title) obj.bindTooltip(m.title, { permanent: false, direction: "top" });
          if (m.onClick) obj.on("click", m.onClick);
          markerObjsRef.current.set(key, obj);
        });
        markerDefsRef.current = markers;
      } catch (err) {
        console.error("Map init error:", err);
      }
    })();
    return () => {
      cancelled = true;
      if (mapRef.current) { mapRef.current.remove(); mapRef.current = null; }
      markerObjsRef.current.clear();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Sync markers when list changes after mount
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !window.L) return;
    const L = window.L;
    const existing = markerObjsRef.current;

    markers.forEach((m) => {
      const key = m.id ?? `${m.lat},${m.lng}`;
      if (existing.has(key)) return;
      const isSelected = selectedId != null && m.id === selectedId;
      const obj = L.marker([m.lat, m.lng], { icon: makeIcon(L, isSelected), title: m.title ?? "" }).addTo(map);
      if (m.title) obj.bindTooltip(m.title, { permanent: false, direction: "top" });
      if (m.onClick) obj.on("click", m.onClick);
      existing.set(key, obj);
    });
    markerDefsRef.current = markers;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [markers]);

  // Update marker colors and pan when selection changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !window.L) return;
    const L = window.L;

    markerDefsRef.current.forEach((m: MarkerDef) => {
      const key = m.id ?? `${m.lat},${m.lng}`;
      const obj = markerObjsRef.current.get(key);
      if (!obj) return;
      const isSelected = selectedId != null && m.id != null && m.id === selectedId;
      obj.setIcon(makeIcon(L, isSelected));
    });

    if (selectedId != null) {
      const target = markerDefsRef.current.find((m: MarkerDef) => m.id === selectedId);
      if (target) {
        map.flyTo([target.lat, target.lng], Math.max(map.getZoom(), 13), { duration: 0.8 });
      }
    }
  }, [selectedId]);

  return <div ref={containerRef} className={cn("w-full h-[500px]", className)} />;
}
