import { useState } from "react";
import { Car, Menu, X } from "lucide-react";
import { useAuthContext } from "@/contexts/AuthContext";
import UserProfileMenu from "@/components/UserProfileMenu";
import { useLocation } from "wouter";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";

export default function Header() {
  const { user } = useAuthContext();
  const [, navigate] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navLinks = [
    { label: "Browse Cars", path: "/browse" },
    { label: "Sell Your Car", path: "/sell" },
    { label: "Dealers", path: "/dealers" },
    { label: "Get Valuation", path: "/valuation" },
    { label: "AI Assistant", path: "/chat" },
  ];

  const handleNav = (path: string) => {
    navigate(path);
    setMobileOpen(false);
  };

  return (
    <nav className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div
            className="flex items-center space-x-2 cursor-pointer hover:opacity-80 transition-opacity"
            onClick={() => navigate("/")}
          >
            <Car className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold text-gradient">Lebanese Auto Hub</span>
          </div>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center space-x-6">
            {navLinks.map((link) => (
              <button
                key={link.path}
                onClick={() => navigate(link.path)}
                className="text-foreground hover:text-primary transition-colors cursor-pointer font-medium"
              >
                {link.label}
              </button>
            ))}

            {user?.role === "admin" && (
              <button
                onClick={() => navigate("/admin")}
                className="text-foreground hover:text-primary transition-colors cursor-pointer font-medium px-3 py-1 rounded-md bg-primary/10 border border-primary/30"
              >
                Admin
              </button>
            )}

            {user ? (
              <UserProfileMenu />
            ) : (
              <button
                onClick={() => navigate("/auth")}
                className="px-4 py-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-colors cursor-pointer font-medium"
              >
                Sign In
              </button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center gap-2">
            {user && <UserProfileMenu />}
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Open menu">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-64 pt-12">
                <div className="flex flex-col gap-1">
                  {navLinks.map((link) => (
                    <button
                      key={link.path}
                      onClick={() => handleNav(link.path)}
                      className="w-full text-left px-4 py-3 rounded-lg text-foreground hover:bg-primary/10 hover:text-primary transition-colors font-medium"
                    >
                      {link.label}
                    </button>
                  ))}

                  {user?.role === "admin" && (
                    <button
                      onClick={() => handleNav("/admin")}
                      className="w-full text-left px-4 py-3 rounded-lg text-foreground hover:bg-primary/10 hover:text-primary transition-colors font-medium border border-primary/30 mt-2"
                    >
                      Admin Dashboard
                    </button>
                  )}

                  {!user && (
                    <button
                      onClick={() => handleNav("/auth")}
                      className="w-full mt-4 px-4 py-3 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-colors font-medium text-center"
                    >
                      Sign In
                    </button>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
