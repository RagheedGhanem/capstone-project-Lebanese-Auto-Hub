import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Car, Upload, Loader2, CheckCircle2 } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";
import ImageUpload from "@/components/ImageUpload";
import Header from "@/components/Header";

export default function SellCar() {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [uploadedImages, setUploadedImages] = useState<File[]>([]);
  const [isUploadingImages, setIsUploadingImages] = useState(false);
  const [formData, setFormData] = useState({
    brand: "",
    model: "",
    carType: "",
    year: new Date().getFullYear(),
    color: "",
    kilometers: 0,
    condition: "good" as "new" | "excellent" | "good" | "fair" | "poor",
    price: 0,
    description: "",
    transmission: "",
    fuelType: "",
    engineSize: "",

    sellerName: user?.name || "",
    sellerPhone: "",
    sellerEmail: user?.email || "",
    sellerLocation: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const createCar = trpc.cars.create.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      toast.success("Your car has been listed successfully!");
    },
    onError: (error) => {
      toast.error(`Failed to list car: ${error.message}`);
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.brand || !formData.model || !formData.carType || !formData.sellerName || !formData.sellerPhone || !formData.sellerEmail || !formData.sellerLocation) {
      toast.error("Please fill in all required fields including seller information");
      return;
    }

    // First, create the car
    const carResponse = await new Promise<{ carId: number }>((resolve, reject) => {
      createCar.mutate({
        brand: formData.brand,
        model: formData.model,
        carType: formData.carType,
        year: formData.year,
        color: formData.color,
        kilometers: formData.kilometers,
        condition: formData.condition,
        price: String(formData.price),
        description: formData.description,
        transmission: formData.transmission,
        fuelType: formData.fuelType,
        engineSize: formData.engineSize,
        sellerName: formData.sellerName,
        sellerPhone: formData.sellerPhone,
        sellerEmail: formData.sellerEmail,
        sellerLocation: formData.sellerLocation,
      }, {
        onSuccess: (data) => resolve(data),
        onError: (error) => reject(error),
      });
    });

    // Then, upload images if any
    if (uploadedImages.length > 0) {
      try {
        const formDataImages = new FormData();
        uploadedImages.forEach((file, index) => {
          formDataImages.append(`images`, file);
        });
        formDataImages.append('carId', carResponse.carId.toString());

        const uploadResponse = await fetch('/api/upload-car-images', {
          method: 'POST',
          body: formDataImages,
        });

        if (!uploadResponse.ok) {
          const errorData = await uploadResponse.json();
          console.error('Image upload failed:', errorData);
          toast.warning('Car listed but some images failed to upload');
        } else {
          const result = await uploadResponse.json();
          console.log('Images uploaded successfully:', result);
          toast.success('Images uploaded successfully!');
        }
      } catch (error) {
        console.error('Error uploading images:', error);
        toast.warning('Car listed but images could not be uploaded');
      }
    }
  };

  // Show loading state while checking authentication
  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // If not authenticated after loading is complete, show sign in prompt
  if (!user || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-20">
          <Card className="max-w-md mx-auto glass">
            <CardContent className="pt-6 text-center">
              <h2 className="text-2xl font-bold mb-4">Sign In Required</h2>
              <p className="text-muted-foreground mb-6">
                Please sign in to list your car for sale
              </p>
              <Button className="gradient-gold w-full" onClick={() => window.location.href = '/auth'}>
                Sign In or Create Account
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-20">
          <Card className="max-w-2xl mx-auto glass text-center">
            <CardContent className="pt-12 pb-12">
              <CheckCircle2 className="h-20 w-20 text-primary mx-auto mb-6" />
              <h2 className="text-3xl font-bold mb-4">Car Listed Successfully!</h2>
              <p className="text-muted-foreground mb-8">
                Your {formData.brand} {formData.model} has been added to our marketplace.
                Our team will review it shortly.
              </p>
              <div className="flex gap-4 justify-center">
                <Link href="/browse">
                  <Button className="gradient-gold">
                    Browse Cars
                  </Button>
                </Link>
                <Button variant="outline" onClick={() => {
                  setSubmitted(false);
                  setFormData({
                    brand: "",
                    model: "",
                    carType: "",
                    year: new Date().getFullYear(),
                    color: "",
                    kilometers: 0,
                    condition: "good",
                    price: 0,
                    description: "",
                    transmission: "",
                    fuelType: "",
                    engineSize: "",
                
                    sellerName: user?.name || "",
                    sellerPhone: "",
                    sellerEmail: user?.email || "",
                    sellerLocation: "",
                  });
                }}>
                  List Another Car
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <Header />

      <div className="container py-8 max-w-4xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Sell Your Car</h1>
          <p className="text-muted-foreground">Fill in the details below to list your car for sale</p>
        </div>

        <form onSubmit={handleSubmit}>
          <Card className="glass">
            <CardHeader>
              <CardTitle>Car Details</CardTitle>
              <CardDescription>Provide accurate information to attract buyers</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Basic Information */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="brand">Brand *</Label>
                  <Input
                    id="brand"
                    placeholder="e.g., Toyota"
                    value={formData.brand}
                    onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="model">Model *</Label>
                  <Input
                    id="model"
                    placeholder="e.g., Camry"
                    value={formData.model}
                    onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="carType">Car Type *</Label>
                  <Select value={formData.carType} onValueChange={(value) => setFormData({ ...formData, carType: value })} required>
                    <SelectTrigger id="carType">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sedan">Sedan</SelectItem>
                      <SelectItem value="suv">SUV</SelectItem>
                      <SelectItem value="coupe">Coupe</SelectItem>
                      <SelectItem value="hatchback">Hatchback</SelectItem>
                      <SelectItem value="truck">Truck</SelectItem>
                      <SelectItem value="van">Van</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="year">Year *</Label>
                  <Input
                    id="year"
                    type="number"
                    value={formData.year}
                    onChange={(e) => setFormData({ ...formData, year: parseInt(e.target.value) })}
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="color">Color *</Label>
                  <Input
                    id="color"
                    placeholder="e.g., Black"
                    value={formData.color}
                    onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="kilometers">Kilometers *</Label>
                  <Input
                    id="kilometers"
                    type="number"
                    placeholder="e.g., 50000"
                    value={formData.kilometers}
                    onChange={(e) => setFormData({ ...formData, kilometers: parseInt(e.target.value) })}
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="condition">Condition *</Label>
                  <Select value={formData.condition} onValueChange={(value: any) => setFormData({ ...formData, condition: value })} required>
                    <SelectTrigger id="condition">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new">New</SelectItem>
                      <SelectItem value="excellent">Excellent</SelectItem>
                      <SelectItem value="good">Good</SelectItem>
                      <SelectItem value="fair">Fair</SelectItem>
                      <SelectItem value="poor">Poor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="price">Price (USD) *</Label>
                  <Input
                    id="price"
                    type="number"
                    placeholder="e.g., 25000"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) })}
                    required
                  />
                </div>
              </div>

              {/* Additional Details */}
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="transmission">Transmission</Label>
                  <Input
                    id="transmission"
                    placeholder="e.g., Automatic"
                    value={formData.transmission}
                    onChange={(e) => setFormData({ ...formData, transmission: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="fuelType">Fuel Type</Label>
                  <Input
                    id="fuelType"
                    placeholder="e.g., Gasoline"
                    value={formData.fuelType}
                    onChange={(e) => setFormData({ ...formData, fuelType: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="engineSize">Engine Size</Label>
                  <Input
                    id="engineSize"
                    placeholder="e.g., 2.5L"
                    value={formData.engineSize}
                    onChange={(e) => setFormData({ ...formData, engineSize: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description & Features</Label>
                <Textarea
                  id="description"
                  placeholder="Describe your car's features, history, and condition..."
                  rows={4}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                />
              </div>

              <div>
                <Label>Car Photos</Label>
                <p className="text-sm text-muted-foreground mb-4">Upload high-quality photos of your car to attract more buyers</p>
                <ImageUpload
                  onImagesSelected={setUploadedImages}
                  maxFiles={8}
                  maxSizeMB={15}
                />
              </div>
            </CardContent>
          </Card>

          {/* Personal Details Card */}
          <Card className="glass mt-6">
            <CardHeader>
              <CardTitle>Your Contact Information</CardTitle>
              <CardDescription>This information will be displayed to potential buyers</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="sellerName">Full Name *</Label>
                  <Input
                    id="sellerName"
                    placeholder="Your full name"
                    value={formData.sellerName}
                    onChange={(e) => setFormData({ ...formData, sellerName: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="sellerPhone">Phone Number *</Label>
                  <Input
                    id="sellerPhone"
                    placeholder="e.g., +961-1-234567"
                    value={formData.sellerPhone}
                    onChange={(e) => setFormData({ ...formData, sellerPhone: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="sellerEmail">Email Address *</Label>
                  <Input
                    id="sellerEmail"
                    type="email"
                    placeholder="your@email.com"
                    value={formData.sellerEmail}
                    onChange={(e) => setFormData({ ...formData, sellerEmail: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="sellerLocation">Location *</Label>
                  <Input
                    id="sellerLocation"
                    placeholder="e.g., Beirut, Lebanon"
                    value={formData.sellerLocation}
                    onChange={(e) => setFormData({ ...formData, sellerLocation: e.target.value })}
                    required
                  />
                </div>
              </div>

            </CardContent>
          </Card>

          <div className="pt-4">
                <Button 
                  type="submit" 
                  className="w-full gradient-gold text-lg py-6"
                  disabled={createCar.isPending || isUploadingImages}
                >
                  {createCar.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Listing Car...
                    </>
                  ) : (
                    <>
                      <Upload className="mr-2 h-5 w-5" />
                      List My Car
                    </>
                  )}
                </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
