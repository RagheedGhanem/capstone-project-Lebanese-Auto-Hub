import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Car, Eye, EyeOff, Check, X } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { useAuthContext } from "@/contexts/AuthContext";

const isOAuthConfigured = Boolean(import.meta.env.VITE_OAUTH_PORTAL_URL);

export default function Auth() {
  const [, setLocation] = useLocation();
  const { refresh } = useAuthContext();
  // Sign In State
  const [signInEmail, setSignInEmail] = useState("");
  const [signInPassword, setSignInPassword] = useState("");
  const [showSignInPassword, setShowSignInPassword] = useState(false);
  const [signInErrors, setSignInErrors] = useState<{ email?: string; password?: string }>({});
  const [signInLoading, setSignInLoading] = useState(false);

  // Sign Up State
  const [signUpName, setSignUpName] = useState("");
  const [signUpEmail, setSignUpEmail] = useState("");
  const [signUpPassword, setSignUpPassword] = useState("");
  const [signUpConfirmPassword, setSignUpConfirmPassword] = useState("");
  const [showSignUpPassword, setShowSignUpPassword] = useState(false);
  const [showSignUpConfirmPassword, setShowSignUpConfirmPassword] = useState(false);
  const [signUpErrors, setSignUpErrors] = useState<{ name?: string; email?: string; password?: string; confirmPassword?: string }>({});
  const [signUpLoading, setSignUpLoading] = useState(false);

  // Mutations
  const utils = trpc.useUtils();

  const signInMutation = trpc.auth.signIn.useMutation({
    onSuccess: async () => {
      toast.success("Signed in successfully!");
      // Invalidate and wait for refetch to complete
      await utils.auth.me.invalidate();
      // Refresh auth context
      await refresh();
      // Give it a moment for the cache to update
      await new Promise(resolve => setTimeout(resolve, 300));
      setLocation("/");
    },
    onError: (error: any) => {
      toast.error(error.message || "Failed to sign in");
    },
  });

  const signUpMutation = trpc.auth.signUp.useMutation({
    onSuccess: async () => {
      toast.success("Account created! Signing you in...");
      setSignUpName("");
      setSignUpEmail("");
      setSignUpPassword("");
      setSignUpConfirmPassword("");
      // Invalidate and wait for refetch to complete
      await utils.auth.me.invalidate();
      // Refresh auth context
      await refresh();
      // Give it a moment for the cache to update
      await new Promise(resolve => setTimeout(resolve, 300));
      setLocation("/");
    },
    onError: (error: any) => {
      toast.error(error.message || "Failed to create account");
    },
  });

  // Sign In Validation
  const validateSignIn = () => {
    const newErrors: typeof signInErrors = {};

    if (!signInEmail) {
      newErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(signInEmail)) {
      newErrors.email = "Please enter a valid email";
    }

    if (!signInPassword) {
      newErrors.password = "Password is required";
    }

    setSignInErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Sign Up Validation
  const validateSignUp = () => {
    const newErrors: typeof signUpErrors = {};

    if (!signUpName) {
      newErrors.name = "Name is required";
    } else if (signUpName.length < 2) {
      newErrors.name = "Name must be at least 2 characters";
    }

    if (!signUpEmail) {
      newErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(signUpEmail)) {
      newErrors.email = "Please enter a valid email";
    }

    if (!signUpPassword) {
      newErrors.password = "Password is required";
    }

    if (!signUpConfirmPassword) {
      newErrors.confirmPassword = "Please confirm your password";
    } else if (signUpPassword !== signUpConfirmPassword) {
      newErrors.confirmPassword = "Passwords don't match";
    }

    setSignUpErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Sign In Submit
  const handleSignInSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateSignIn()) return;

    setSignInLoading(true);
    try {
      await signInMutation.mutateAsync({ email: signInEmail, password: signInPassword });
    } finally {
      setSignInLoading(false);
    }
  };

  // Sign Up Submit
  const handleSignUpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateSignUp()) return;

    setSignUpLoading(true);
    try {
      await signUpMutation.mutateAsync({
        name: signUpName,
        email: signUpEmail,
        password: signUpPassword,
      });
    } finally {
      setSignUpLoading(false);
    }
  };

  // Password strength indicators
  const hasUppercase = /[A-Z]/.test(signUpPassword);
  const hasLowercase = /[a-z]/.test(signUpPassword);
  const hasNumber = /\d/.test(signUpPassword);
  const hasSpecialChar = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(signUpPassword);
  const hasMinLength = signUpPassword.length >= 8;
  const passwordStrength = [hasUppercase, hasLowercase, hasNumber, hasSpecialChar, hasMinLength].filter(Boolean).length;

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-card/20 flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Car className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold text-gradient">Lebanese Auto Hub</span>
          </div>
          <p className="text-muted-foreground">Sign in or create an account to list your car</p>
        </div>

        {/* Auth Card with Tabs */}
        <Card className="glass border-primary/10">
          <CardHeader>
            <CardTitle>Get Started</CardTitle>
            <CardDescription>Sign in to your account or create a new one</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="signin" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="signin">Sign In</TabsTrigger>
                <TabsTrigger value="signup">Sign Up</TabsTrigger>
              </TabsList>

              {/* Sign In Tab */}
              <TabsContent value="signin" className="space-y-4">
                <form onSubmit={handleSignInSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="signin-email">Email Address</Label>
                    <Input
                      id="signin-email"
                      type="email"
                      placeholder="your@email.com"
                      value={signInEmail}
                      onChange={(e) => {
                        setSignInEmail(e.target.value);
                        if (signInErrors.email) setSignInErrors({ ...signInErrors, email: undefined });
                      }}
                      className={signInErrors.email ? "border-red-500" : ""}
                      disabled={signInLoading}
                    />
                    {signInErrors.email && <p className="text-sm text-red-500 mt-1">{signInErrors.email}</p>}
                  </div>

                  <div>
                    <Label htmlFor="signin-password">Password</Label>
                    <div className="relative">
                      <Input
                        id="signin-password"
                        type={showSignInPassword ? "text" : "password"}
                        placeholder="••••••••"
                        value={signInPassword}
                        onChange={(e) => {
                          setSignInPassword(e.target.value);
                          if (signInErrors.password) setSignInErrors({ ...signInErrors, password: undefined });
                        }}
                        className={signInErrors.password ? "border-red-500 pr-10" : "pr-10"}
                        disabled={signInLoading}
                      />
                      <button
                        type="button"
                        onClick={() => setShowSignInPassword(!showSignInPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        disabled={signInLoading}
                      >
                        {showSignInPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                    {signInErrors.password && <p className="text-sm text-red-500 mt-1">{signInErrors.password}</p>}
                  </div>

                  <Button type="submit" className="w-full gradient-gold text-base" disabled={signInLoading}>
                    {signInLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Signing in...
                      </>
                    ) : (
                      "Sign In"
                    )}
                  </Button>
                </form>

                {/* Google Sign In - only shown when OAuth is configured */}
                {isOAuthConfigured && (
                  <>
                    <div className="relative">
                      <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-border"></div>
                      </div>
                      <div className="relative flex justify-center text-sm">
                        <span className="px-2 bg-card text-muted-foreground">Or continue with</span>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      className="w-full border-primary/20 hover:bg-primary/5"
                      onClick={() => (window.location.href = getLoginUrl())}
                      disabled={signInLoading}
                    >
                      <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
                        <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                        <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                        <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                        <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                      </svg>
                      Sign in with Google
                    </Button>
                  </>
                )}
              </TabsContent>

              {/* Sign Up Tab */}
              <TabsContent value="signup" className="space-y-4">
                <form onSubmit={handleSignUpSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="signup-name">Full Name</Label>
                    <Input
                      id="signup-name"
                      type="text"
                      placeholder="John Doe"
                      value={signUpName}
                      onChange={(e) => {
                        setSignUpName(e.target.value);
                        if (signUpErrors.name) setSignUpErrors({ ...signUpErrors, name: undefined });
                      }}
                      className={signUpErrors.name ? "border-red-500" : ""}
                      disabled={signUpLoading}
                    />
                    {signUpErrors.name && <p className="text-sm text-red-500 mt-1">{signUpErrors.name}</p>}
                  </div>

                  <div>
                    <Label htmlFor="signup-email">Email Address</Label>
                    <Input
                      id="signup-email"
                      type="email"
                      placeholder="your@email.com"
                      value={signUpEmail}
                      onChange={(e) => {
                        setSignUpEmail(e.target.value);
                        if (signUpErrors.email) setSignUpErrors({ ...signUpErrors, email: undefined });
                      }}
                      className={signUpErrors.email ? "border-red-500" : ""}
                      disabled={signUpLoading}
                    />
                    {signUpErrors.email && <p className="text-sm text-red-500 mt-1">{signUpErrors.email}</p>}
                  </div>

                  <div>
                    <Label htmlFor="signup-password">Password</Label>
                    <div className="relative">
                      <Input
                        id="signup-password"
                        type={showSignUpPassword ? "text" : "password"}
                        placeholder="••••••••"
                        value={signUpPassword}
                        onChange={(e) => {
                          setSignUpPassword(e.target.value);
                          if (signUpErrors.password) setSignUpErrors({ ...signUpErrors, password: undefined });
                        }}
                        className={signUpErrors.password ? "border-red-500 pr-10" : "pr-10"}
                        disabled={signUpLoading}
                      />
                      <button
                        type="button"
                        onClick={() => setShowSignUpPassword(!showSignUpPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        disabled={signUpLoading}
                      >
                        {showSignUpPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                    {signUpErrors.password && <p className="text-sm text-red-500 mt-1">{signUpErrors.password}</p>}

                    {/* Password Strength Indicator */}
                    {signUpPassword && (
                      <div className="mt-3 space-y-2">
                        <div className="flex gap-1">
                          {[...Array(5)].map((_, i) => (
                            <div
                              key={i}
                              className={`h-1 flex-1 rounded-full transition-colors ${
                                i < passwordStrength ? "bg-primary" : "bg-muted"
                              }`}
                            />
                          ))}
                        </div>
                        <div className="text-xs space-y-1">
                          <div className={`flex items-center gap-1 ${hasMinLength ? "text-green-600" : "text-muted-foreground"}`}>
                            {hasMinLength ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}
                            At least 8 characters
                          </div>
                          <div className={`flex items-center gap-1 ${hasUppercase ? "text-green-600" : "text-muted-foreground"}`}>
                            {hasUppercase ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}
                            One uppercase letter
                          </div>
                          <div className={`flex items-center gap-1 ${hasLowercase ? "text-green-600" : "text-muted-foreground"}`}>
                            {hasLowercase ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}
                            One lowercase letter
                          </div>
                          <div className={`flex items-center gap-1 ${hasNumber ? "text-green-600" : "text-muted-foreground"}`}>
                            {hasNumber ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}
                            One number
                          </div>
                          <div className={`flex items-center gap-1 ${hasSpecialChar ? "text-green-600" : "text-muted-foreground"}`}>
                            {hasSpecialChar ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}
                            One special character
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="signup-confirm-password">Confirm Password</Label>
                    <div className="relative">
                      <Input
                        id="signup-confirm-password"
                        type={showSignUpConfirmPassword ? "text" : "password"}
                        placeholder="••••••••"
                        value={signUpConfirmPassword}
                        onChange={(e) => {
                          setSignUpConfirmPassword(e.target.value);
                          if (signUpErrors.confirmPassword) setSignUpErrors({ ...signUpErrors, confirmPassword: undefined });
                        }}
                        className={signUpErrors.confirmPassword ? "border-red-500 pr-10" : "pr-10"}
                        disabled={signUpLoading}
                      />
                      <button
                        type="button"
                        onClick={() => setShowSignUpConfirmPassword(!showSignUpConfirmPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        disabled={signUpLoading}
                      >
                        {showSignUpConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                    {signUpErrors.confirmPassword && <p className="text-sm text-red-500 mt-1">{signUpErrors.confirmPassword}</p>}
                  </div>

                  <Button type="submit" className="w-full gradient-gold text-base" disabled={signUpLoading}>
                    {signUpLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Creating account...
                      </>
                    ) : (
                      "Create Account"
                    )}
                  </Button>
                </form>

                {/* Google Sign Up - only shown when OAuth is configured */}
                {isOAuthConfigured && (
                  <>
                    <div className="relative">
                      <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-border"></div>
                      </div>
                      <div className="relative flex justify-center text-sm">
                        <span className="px-2 bg-card text-muted-foreground">Or sign up with</span>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      className="w-full border-primary/20 hover:bg-primary/5"
                      onClick={() => (window.location.href = getLoginUrl())}
                      disabled={signUpLoading}
                    >
                      <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
                        <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                        <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                        <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                        <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                      </svg>
                      Sign up with Google
                    </Button>
                  </>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Footer */}
        <p className="text-center text-xs text-muted-foreground mt-8">
          By signing in or creating an account, you agree to our Terms of Service and Privacy Policy
        </p>
      </div>
    </div>
  );
}
