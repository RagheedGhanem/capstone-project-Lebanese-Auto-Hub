import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Loader2, Trash2, Shield, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import Header from "@/components/Header";

export default function AdminUsers() {
  const { user, loading } = useAuth({ redirectOnUnauthenticated: true, redirectPath: "/auth" });
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");

  // Redirect non-admins
  if (!loading && user?.role !== "admin") {
    setLocation("/");
    return null;
  }

  // Fetch all users
  const { data: users = [], isLoading, refetch } = trpc.admin.getAllUsers.useQuery();
  const deleteUserMutation = trpc.admin.deleteUser.useMutation();
  const updateRoleMutation = trpc.admin.updateUserRole.useMutation();

  // Filter users based on search
  const filteredUsers = users.filter(
    (u) =>
      u.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDeleteUser = async (userId: number) => {
    if (!confirm("Are you sure you want to delete this user? This action cannot be undone.")) {
      return;
    }

    try {
      await deleteUserMutation.mutateAsync({ userId });
      toast.success("User deleted successfully");
      refetch();
    } catch (error: any) {
      toast.error(error?.message || "Failed to delete user");
    }
  };

  const handlePromoteToAdmin = async (userId: number) => {
    try {
      await updateRoleMutation.mutateAsync({ userId, role: "admin" });
      toast.success("User promoted to admin");
      refetch();
    } catch (error: any) {
      toast.error(error?.message || "Failed to update user role");
    }
  };

  const handleDemoteToUser = async (userId: number) => {
    try {
      await updateRoleMutation.mutateAsync({ userId, role: "user" });
      toast.success("User demoted to regular user");
      refetch();
    } catch (error: any) {
      toast.error(error?.message || "Failed to update user role");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="flex items-center justify-center h-screen">
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto py-8 px-4">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-4 mb-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLocation("/admin")}
                className="gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Dashboard
              </Button>
            </div>
            <h1 className="text-3xl font-bold">Manage Users</h1>
            <p className="text-muted-foreground">View and manage all user accounts</p>
          </div>
        </div>

        {/* Search */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Search Users</CardTitle>
          </CardHeader>
          <CardContent>
            <Input
              placeholder="Search by name or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-md"
            />
          </CardContent>
        </Card>

        {/* Users Table */}
        <Card>
          <CardHeader>
            <CardTitle>All Users ({filteredUsers.length})</CardTitle>
            <CardDescription>
              Total: {users.length} users | Showing: {filteredUsers.length}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
              </div>
            ) : filteredUsers.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No users found</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4 font-semibold">Name</th>
                      <th className="text-left py-3 px-4 font-semibold">Email</th>
                      <th className="text-left py-3 px-4 font-semibold">Role</th>
                      <th className="text-left py-3 px-4 font-semibold">Login Method</th>
                      <th className="text-left py-3 px-4 font-semibold">Joined</th>
                      <th className="text-left py-3 px-4 font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredUsers.map((u) => (
                      <tr key={u.id} className="border-b hover:bg-muted/50">
                        <td className="py-3 px-4">{u.name || "N/A"}</td>
                        <td className="py-3 px-4 text-sm">{u.email || u.openId || "N/A"}</td>
                        <td className="py-3 px-4">
                          <Badge variant={u.role === "admin" ? "default" : "secondary"}>
                            {u.role}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-sm capitalize">{u.loginMethod || "N/A"}</td>
                        <td className="py-3 px-4 text-sm">
                          {u.createdAt
                            ? new Date(u.createdAt).toLocaleDateString()
                            : "N/A"}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex gap-2">
                            {u.role === "user" ? (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handlePromoteToAdmin(u.id)}
                                disabled={updateRoleMutation.isPending}
                                className="gap-1"
                              >
                                <Shield className="w-3 h-3" />
                                Make Admin
                              </Button>
                            ) : u.id !== user?.id ? (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleDemoteToUser(u.id)}
                                disabled={updateRoleMutation.isPending}
                              >
                                Demote
                              </Button>
                            ) : null}
                            {u.id !== user?.id && (
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleDeleteUser(u.id)}
                                disabled={deleteUserMutation.isPending}
                                className="gap-1"
                              >
                                <Trash2 className="w-3 h-3" />
                                Delete
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
