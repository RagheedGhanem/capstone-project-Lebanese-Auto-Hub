import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Mail, Phone, MessageSquare } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function SellerInquiries() {
  const [, navigate] = useLocation();
  const [expandedInquiryId, setExpandedInquiryId] = useState<number | null>(null);

  // Fetch seller inquiries
  const { data: inquiries, isLoading, refetch } = trpc.inquiries.getSellerInquiries.useQuery();

  // Update status mutation
  const updateStatusMutation = trpc.inquiries.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Inquiry status updated!");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update status");
    },
  });

  const handleStatusChange = (inquiryId: number, newStatus: string) => {
    updateStatusMutation.mutate({
      inquiryId,
      status: newStatus as "new" | "contacted" | "completed" | "cancelled",
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new":
        return "bg-blue-100 text-blue-800";
      case "contacted":
        return "bg-yellow-100 text-yellow-800";
      case "completed":
        return "bg-green-100 text-green-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center gap-4 mb-8">
            <button
              onClick={() => navigate("/profile")}
              className="flex items-center gap-2 text-primary hover:text-primary/80 transition"
            >
              <ArrowLeft size={20} />
              <span>Back</span>
            </button>
            <h1 className="text-3xl font-bold">Seller Inquiries</h1>
          </div>
          <div className="flex justify-center py-12">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p>Loading inquiries...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate("/profile")}
            className="flex items-center gap-2 text-primary hover:text-primary/80 transition"
          >
            <ArrowLeft size={20} />
            <span>Back</span>
          </button>
          <div>
            <h1 className="text-3xl font-bold">Seller Inquiries</h1>
            <p className="text-muted-foreground mt-1">
              Manage inquiries from buyers interested in your cars
            </p>
          </div>
        </div>

        {/* Empty State */}
        {!inquiries || inquiries.length === 0 ? (
          <Card className="p-12 text-center">
            <MessageSquare size={48} className="mx-auto mb-4 text-muted-foreground opacity-50" />
            <h2 className="text-xl font-semibold mb-2">No inquiries yet</h2>
            <p className="text-muted-foreground mb-6">
              When buyers submit inquiries about your car listings, they'll appear here.
            </p>
            <Button onClick={() => navigate("/browse")} variant="outline">
              Browse Your Listings
            </Button>
          </Card>
        ) : (
          <div className="space-y-4">
            {/* Filter/Summary */}
            <div className="flex justify-between items-center mb-6">
              <div className="text-sm text-muted-foreground">
                {inquiries.length} total inquiry{inquiries.length !== 1 ? "ies" : ""}
              </div>
              <div className="flex gap-2">
                <Badge variant="outline">
                  {inquiries.filter((i: any) => i.status === "new").length} New
                </Badge>
                <Badge variant="outline">
                  {inquiries.filter((i: any) => i.status === "contacted").length} Contacted
                </Badge>
                <Badge variant="outline">
                  {inquiries.filter((i: any) => i.status === "completed").length} Completed
                </Badge>
              </div>
            </div>

            {/* Inquiries List */}
            {inquiries.map((inquiry: any) => (
              <Card
                key={inquiry.id}
                className="p-6 hover:shadow-md transition cursor-pointer"
                onClick={() =>
                  setExpandedInquiryId(expandedInquiryId === inquiry.id ? null : inquiry.id)
                }
              >
                <div className="flex justify-between items-start mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold text-lg">{inquiry.name}</h3>
                      <Badge className={getStatusColor(inquiry.status)}>
                        {inquiry.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">
                      Interested in: <span className="font-medium">{inquiry.year} {inquiry.brand} {inquiry.model}</span>
                    </p>
                    <div className="flex gap-4 text-sm">
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Mail size={16} />
                        <a href={`mailto:${inquiry.email}`} className="hover:text-primary">
                          {inquiry.email}
                        </a>
                      </div>
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Phone size={16} />
                        <a href={`tel:${inquiry.phone}`} className="hover:text-primary">
                          {inquiry.phone}
                        </a>
                      </div>
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {new Date(inquiry.createdAt).toLocaleDateString()}
                  </div>
                </div>

                {/* Expanded Details */}
                {expandedInquiryId === inquiry.id && (
                  <div className="mt-6 pt-6 border-t border-border space-y-4">
                    {inquiry.additionalNotes && (
                      <div>
                        <h4 className="font-semibold text-sm mb-2">Buyer's Message</h4>
                        <p className="text-sm text-muted-foreground bg-accent/50 p-3 rounded">
                          {inquiry.additionalNotes}
                        </p>
                      </div>
                    )}

                    {inquiry.carDetails && (
                      <div>
                        <h4 className="font-semibold text-sm mb-2">Car Details</h4>
                        <div className="grid grid-cols-2 gap-3 text-sm">
                          <div>
                            <span className="text-muted-foreground">Brand:</span>
                            <p className="font-medium">{inquiry.carDetails.brand}</p>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Model:</span>
                            <p className="font-medium">{inquiry.carDetails.model}</p>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Year:</span>
                            <p className="font-medium">{inquiry.carDetails.year}</p>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Price:</span>
                            <p className="font-medium">
                              ${inquiry.carDetails.price} {inquiry.carDetails.currency}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Status Update */}
                    <div>
                      <h4 className="font-semibold text-sm mb-2">Update Status</h4>
                      <Select
                        value={inquiry.status}
                        onValueChange={(value) => handleStatusChange(inquiry.id, value)}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="new">New</SelectItem>
                          <SelectItem value="contacted">Contacted</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                          <SelectItem value="cancelled">Cancelled</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-2 pt-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          window.location.href = `mailto:${inquiry.email}`;
                        }}
                      >
                        <Mail size={16} className="mr-2" />
                        Reply via Email
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          window.location.href = `tel:${inquiry.phone}`;
                        }}
                      >
                        <Phone size={16} className="mr-2" />
                        Call Buyer
                      </Button>
                    </div>
                  </div>
                )}
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
