import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Loader2, Trash2, Edit2, ArrowLeft, Eye } from "lucide-react";
import { toast } from "sonner";
import Header from "@/components/Header";

export default function AdminListings() {
  const { user, loading } = useAuth({ redirectOnUnauthenticated: true, redirectPath: "/auth" });
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");

  // Redirect non-admins
  if (!loading && user?.role !== "admin") {
    setLocation("/");
    return null;
  }

  // Fetch all listings
  const { data: listings = [], isLoading, refetch } = trpc.admin.getAllListings.useQuery();
  const deleteListingMutation = trpc.admin.deleteListing.useMutation();

  // Filter listings based on search
  const filteredListings = listings.filter(
    (car) =>
      car.brand?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      car.model?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      car.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDeleteListing = async (carId: number) => {
    if (!confirm("Are you sure you want to delete this listing? This action cannot be undone.")) {
      return;
    }

    try {
      await deleteListingMutation.mutateAsync({ carId });
      toast.success("Listing deleted successfully");
      refetch();
    } catch (error: any) {
      toast.error(error?.message || "Failed to delete listing");
    }
  };

  const handleViewDetails = (carId: number) => {
    setLocation(`/admin/listings/${carId}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="flex items-center justify-center h-screen">
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto py-8 px-4">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-4 mb-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLocation("/admin")}
                className="gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Dashboard
              </Button>
            </div>
            <h1 className="text-3xl font-bold">Manage Listings</h1>
            <p className="text-muted-foreground">View and manage all car listings</p>
          </div>
        </div>

        {/* Search & Filter */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Search Listings</CardTitle>
          </CardHeader>
          <CardContent>
            <Input
              placeholder="Search by brand, model, or description..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-md"
            />
          </CardContent>
        </Card>

        {/* Listings Grid */}
        <Card>
          <CardHeader>
            <CardTitle>All Listings ({filteredListings.length})</CardTitle>
            <CardDescription>
              Total: {listings.length} listings | Showing: {filteredListings.length}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
              </div>
            ) : filteredListings.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No listings found</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredListings.map((car) => (
                  <Card key={car.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                    {/* Car Image Placeholder */}
                    <div className="w-full h-40 bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                      <div className="text-center">
                        <p className="text-muted-foreground text-sm font-medium">{car.year} {car.brand}</p>
                        <p className="text-muted-foreground text-xs">{car.model}</p>
                      </div>
                    </div>

                    <CardContent className="p-4">
                      {/* Title */}
                      <h3 className="font-bold text-lg mb-1">
                        {car.year} {car.brand} {car.model}
                      </h3>

                      {/* Details */}
                      <div className="space-y-2 mb-4 text-sm text-muted-foreground">
                        <p>
                          <span className="font-semibold">Price:</span> ${car.price?.toLocaleString() || "N/A"}
                        </p>
                        <p>
                          <span className="font-semibold">Kilometers:</span> {car.kilometers?.toLocaleString() || "N/A"} km
                        </p>
                        <p>
                          <span className="font-semibold">Transmission:</span> {car.transmission || "N/A"}
                        </p>
                        <p>
                          <span className="font-semibold">Fuel:</span> {car.fuelType || "N/A"}
                        </p>
                      </div>

                      {/* Actions */}
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleViewDetails(car.id)}
                          className="flex-1 gap-1"
                        >
                          <Eye className="w-3 h-3" />
                          View
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDeleteListing(car.id)}
                          disabled={deleteListingMutation.isPending}
                          className="gap-1"
                        >
                          <Trash2 className="w-3 h-3" />
                          Delete
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
