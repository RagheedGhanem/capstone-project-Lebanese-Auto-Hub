import { useState, useRef, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Car, Send, Loader2, Bot, User } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { Streamdown } from "streamdown";
import Header from "@/components/Header";
import CarCard from "@/components/CarCard";

interface Message {
  role: "user" | "assistant";
  content: string;
  cars?: Array<{
    id: number;
    brand: string;
    model: string;
    year: number;
    price: string;
    kilometers: number;
    transmission: string;
    fuelType: string;
    condition: string;
    sellerName: string;
    sellerPhone: string;
    sellerEmail: string;
    sellerLocation: string;
    carType: string;
    color: string;
  }>;
}

export default function ChatAssistant() {
  const [sessionId] = useState(() => `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [lastSearchPreferences, setLastSearchPreferences] = useState<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: history, isLoading: historyLoading } = trpc.chat.getHistory.useQuery({ sessionId });
  
  const searchCars = trpc.chat.searchCars.useMutation({
    onSuccess: (data) => {
      const newMessage: Message = {
        role: "assistant",
        content: data.message,
        cars: data.listings,
      };
      setMessages(prev => [...prev, newMessage]);
      // Store preferences for context refinement
      if (data.preferences) {
        setLastSearchPreferences(data.preferences);
      }
    },
    onError: (error) => {
      toast.error(`Failed to search cars: ${error.message}`);
    },
  });

  const sendMessage = trpc.chat.sendMessage.useMutation({
    onSuccess: (data) => {
      const newMessage: Message = {
        role: "assistant",
        content: data.message,
        cars: data.listings,
      };
      setMessages(prev => [...prev, newMessage]);
      // Store preferences for context refinement
      if (data.preferences) {
        setLastSearchPreferences(data.preferences);
      }
    },
    onError: (error) => {
      toast.error(`Failed to send message: ${error.message}`);
    },
  });

  useEffect(() => {
    if (history && Array.isArray(history) && history.length > 0) {
      setMessages(history as Message[]);
    } else if (!historyLoading && messages.length === 0) {
      // Welcome message
      setMessages([{
        role: "assistant",
        content: "Hello! I'm your AI car shopping assistant. I'm here to help you find the perfect car in Lebanon. \n\nTo get started, I'd like to know:\n- What type of car are you looking for? (sedan, SUV, coupe, etc.)\n- What's your budget range?\n- Do you have any brand preferences?\n- What will you primarily use the car for?\n\nFeel free to share as much or as little as you'd like!"
      }]);
    }
  }, [history, historyLoading]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || sendMessage.isPending || searchCars.isPending) return;

    const userMessage = input.trim();
    setMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setInput("");

    // Detect if this is a car search query
    const carSearchKeywords = ["looking for", "find", "search", "car", "vehicle", "brand", "model", "price", "budget", "mileage", "sedan", "suv", "truck", "coupe", "automatic", "manual", "diesel", "gasoline", "electric", "cheaper", "expensive", "newer", "older", "show me"];
    const isCarSearch = carSearchKeywords.some(keyword => userMessage.toLowerCase().includes(keyword));

    if (isCarSearch) {
      searchCars.mutate({
        userQuery: userMessage,
        conversationHistory: messages,
        previousPreferences: lastSearchPreferences,
      });
    } else {
      sendMessage.mutate({
        sessionId,
        message: userMessage,
        conversationHistory: messages,
        previousPreferences: lastSearchPreferences,
      });
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <Header />

      <div className="flex-1 container py-8 flex flex-col max-w-5xl">
        <div className="mb-6">
          <h1 className="text-4xl font-bold mb-2">AI Car Assistant</h1>
          <p className="text-muted-foreground">Chat with our AI to find your perfect car</p>
        </div>

        {/* Chat Container */}
        <Card className="flex-1 flex flex-col glass">
          <CardHeader className="border-b border-border">
            <CardTitle className="flex items-center">
              <Bot className="mr-2 h-6 w-6 text-primary" />
              Chat Assistant
            </CardTitle>
          </CardHeader>
          
          {/* Messages */}
          <CardContent className="flex-1 overflow-y-auto p-6 space-y-4" style={{ maxHeight: "calc(100vh - 350px)" }}>
            {messages.map((message, index) => (
              <div key={index}>
                <div
                  className={`flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  {message.role === "assistant" && (
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Bot className="h-5 w-5 text-primary" />
                      </div>
                    </div>
                  )}
                  
                  <div
                    className={`max-w-[80%] rounded-lg p-4 ${
                      message.role === "user"
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted"
                    }`}
                  >
                    {message.role === "assistant" ? (
                      <Streamdown>{message.content}</Streamdown>
                    ) : (
                      <p className="whitespace-pre-wrap">{message.content}</p>
                    )}
                  </div>

                  {message.role === "user" && (
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                        <User className="h-5 w-5 text-primary-foreground" />
                      </div>
                    </div>
                  )}
                </div>

                {/* Display car cards if available */}
                {message.cars && message.cars.length > 0 && (
                  <div className="mt-4 space-y-3 ml-14">
                    {message.cars.map((car) => (
                      <CarCard
                        key={car.id}
                        {...car}
                        compact={true}
                      />
                    ))}
                  </div>
                )}
              </div>
            ))}
            
            {(sendMessage.isPending || searchCars.isPending) && (
              <div className="flex gap-3 justify-start">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Bot className="h-5 w-5 text-primary" />
                  </div>
                </div>
                <div className="bg-muted rounded-lg p-4">
                  <Loader2 className="h-5 w-5 animate-spin text-primary" />
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </CardContent>

          {/* Input */}
          <div className="border-t border-border p-4">
            <form onSubmit={handleSubmit} className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your message..."
                disabled={sendMessage.isPending || searchCars.isPending}
                className="flex-1"
              />
              <Button 
                type="submit" 
                disabled={!input.trim() || sendMessage.isPending || searchCars.isPending}
                className="gradient-gold"
              >
                {sendMessage.isPending || searchCars.isPending ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <Send className="h-5 w-5" />
                )}
              </Button>
            </form>
          </div>
        </Card>

        {/* Quick Actions */}
        <div className="mt-4 flex gap-2 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setInput("I'm looking for a family SUV under $30,000")}
            disabled={sendMessage.isPending || searchCars.isPending}
          >
            Family SUV
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setInput("Show me luxury sedans from 2020 or newer")}
            disabled={sendMessage.isPending || searchCars.isPending}
          >
            Luxury Sedan
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setInput("I need a fuel-efficient car for city driving")}
            disabled={sendMessage.isPending || searchCars.isPending}
          >
            Fuel Efficient
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setInput("What's the best car for off-road driving in Lebanon?")}
            disabled={sendMessage.isPending || searchCars.isPending}
          >
            Off-Road
          </Button>
        </div>
      </div>
    </div>
  );
}
