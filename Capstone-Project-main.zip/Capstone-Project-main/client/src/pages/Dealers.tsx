import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, Phone, Mail, Globe, Loader2 } from "lucide-react";
import { MapView, MarkerDef } from "@/components/Map";
import Header from "@/components/Header";

export default function Dealers() {
  const { data: dealers, isLoading } = trpc.dealers.list.useQuery();
  const [selectedDealer, setSelectedDealer] = useState<number | null>(null);

  const markers: MarkerDef[] = useMemo(() => {
    if (!dealers) return [];
    return dealers
      .filter((d) => d.latitude && d.longitude)
      .map((d) => ({
        id: d.id,
        lat: typeof d.latitude === "string" ? parseFloat(d.latitude) : Number(d.latitude),
        lng: typeof d.longitude === "string" ? parseFloat(d.longitude) : Number(d.longitude),
        title: d.name,
        onClick: () => setSelectedDealer(d.id),
      }));
  }, [dealers]);

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Lebanese Car Dealerships</h1>
          <p className="text-muted-foreground">Explore verified dealerships across Lebanon</p>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Dealers List */}
            <div className="lg:col-span-1 space-y-4 max-h-[800px] overflow-y-auto">
              {dealers && dealers.length > 0 ? (
                dealers.map((dealer) => (
                  <Card
                    key={dealer.id}
                    className={`card-hover glass cursor-pointer ${
                      selectedDealer === dealer.id ? "border-primary" : ""
                    }`}
                    onClick={() => setSelectedDealer(dealer.id)}
                  >
                    <CardHeader>
                      <CardTitle>{dealer.name}</CardTitle>
                      {dealer.description && (
                        <CardDescription>{dealer.description}</CardDescription>
                      )}
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between items-start gap-4">
                        <div className="flex-1 space-y-2">
                          {dealer.address && (
                            <div className="flex items-start gap-2 text-sm">
                              <MapPin className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                              <span className="text-muted-foreground">{dealer.address}</span>
                            </div>
                          )}
                          {dealer.phone && (
                            <div className="flex items-center gap-2 text-sm">
                              <Phone className="h-4 w-4 text-primary flex-shrink-0" />
                              <a href={`tel:${dealer.phone}`} className="text-muted-foreground hover:text-primary">
                                {dealer.phone}
                              </a>
                            </div>
                          )}
                          {dealer.email && (
                            <div className="flex items-center gap-2 text-sm">
                              <Mail className="h-4 w-4 text-primary flex-shrink-0" />
                              <a href={`mailto:${dealer.email}`} className="text-muted-foreground hover:text-primary">
                                {dealer.email}
                              </a>
                            </div>
                          )}
                          {dealer.website && (
                            <div className="flex items-center gap-2 text-sm">
                              <Globe className="h-4 w-4 text-primary flex-shrink-0" />
                              <a href={dealer.website} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary truncate">
                                {dealer.website}
                              </a>
                            </div>
                          )}
                        </div>
                        {dealer.logoUrl && (
                          <div className="flex-shrink-0">
                            <img
                              src={dealer.logoUrl}
                              alt={dealer.name}
                              className="h-16 w-16 object-contain rounded"
                              onError={(e) => { e.currentTarget.style.display = "none"; }}
                            />
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card className="glass">
                  <CardContent className="py-12 text-center">
                    <MapPin className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">No dealerships available yet</p>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Map — always rendered, shows markers when dealers have coordinates */}
            <div className="lg:col-span-2">
              <Card className="glass overflow-hidden h-[800px]">
                <CardContent className="p-0 h-full">
                  <MapView
                    markers={markers}
                    selectedId={selectedDealer}
                    initialCenter={{ lat: 33.8938, lng: 35.5018 }}
                    initialZoom={10}
                    className="w-full h-full"
                  />
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
