import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Car, Search, MessageSquare, TrendingUp, MapPin, Shield } from "lucide-react";
import Header from "@/components/Header";

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      {/* Hero Section */}
      <section className="py-20 md:py-32 bg-gradient-to-b from-background via-background to-card/20">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              Find Your Perfect Car in <span className="text-gradient">Lebanon</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Discover the most comprehensive car marketplace in Lebanon. Buy, sell, or trade with confidence using our AI-powered platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="gradient-gold text-lg px-8" onClick={() => window.location.href = '/browse'}>
                <Search className="mr-2 h-5 w-5" />
                Browse Cars
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8 border-primary hover:bg-primary/10" onClick={() => window.location.href = '/sell'}>
                <Car className="mr-2 h-5 w-5" />
                Sell Your Car
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">Why Choose Lebanese Auto Hub?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="glass border-primary/10 hover:border-primary/30 transition-colors">
              <CardHeader>
                <Search className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Smart Search</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Filter by brand, model, year, color, and more. Find exactly what you're looking for with our advanced search.
                </p>
              </CardContent>
            </Card>

            <Card className="glass border-primary/10 hover:border-primary/30 transition-colors">
              <CardHeader>
                <MessageSquare className="h-8 w-8 text-primary mb-2" />
                <CardTitle>AI Chat Assistant</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Chat with our AI assistant to get personalized car recommendations based on your preferences.
                </p>
              </CardContent>
            </Card>

            <Card className="glass border-primary/10 hover:border-primary/30 transition-colors">
              <CardHeader>
                <TrendingUp className="h-8 w-8 text-primary mb-2" />
                <CardTitle>AI Valuation</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Get instant, AI-powered valuations of your car based on market data and condition analysis.
                </p>
              </CardContent>
            </Card>

            <Card className="glass border-primary/10 hover:border-primary/30 transition-colors">
              <CardHeader>
                <MapPin className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Dealer Network</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Connect with trusted Lebanese dealerships and view their complete inventory in one place.
                </p>
              </CardContent>
            </Card>

            <Card className="glass border-primary/10 hover:border-primary/30 transition-colors">
              <CardHeader>
                <Shield className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Secure Communication</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Connect directly with buyers and sellers. Our platform keeps your messages private and protected.
                </p>
              </CardContent>
            </Card>

            <Card className="glass border-primary/10 hover:border-primary/30 transition-colors">
              <CardHeader>
                <Car className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Trade-In Support</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Get trade-in recommendations and valuations to make your next purchase easier.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-primary/10 to-primary/5 border-t border-b border-primary/20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Find Your Perfect Car?</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands of satisfied buyers and sellers on Lebanon's most trusted car marketplace.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="gradient-gold text-lg px-8" onClick={() => window.location.href = '/browse'}>
              <Search className="mr-2 h-5 w-5" />
              Start Browsing
            </Button>
            <Button size="lg" variant="outline" className="text-lg px-8 border-primary hover:bg-primary/10" onClick={() => window.location.href = '/auth'}>
              <Car className="mr-2 h-5 w-5" />
              List My Car
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card/30 py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold mb-4">About Us</h3>
              <p className="text-sm text-muted-foreground">
                Lebanese Auto Hub is your trusted marketplace for buying, selling, and trading cars in Lebanon.
              </p>
            </div>
            <div>
              <h3 className="font-bold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-sm">
                <li><button onClick={() => window.location.href = '/browse'} className="text-muted-foreground hover:text-primary cursor-pointer">Browse Cars</button></li>
                <li><button onClick={() => window.location.href = '/auth'} className="text-muted-foreground hover:text-primary cursor-pointer">List My Car</button></li>
                <li><button onClick={() => window.location.href = '/dealers'} className="text-muted-foreground hover:text-primary cursor-pointer">Dealers</button></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-4">Features</h3>
              <ul className="space-y-2 text-sm">
                <li><button onClick={() => window.location.href = '/valuation'} className="text-muted-foreground hover:text-primary cursor-pointer">AI Valuation</button></li>
                <li><button onClick={() => window.location.href = '/chat'} className="text-muted-foreground hover:text-primary cursor-pointer">AI Assistant</button></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-4">Contact</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Email: info@autohub.lb</li>
                <li>Phone: +961 1 234 567</li>
                <li>Beirut, Lebanon</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 Lebanese Auto Hub. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
