import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, MapPin, Phone, Mail, Heart } from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { useAuthContext } from "@/contexts/AuthContext";

export default function CarDetail() {
  const [, navigate] = useLocation();
  const { user } = useAuthContext();
  const [carId, setCarId] = useState<number | null>(null);
  const [inquiryMessage, setInquiryMessage] = useState("");
  const [isFavorite, setIsFavorite] = useState(false);
  const [contactInfo, setContactInfo] = useState({
    name: "",
    email: "",
    phone: "",
  });

  // Extract car ID from route parameter (/car/:id)
  useEffect(() => {
    // Try to get ID from URL path parameter first
    const pathMatch = window.location.pathname.match(/\/car\/(\d+)/);
    if (pathMatch && pathMatch[1]) {
      const id = parseInt(pathMatch[1]);
      if (!isNaN(id)) {
        setCarId(id);
        return;
      }
    }
    
    // Fallback to query string parameter
    const params = new URLSearchParams(window.location.search);
    const queryId = params.get("id");
    if (queryId) {
      const id = parseInt(queryId);
      if (!isNaN(id)) {
        setCarId(id);
      }
    }
  }, []);

  // Fetch car details
  const { data: car, isLoading: carLoading, error: carError } = trpc.cars.getById.useQuery(
    { id: carId || 0 },
    { enabled: carId !== null }
  );
  


  // Fetch car images
  const { data: images } = trpc.cars.getImages.useQuery(
    { carId: carId || 0 },
    { enabled: carId !== null }
  );

  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Check if car is favorited
  const { data: isFavoritedData } = trpc.favorites.isFavorited.useQuery(
    { carId: carId || 0 },
    { enabled: carId !== null && !!user }
  );

  // Add favorite mutation
  const addFavoriteMutation = trpc.favorites.add.useMutation({
    onSuccess: () => {
      toast.success("Added to favorites!");
      setIsFavorite(true);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to add to favorites");
    },
  });

  // Remove favorite mutation
  const removeFavoriteMutation = trpc.favorites.remove.useMutation({
    onSuccess: () => {
      toast.success("Removed from favorites");
      setIsFavorite(false);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to remove from favorites");
    },
  });

  // Update favorite state when data loads
  useEffect(() => {
    if (isFavoritedData !== undefined) {
      setIsFavorite(isFavoritedData);
    }
  }, [isFavoritedData]);

  const handleToggleFavorite = () => {
    if (!user) {
      toast.error("Please sign in to add favorites");
      navigate("/auth");
      return;
    }

    if (!carId) return;

    if (isFavorite) {
      removeFavoriteMutation.mutate({ carId });
    } else {
      addFavoriteMutation.mutate({ carId });
    }
  };

  // Create inquiry mutation
  const createInquiryMutation = trpc.inquiries.create.useMutation({
    onSuccess: () => {
      toast.success("Inquiry submitted successfully!");
      setInquiryMessage("");
      setContactInfo({ name: "", email: "", phone: "" });
    },
    onError: (error) => {
      toast.error(error.message || "Failed to submit inquiry");
    },
  });

  const handleSubmitInquiry = () => {
    if (!car) return;
    if (!contactInfo.name || !contactInfo.email || !contactInfo.phone) {
      toast.error("Please fill in all contact information");
      return;
    }

    // Log inquiry submission for debugging
    console.log("Submitting inquiry:", {
      buyerName: contactInfo.name,
      buyerEmail: contactInfo.email,
      buyerPhone: contactInfo.phone,
      carId: car.id,
      sellerEmail: car.sellerEmail,
      hasMessage: !!inquiryMessage,
    });

    createInquiryMutation.mutate({
      name: contactInfo.name,
      email: contactInfo.email,
      phone: contactInfo.phone,
      additionalNotes: inquiryMessage,
      brand: car.brand,
      model: car.model,
      carType: car.carType,
      year: car.year,
      color: car.color,
      carId: car.id,
      sellerEmail: car.sellerEmail || undefined,
    });
  };

  if (carLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading car details...</p>
        </div>
      </div>
    );
  }

  if (!car) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <p className="text-lg font-semibold mb-2">Car not found</p>
          <p className="text-muted-foreground mb-4">The car you're looking for doesn't exist or has been removed.</p>
          <Button onClick={() => navigate("/browse")}>Back to Browse</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate("/browse")}
            className="flex items-center gap-2 text-primary hover:text-primary/80 transition"
          >
            <ArrowLeft size={20} />
            <span>Back to Browse</span>
          </button>
          <h1 className="text-2xl font-bold">Car Details</h1>
          <button
            onClick={handleToggleFavorite}
            className="p-2 hover:bg-accent rounded-lg transition"
            disabled={addFavoriteMutation.isPending || removeFavoriteMutation.isPending}
          >
            <Heart
              size={24}
              className={isFavorite ? "fill-red-500 text-red-500" : ""}
            />
          </button>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Car Images & Details */}
          <div className="lg:col-span-2">
            {/* Main Image */}
            <Card className="mb-6 overflow-hidden bg-card">
              <div className="aspect-video bg-muted flex items-center justify-center relative">
                {images && images.length > 0 ? (
                  <>
                    <img
                      src={images[currentImageIndex]?.imageUrl || ""}
                      alt={`${car.brand} ${car.model}`}
                      className="w-full h-full object-cover"
                    />
                    {images.length > 1 && (
                      <>
                        <button
                          onClick={() =>
                            setCurrentImageIndex((prev) =>
                              prev === 0 ? images.length - 1 : prev - 1
                            )
                          }
                          className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors"
                        >
                          ←
                        </button>
                        <button
                          onClick={() =>
                            setCurrentImageIndex((prev) =>
                              prev === images.length - 1 ? 0 : prev + 1
                            )
                          }
                          className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors"
                        >
                          →
                        </button>
                        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 bg-black/50 text-white px-3 py-1 rounded-full text-sm">
                          {currentImageIndex + 1} / {images.length}
                        </div>
                      </>
                    )}
                  </>
                ) : (
                  <div className="text-center">
                    <p className="text-muted-foreground">No image available</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Images will be displayed here when uploaded
                    </p>
                  </div>
                )}
              </div>
            </Card>

            {/* Copy Link Button - Below Image */}
            <Card className="p-4 bg-card mb-6">
              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  const url = window.location.href;
                  navigator.clipboard.writeText(url);
                  toast.success("Link copied to clipboard!");
                }}
              >
                Copy Link
              </Button>
            </Card>

            {/* Image Thumbnails */}
            {images && images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto mb-6 pb-2">
                {images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors ${
                      index === currentImageIndex
                        ? "border-primary"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <img
                      src={image.imageUrl}
                      alt={`Thumbnail ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}

            {/* Car Specifications */}
            <Card className="p-6 bg-card mb-6">
              <h2 className="text-2xl font-bold mb-6">
                {car.year} {car.brand} {car.model}
              </h2>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                <div>
                  <Label className="text-muted-foreground">Brand</Label>
                  <p className="text-lg font-semibold">{car.brand}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Model</Label>
                  <p className="text-lg font-semibold">{car.model}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Year</Label>
                  <p className="text-lg font-semibold">{car.year}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Type</Label>
                  <p className="text-lg font-semibold capitalize">{car.carType}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Color</Label>
                  <p className="text-lg font-semibold capitalize">{car.color}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Kilometers</Label>
                  <p className="text-lg font-semibold">
                    {car.kilometers?.toLocaleString() || "N/A"} km
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Condition</Label>
                  <p className="text-lg font-semibold capitalize">
                    {car.condition || "N/A"}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Transmission</Label>
                  <p className="text-lg font-semibold capitalize">
                    {car.transmission || "N/A"}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Fuel Type</Label>
                  <p className="text-lg font-semibold capitalize">
                    {car.fuelType || "N/A"}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Engine Size</Label>
                  <p className="text-lg font-semibold">
                    {car.engineSize || "N/A"}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Price</Label>
                  <p className="text-2xl font-bold text-primary">
                    ${parseFloat(car.price || "0").toLocaleString() || "Contact for price"}
                  </p>
                </div>
              </div>

              {/* Description */}
              {car.description && (
                <div className="mt-8 pt-8 border-t border-border">
                  <h3 className="text-lg font-semibold mb-4">Description</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {car.description}
                  </p>
                </div>
              )}
            </Card>
          </div>

          {/* Right Column - Contact & Inquiry */}
          <div className="lg:col-span-1">
            {/* Seller Contact Card */}
            <Card className="p-6 bg-card mb-6 sticky top-24 max-h-[calc(100vh-7rem)] overflow-y-auto">
              <h3 className="text-xl font-bold mb-6">Contact Seller</h3>

              <div className="space-y-4 mb-6">
                {car?.sellerName && (
                  <div>
                    <p className="text-sm text-muted-foreground">Seller</p>
                    <p className="font-semibold">{car.sellerName}</p>
                  </div>
                )}
                {car?.sellerLocation && (
                  <div className="flex items-center gap-3">
                    <MapPin size={18} className="text-primary flex-shrink-0" />
                    <div>
                      <p className="text-sm text-muted-foreground">Location</p>
                      <p className="font-semibold">{car.sellerLocation}</p>
                    </div>
                  </div>
                )}
                {car?.sellerPhone && (
                  <div className="flex items-center gap-3">
                    <Phone size={18} className="text-primary flex-shrink-0" />
                    <div>
                      <p className="text-sm text-muted-foreground">Phone</p>
                      <p className="font-semibold">{car.sellerPhone}</p>
                    </div>
                  </div>
                )}
                {car?.sellerEmail && (
                  <div className="flex items-center gap-3">
                    <Mail size={18} className="text-primary flex-shrink-0" />
                    <div>
                      <p className="text-sm text-muted-foreground">Email</p>
                      <p className="font-semibold">{car.sellerEmail}</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Inquiry Form */}
              <div className="space-y-4 border-t border-border pt-6">
                <div>
                  <Label htmlFor="name" className="text-sm">
                    Name
                  </Label>
                  <Input
                    id="name"
                    placeholder="Enter your name"
                    value={contactInfo.name}
                    onChange={(e) =>
                      setContactInfo({ ...contactInfo, name: e.target.value })
                    }
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label htmlFor="email" className="text-sm">
                    Email
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter your email"
                    value={contactInfo.email}
                    onChange={(e) =>
                      setContactInfo({ ...contactInfo, email: e.target.value })
                    }
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label htmlFor="phone" className="text-sm">
                    Phone
                  </Label>
                  <Input
                    id="phone"
                    placeholder="Enter your phone number"
                    value={contactInfo.phone}
                    onChange={(e) =>
                      setContactInfo({ ...contactInfo, phone: e.target.value })
                    }
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label htmlFor="message" className="text-sm">
                    Additional Notes (Optional)
                  </Label>
                  <Textarea
                    id="message"
                    placeholder="Ask any questions about the car..."
                    value={inquiryMessage}
                    onChange={(e) => setInquiryMessage(e.target.value)}
                    className="mt-2 resize-none"
                    rows={4}
                  />
                </div>

                <Button
                  onClick={handleSubmitInquiry}
                  disabled={createInquiryMutation.isPending}
                  className="w-full bg-primary hover:bg-primary/90"
                >
                  {createInquiryMutation.isPending
                    ? "Submitting..."
                    : "Send Inquiry"}
                </Button>
              </div>
            </Card>


          </div>
        </div>
      </div>
    </div>
  );
}
