import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, FileText, ArrowRight } from "lucide-react";
import Header from "@/components/Header";
import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";

export default function AdminDashboard() {
  const { user, loading } = useAuth({ redirectOnUnauthenticated: true, redirectPath: "/auth" });
  const [, setLocation] = useLocation();
  
  // Use tRPC hook for statistics - call at top level
  const { data: statsData, isLoading: statsLoading, error: statsError } = trpc.admin.getStatistics.useQuery(undefined, {
    enabled: user?.role === "admin" && !loading,
  });
  
  // Default stats
  const stats = statsData || { totalUsers: 0, activeListings: 0, adminCount: 0 };

  // Redirect non-admins
  if (!loading && user?.role !== "admin") {
    setLocation("/");
    return null;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="flex items-center justify-center h-screen">
          <p className="text-muted-foreground">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  const adminSections = [
    {
      title: "Manage Users",
      description: "View, edit, and manage all user accounts",
      icon: Users,
      href: "/admin/users",
      color: "bg-blue-50 border-blue-200",
      iconColor: "text-blue-600",
    },
    {
      title: "Manage Listings",
      description: "View, edit, and moderate all car listings",
      icon: FileText,
      href: "/admin/listings",
      color: "bg-green-50 border-green-200",
      iconColor: "text-green-600",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto py-8 px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Admin Dashboard</h1>
          <p className="text-muted-foreground">Manage your platform and monitor system activity</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Users</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{statsLoading ? "--" : stats.totalUsers}</div>
              <p className="text-xs text-muted-foreground mt-1">Registered accounts</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Listings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{statsLoading ? "--" : stats.activeListings}</div>
              <p className="text-xs text-muted-foreground mt-1">Car listings</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Admins</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{statsLoading ? "--" : stats.adminCount}</div>
              <p className="text-xs text-muted-foreground mt-1">Admin accounts</p>
            </CardContent>
          </Card>
        </div>

        {/* Admin Sections Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {adminSections.map((section) => {
            const Icon = section.icon;
            return (
              <Card
                key={section.href}
                className={`${section.color} border cursor-pointer hover:shadow-lg transition-shadow`}
                onClick={() => setLocation(section.href)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-xl mb-2">{section.title}</CardTitle>
                      <CardDescription>{section.description}</CardDescription>
                    </div>
                    <Icon className={`${section.iconColor} w-8 h-8 flex-shrink-0`} />
                  </div>
                </CardHeader>
                <CardContent>
                  <Button
                    variant="outline"
                    className="w-full justify-between"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLocation(section.href);
                    }} style={{color: '#000000', backgroundColor: '#a3a3a3'}}
                  >
                    <span>Go to {section.title}</span>
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </main>
    </div>
  );
}
