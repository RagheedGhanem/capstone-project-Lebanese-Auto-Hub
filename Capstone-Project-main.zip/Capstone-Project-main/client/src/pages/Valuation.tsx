import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Car, TrendingUp, Loader2, DollarSign, CheckCircle2 } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";
import { Streamdown } from "streamdown";
import ImageUpload from "@/components/ImageUpload";
import Header from "@/components/Header";

export default function Valuation() {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [formData, setFormData] = useState({
    brand: "",
    model: "",
    year: new Date().getFullYear(),
    kilometers: 0,
    condition: "good",
    description: "",
  });
  const [uploadedImages, setUploadedImages] = useState<File[]>([]);
  const [valuation, setValuation] = useState<{
    valuationId: number;
    estimatedValue: number;
    valuationDetails: string;
    imageAnalysis: string;
  } | null>(null);

  const estimateValue = trpc.valuation.estimate.useMutation({
    onSuccess: (data) => {
      setValuation({
        valuationId: data.id,
        estimatedValue: data.estimatedValue,
        valuationDetails: data.details,
        imageAnalysis: "",
      });
      toast.success("Valuation completed successfully!");
    },
    onError: (error) => {
      toast.error(`Failed to estimate value: ${error.message}`);
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.brand || !formData.model) {
      toast.error("Please fill in all required fields");
      return;
    }

    // Upload images if any were selected
    let imageUrls: string[] = [];
    if (uploadedImages.length > 0) {
      const formDataToSend = new FormData();
      uploadedImages.forEach((file) => {
        formDataToSend.append('images', file);
      });
      
      try {
        const response = await fetch('/api/upload-valuation-images', {
          method: 'POST',
          body: formDataToSend,
        });
        
        if (!response.ok) {
          throw new Error('Failed to upload images');
        }
        
        const data = await response.json();
        imageUrls = data.imageUrls || [];
      } catch (error) {
        toast.error('Failed to upload images. Continuing without them...');
      }
    }

    // Send valuation request with image URLs
    estimateValue.mutate({
      ...formData,
      imageUrls: imageUrls,
    });
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-20">
          <Card className="max-w-md mx-auto glass">
            <CardContent className="pt-6 text-center">
              <h2 className="text-2xl font-bold mb-4">Sign In Required</h2>
              <p className="text-muted-foreground mb-6">
                Please sign in to get your car valuation
              </p>
              <Button className="gradient-gold" onClick={() => window.location.href = getLoginUrl()}>
                Sign In
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <Header />

      <div className="container py-8 max-w-6xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">AI Car Valuation</h1>
          <p className="text-muted-foreground">Get an instant, AI-powered estimate of your car's market value</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Valuation Form */}
          <div>
            <form onSubmit={handleSubmit}>
              <Card className="glass">
                <CardHeader>
                  <CardTitle>Vehicle Information</CardTitle>
                  <CardDescription>Provide details about your car for accurate valuation</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="brand">Brand *</Label>
                    <Input
                      id="brand"
                      placeholder="e.g., Toyota"
                      value={formData.brand}
                      onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="model">Model *</Label>
                    <Input
                      id="model"
                      placeholder="e.g., Camry"
                      value={formData.model}
                      onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="year">Year *</Label>
                    <Input
                      id="year"
                      type="number"
                      value={formData.year || ''}
                      onChange={(e) => setFormData({ ...formData, year: e.target.value ? parseInt(e.target.value) : 0 })}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="kilometers">Kilometers *</Label>
                    <Input
                      id="kilometers"
                      type="number"
                      placeholder="e.g., 50000"
                      value={formData.kilometers || ''}
                      onChange={(e) => setFormData({ ...formData, kilometers: e.target.value ? parseInt(e.target.value) : 0 })}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="condition">Condition *</Label>
                    <Select value={formData.condition} onValueChange={(value) => setFormData({ ...formData, condition: value })} required>
                      <SelectTrigger id="condition">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="new">New</SelectItem>
                        <SelectItem value="excellent">Excellent</SelectItem>
                        <SelectItem value="good">Good</SelectItem>
                        <SelectItem value="fair">Fair</SelectItem>
                        <SelectItem value="poor">Poor</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="description">Additional Details</Label>
                    <Textarea
                      id="description"
                      placeholder="Describe any special features, modifications, or issues..."
                      rows={4}
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    />
                  </div>

                  <div>
                    <Label>Car Photos (Optional)</Label>
                    <p className="text-sm text-muted-foreground mb-4">Upload photos for AI image analysis to improve valuation accuracy</p>
                    <ImageUpload
                      onImagesSelected={setUploadedImages}
                      maxFiles={5}
                      maxSizeMB={15}
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full gradient-gold text-lg py-6"
                    disabled={estimateValue.isPending}
                  >
                    {estimateValue.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <TrendingUp className="mr-2 h-5 w-5" />
                        Get Valuation
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </form>
          </div>

          {/* Valuation Results */}
          <div>
            {valuation ? (
              <div className="space-y-6">
                <Card className="glass border-primary/20">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <CheckCircle2 className="mr-2 h-6 w-6 text-primary" />
                      Valuation Complete
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-6">
                      <p className="text-sm text-muted-foreground mb-2">Estimated Market Value</p>
                      <div className="flex items-center justify-center">
                        <DollarSign className="h-8 w-8 text-primary" />
                        <span className="text-5xl font-bold text-gradient">
                          {valuation.estimatedValue.toLocaleString()}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-2">USD</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="glass">
                  <CardHeader>
                    <CardTitle>Detailed Analysis</CardTitle>
                  </CardHeader>
                  <CardContent className="prose prose-invert max-w-none">
                    <Streamdown>{valuation.valuationDetails}</Streamdown>
                  </CardContent>
                </Card>

                {valuation.imageAnalysis && (
                  <Card className="glass">
                    <CardHeader>
                      <CardTitle>Condition Assessment</CardTitle>
                    </CardHeader>
                    <CardContent className="prose prose-invert max-w-none">
                      <Streamdown>{valuation.imageAnalysis}</Streamdown>
                    </CardContent>
                  </Card>
                )}

                <Card className="glass border-primary/20">
                  <CardContent className="pt-6">
                    <h3 className="font-semibold mb-4">What's Next?</h3>
                    <div className="space-y-3">
                      <Button className="w-full gradient-gold" onClick={() => window.location.href = '/sell'}>
                        <Car className="mr-2 h-4 w-4" />
                        List Your Car for Sale
                      </Button>
                      <Button variant="outline" className="w-full border-primary" onClick={() => window.location.href = '/browse'}>
                        <TrendingUp className="mr-2 h-4 w-4" />
                        Browse Trade-In Options
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card className="glass">
                <CardContent className="py-20 text-center">
                  <TrendingUp className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">Get Your Instant Valuation</h3>
                  <p className="text-muted-foreground">
                    Fill in the form to receive an AI-powered estimate of your car's market value
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
