import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Car, Send, Loader2, CheckCircle2 } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import Header from "@/components/Header";

export default function Inquiry() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    brand: "",
    model: "",
    carType: "",
    year: undefined as number | undefined,
    color: "",
    minPrice: undefined as number | undefined,
    maxPrice: undefined as number | undefined,
    additionalNotes: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const createInquiry = trpc.inquiries.create.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      toast.success("Your inquiry has been submitted successfully!");
    },
    onError: (error) => {
      toast.error(`Failed to submit inquiry: ${error.message}`);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email) {
      toast.error("Please fill in your name and email");
      return;
    }

    createInquiry.mutate({
      ...formData,
      minPrice: formData.minPrice !== undefined ? String(formData.minPrice) : undefined,
      maxPrice: formData.maxPrice !== undefined ? String(formData.maxPrice) : undefined,
    });
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-20">
          <Card className="max-w-2xl mx-auto glass text-center">
            <CardContent className="pt-12 pb-12">
              <CheckCircle2 className="h-20 w-20 text-primary mx-auto mb-6" />
              <h2 className="text-3xl font-bold mb-4">Inquiry Submitted!</h2>
              <p className="text-muted-foreground mb-8">
                Thank you for your inquiry. Our team will review your requirements and get back to you soon with matching options.
              </p>
              <div className="flex gap-4 justify-center">
                <Link href="/browse">
                  <a>
                    <Button className="gradient-gold">
                      Browse Cars
                    </Button>
                  </a>
                </Link>
                <Link href="/chat">
                  <a>
                    <Button variant="outline">
                      Chat with AI
                    </Button>
                  </a>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <Header />

      <div className="container py-8 max-w-4xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Submit a Car Inquiry</h1>
          <p className="text-muted-foreground">Tell us what you're looking for and we'll help you find it</p>
        </div>

        <form onSubmit={handleSubmit}>
          <Card className="glass">
            <CardHeader>
              <CardTitle>Your Information</CardTitle>
              <CardDescription>We'll use this to contact you with matching options</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Contact Information */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Name *</Label>
                  <Input
                    id="name"
                    placeholder="John Doe"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="john@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="+961 XX XXX XXX"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                />
              </div>
            </CardContent>
          </Card>

          <Card className="glass mt-6">
            <CardHeader>
              <CardTitle>Car Preferences</CardTitle>
              <CardDescription>Tell us what you're looking for (all fields optional)</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="brand">Brand</Label>
                  <Input
                    id="brand"
                    placeholder="e.g., Toyota"
                    value={formData.brand}
                    onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="model">Model</Label>
                  <Input
                    id="model"
                    placeholder="e.g., Camry"
                    value={formData.model}
                    onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="carType">Car Type</Label>
                  <Input
                    id="carType"
                    placeholder="e.g., SUV"
                    value={formData.carType}
                    onChange={(e) => setFormData({ ...formData, carType: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="year">Year</Label>
                  <Input
                    id="year"
                    type="number"
                    placeholder="e.g., 2020"
                    value={formData.year || ""}
                    onChange={(e) => setFormData({ ...formData, year: e.target.value ? parseInt(e.target.value) : undefined })}
                  />
                </div>
                <div>
                  <Label htmlFor="color">Color</Label>
                  <Input
                    id="color"
                    placeholder="e.g., Black"
                    value={formData.color}
                    onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="minPrice">Min Budget (USD)</Label>
                  <Input
                    id="minPrice"
                    type="number"
                    placeholder="e.g., 10000"
                    value={formData.minPrice || ""}
                    onChange={(e) => setFormData({ ...formData, minPrice: e.target.value ? parseFloat(e.target.value) : undefined })}
                  />
                </div>
                <div>
                  <Label htmlFor="maxPrice">Max Budget (USD)</Label>
                  <Input
                    id="maxPrice"
                    type="number"
                    placeholder="e.g., 30000"
                    value={formData.maxPrice || ""}
                    onChange={(e) => setFormData({ ...formData, maxPrice: e.target.value ? parseFloat(e.target.value) : undefined })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="additionalNotes">Additional Notes</Label>
                <Textarea
                  id="additionalNotes"
                  placeholder="Tell us more about what you're looking for..."
                  rows={4}
                  value={formData.additionalNotes}
                  onChange={(e) => setFormData({ ...formData, additionalNotes: e.target.value })}
                />
              </div>

              <div className="pt-4">
                <Button 
                  type="submit" 
                  className="w-full gradient-gold text-lg py-6"
                  disabled={createInquiry.isPending}
                >
                  {createInquiry.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      <Send className="mr-2 h-5 w-5" />
                      Submit Inquiry
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </form>
      </div>
    </div>
  );
}
