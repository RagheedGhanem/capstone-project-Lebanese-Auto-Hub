import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Car, Filter, Loader2 } from "lucide-react";
import { Link } from "wouter";
import Header from "@/components/Header";

const SCROLL_KEY = "browse_scroll_y";

// Separate component to handle image loading per car
function CarCard({ car }: { car: any }) {
  const { data: images } = trpc.cars.getImages.useQuery({ carId: car.id });
  const primaryImage = images?.find(img => img.isPrimary) || images?.[0];
  
  return (
    <Card className="card-hover glass overflow-hidden">
      <div className="aspect-video bg-muted flex items-center justify-center overflow-hidden">
        {primaryImage?.imageUrl ? (
          <img 
            src={primaryImage.imageUrl} 
            alt={`${car.brand} ${car.model}`}
            className="w-full h-full object-cover"
          />
        ) : (
          <Car className="h-16 w-16 text-muted-foreground" />
        )}
      </div>
      <CardHeader>
        <CardTitle>{car.brand} {car.model}</CardTitle>
        <CardDescription>
          {car.year} • {car.carType} • {car.color}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {car.kilometers && (
            <p className="text-sm text-muted-foreground">
              {car.kilometers.toLocaleString()} km
            </p>
          )}
          {car.condition && (
            <p className="text-sm">
              <span className="text-muted-foreground">Condition:</span>{" "}
              <span className="capitalize">{car.condition}</span>
            </p>
          )}
          {car.price && (
            <p className="text-2xl font-bold text-primary">
              ${parseFloat(car.price).toLocaleString()}
            </p>
          )}
          {car.description && (
            <p className="text-sm text-muted-foreground line-clamp-2">
              {car.description}
            </p>
          )}
          <Button
            onClick={() => {
              sessionStorage.setItem(SCROLL_KEY, String(window.scrollY));
              window.location.href = `/car/${car.id}`;
            }}
            className="w-full mt-4 gradient-gold"
          >
            View Details
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Browse() {
  // Restore scroll position when returning from car detail
  useEffect(() => {
    const saved = sessionStorage.getItem(SCROLL_KEY);
    if (saved) {
      window.scrollTo({ top: parseInt(saved), behavior: "instant" });
      sessionStorage.removeItem(SCROLL_KEY);
    }
  }, []);

  const [filters, setFilters] = useState({
    brand: "",
    model: "",
    carType: "",
    year: undefined as number | undefined,
    color: "",
    minPrice: undefined as number | undefined,
    maxPrice: undefined as number | undefined,
  });

  const { data: cars, isLoading } = trpc.cars.list.useQuery(filters);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <Header />

      <div className="container py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Browse Cars</h1>
          <p className="text-muted-foreground">Find your perfect vehicle from our extensive inventory</p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <Card className="glass sticky top-24 max-h-[calc(100vh-7rem)] flex flex-col overflow-hidden">
              <CardHeader className="flex-shrink-0">
                <CardTitle className="flex items-center">
                  <Filter className="mr-2 h-5 w-5" />
                  Filters
                </CardTitle>
                <CardDescription>Refine your search</CardDescription>
              </CardHeader>
              <CardContent className="space-y-5 overflow-y-auto flex-1">
                {/* Make & Model Section */}
                <div className="space-y-3 pb-3 border-b border-border">
                  <h3 className="text-sm font-semibold text-foreground">Make & Model</h3>
                  <div>
                    <Label htmlFor="brand" className="text-xs">Make</Label>
                    <Input
                      id="brand"
                      placeholder="e.g., Toyota"
                      value={filters.brand}
                      onChange={(e) => setFilters({ ...filters, brand: e.target.value })}
                      className="text-sm"
                    />
                  </div>
                  <div>
                    <Label htmlFor="model" className="text-xs">Model</Label>
                    <Input
                      id="model"
                      placeholder="e.g., Camry"
                      value={filters.model}
                      onChange={(e) => setFilters({ ...filters, model: e.target.value })}
                      className="text-sm"
                    />
                  </div>
                </div>

                {/* Type Section */}
                <div className="space-y-3 pb-3 border-b border-border">
                  <h3 className="text-sm font-semibold text-foreground">Type</h3>
                  <Select value={filters.carType || "all"} onValueChange={(value) => setFilters({ ...filters, carType: value === "all" ? "" : value })}>
                    <SelectTrigger className="text-sm">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="sedan">Sedan</SelectItem>
                      <SelectItem value="suv">SUV</SelectItem>
                      <SelectItem value="truck">Truck</SelectItem>
                      <SelectItem value="coupe">Coupe</SelectItem>
                      <SelectItem value="hatchback">Hatchback</SelectItem>
                      <SelectItem value="wagon">Wagon</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Year Section */}
                <div className="space-y-3 pb-3 border-b border-border">
                  <h3 className="text-sm font-semibold text-foreground">Year</h3>
                  <Input
                    type="number"
                    placeholder="e.g., 2023"
                    value={filters.year ? String(filters.year) : ""}
                    onChange={(e) => setFilters({ ...filters, year: e.target.value ? parseInt(e.target.value) : undefined })}
                    className="text-sm"
                  />
                </div>

                {/* Color Section */}
                <div className="space-y-3 pb-3 border-b border-border">
                  <h3 className="text-sm font-semibold text-foreground">Color</h3>
                  <Input
                    placeholder="e.g., Black"
                    value={filters.color}
                    onChange={(e) => setFilters({ ...filters, color: e.target.value })}
                    className="text-sm"
                  />
                </div>

                {/* Price Range Section */}
                <div className="space-y-3 pb-3 border-b border-border">
                  <h3 className="text-sm font-semibold text-foreground">Price Range</h3>
                  <div>
                    <Label htmlFor="minPrice" className="text-xs">Min Price ($)</Label>
                    <Input
                      id="minPrice"
                      type="number"
                      placeholder="0"
                      value={filters.minPrice ? String(filters.minPrice) : ""}
                      onChange={(e) => setFilters({ ...filters, minPrice: e.target.value ? parseInt(e.target.value) : undefined })}
                      className="text-sm"
                    />
                  </div>
                  <div>
                    <Label htmlFor="maxPrice" className="text-xs">Max Price ($)</Label>
                    <Input
                      id="maxPrice"
                      type="number"
                      placeholder="999999"
                      value={filters.maxPrice ? String(filters.maxPrice) : ""}
                      onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value ? parseInt(e.target.value) : undefined })}
                      className="text-sm"
                    />
                  </div>
                </div>

                <Button 
                  variant="outline" 
                  className="w-full mt-2"
                  onClick={() => setFilters({
                    brand: "",
                    model: "",
                    carType: "",
                    year: undefined,
                    color: "",
                    minPrice: undefined,
                    maxPrice: undefined,
                  })}
                >
                  Clear All Filters
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Car Listings */}
          <div className="lg:col-span-3">
            {isLoading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : cars && cars.length > 0 ? (
              <div className="grid md:grid-cols-2 gap-6">
                {cars.map((car) => (
                  <CarCard key={car.id} car={car} />
                ))}
              </div>
            ) : (
              <Card className="glass">
                <CardContent className="py-20 text-center">
                  <Car className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No cars found</h3>
                  <p className="text-muted-foreground mb-4">
                    Try adjusting your filters or check back later for new listings
                  </p>
                  <Link href="/chat">
                    <Button className="w-full gradient-gold">
                      Ask AI Assistant
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
