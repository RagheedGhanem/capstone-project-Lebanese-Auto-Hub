import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, ArrowLeft, Trash2 } from "lucide-react";
import { toast } from "sonner";
import Header from "@/components/Header";

export default function AdminListingDetail() {
  const { user, loading } = useAuth({ redirectOnUnauthenticated: true, redirectPath: "/auth" });
  const [, setLocation] = useLocation();
  const [match, params] = useRoute("/admin/listings/:id");
  const carId = params?.id ? parseInt(params.id) : null;

  // Redirect non-admins
  if (!loading && user?.role !== "admin") {
    setLocation("/");
    return null;
  }

  // Fetch listing details
  const { data: car, isLoading, error } = trpc.cars.getById.useQuery(
    { id: carId! },
    { enabled: !!carId }
  );

  const deleteListingMutation = trpc.admin.deleteListing.useMutation();

  const handleDeleteListing = async () => {
    if (!confirm("Are you sure you want to delete this listing? This action cannot be undone.")) {
      return;
    }

    try {
      await deleteListingMutation.mutateAsync({ carId: carId! });
      toast.success("Listing deleted successfully");
      setLocation("/admin/listings");
    } catch (error: any) {
      toast.error(error?.message || "Failed to delete listing");
    }
  };

  if (loading || isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="flex items-center justify-center h-screen">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (error || !car) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto py-8 px-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/admin/listings")}
            className="mb-6 gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Listings
          </Button>
          
          <Card className="border-destructive">
            <CardHeader>
              <CardTitle>Listing Not Found</CardTitle>
              <CardDescription>
                The listing you're looking for doesn't exist or has been deleted.
              </CardDescription>
            </CardHeader>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto py-8 px-4">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={() => setLocation("/admin/listings")}
          className="mb-6 gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Listings
        </Button>

        {/* Listing Details */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Title and Status */}
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-3xl mb-2">
                      {car.brand} {car.model}
                    </CardTitle>
                    <CardDescription className="text-base">
                      {car.year} • {car.carType}
                    </CardDescription>
                  </div>
                  <Badge variant="outline">{car.carType}</Badge>
                </div>
              </CardHeader>
            </Card>

            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Price</p>
                    <p className="text-lg font-semibold">${car.price?.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Year</p>
                    <p className="text-lg font-semibold">{car.year}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Kilometers</p>
                    <p className="text-lg font-semibold">{car.kilometers?.toLocaleString()} km</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Transmission</p>
                    <p className="text-lg font-semibold">{car.transmission}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Fuel Type</p>
                    <p className="text-lg font-semibold">{car.fuelType}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Engine Size</p>
                    <p className="text-lg font-semibold">{car.engineSize} cc</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Description */}
            {car.description && (
              <Card>
                <CardHeader>
                  <CardTitle>Description</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground whitespace-pre-wrap">{car.description}</p>
                </CardContent>
              </Card>
            )}

            {/* Seller Information */}
            <Card>
              <CardHeader>
                <CardTitle>Seller Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm text-muted-foreground">Name</p>
                  <p className="font-medium">{car.sellerName || "N/A"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p className="font-medium">{car.sellerEmail || "N/A"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Phone</p>
                  <p className="font-medium">{car.sellerPhone || "N/A"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Location</p>
                  <p className="font-medium">{car.sellerLocation || "N/A"}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
<Button
                  variant="destructive"
                  className="w-full gap-2"
                  onClick={handleDeleteListing}
                  disabled={deleteListingMutation.isPending}
                >
                  {deleteListingMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Trash2 className="w-4 h-4" />
                  )}
                  Delete Listing
                </Button>
              </CardContent>
            </Card>

            {/* Listing Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Listing Info</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div>
                  <p className="text-muted-foreground">Listing ID</p>
                  <p className="font-mono font-medium">{car.id}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Created</p>
                  <p>{new Date(car.createdAt).toLocaleDateString()}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Updated</p>
                  <p>{new Date(car.updatedAt).toLocaleDateString()}</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
