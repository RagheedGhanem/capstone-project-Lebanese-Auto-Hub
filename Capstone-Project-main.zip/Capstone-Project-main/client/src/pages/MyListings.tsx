import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Edit2, Trash2, AlertCircle, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";

export default function MyListings() {
  const [, setLocation] = useLocation();
  const [editingCar, setEditingCar] = useState<any>(null);
  const [deletingCarId, setDeletingCarId] = useState<number | null>(null);
  const [editFormData, setEditFormData] = useState<any>({});

  // Fetch user's listings
  const { data: listings, isLoading, refetch } = trpc.listings.getMyListings.useQuery();

  // Update listing mutation
  const updateMutation = trpc.listings.updateListing.useMutation({
    onSuccess: () => {
      toast.success("Listing updated successfully!");
      setEditingCar(null);
      refetch();
    },
    onError: (error: any) => {
      toast.error(error.message || "Failed to update listing");
    },
  });

  // Delete listing mutation
  const deleteMutation = trpc.listings.deleteListing.useMutation({
    onSuccess: () => {
      toast.success("Listing deleted successfully!");
      setDeletingCarId(null);
      refetch();
    },
    onError: (error: any) => {
      toast.error(error.message || "Failed to delete listing");
    },
  });

  const handleEditClick = (car: any) => {
    setEditingCar(car);
    setEditFormData(car);
  };

  const handleEditChange = (field: string, value: any) => {
    setEditFormData({ ...editFormData, [field]: value });
  };

  const handleSaveEdit = async () => {
    if (!editingCar) return;
    
    const updates = {
      brand: editFormData.brand,
      model: editFormData.model,
      carType: editFormData.carType,
      year: editFormData.year,
      color: editFormData.color,
      price: editFormData.price,
      description: editFormData.description,
      transmission: editFormData.transmission,
      fuelType: editFormData.fuelType,
      engineSize: editFormData.engineSize,
      sellerName: editFormData.sellerName,
      sellerPhone: editFormData.sellerPhone,
      sellerEmail: editFormData.sellerEmail,
      sellerLocation: editFormData.sellerLocation,
    };

    await updateMutation.mutateAsync({
      carId: editingCar.id,
      updates,
    });
  };

  const handleDeleteConfirm = async () => {
    if (!deletingCarId) return;
    await deleteMutation.mutateAsync({ carId: deletingCarId });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-2 text-primary hover:text-primary/80 transition mb-4"
          >
            <ArrowLeft size={18} />
            <span>Back to Home</span>
          </button>
          <h1 className="text-4xl font-bold mb-2">My Listings</h1>
          <p className="text-muted-foreground">Manage your car listings</p>
        </div>

        {!listings || listings.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-lg font-semibold mb-2">No listings yet</p>
              <p className="text-muted-foreground mb-6">Start by creating your first car listing</p>
              <Button onClick={() => setLocation("/sell")} className="gradient-gold">
                Create Listing
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {listings.map((car: any) => (
              <Card key={car.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <CardTitle className="text-xl">
                    {car.year} {car.brand} {car.model}
                  </CardTitle>
                  <CardDescription>{car.carType}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="text-muted-foreground">Color:</span>
                      <p className="font-semibold">{car.color}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Price:</span>
                      <p className="font-semibold">${car.price}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Transmission:</span>
                      <p className="font-semibold">{car.transmission || "N/A"}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Fuel:</span>
                      <p className="font-semibold">{car.fuelType || "N/A"}</p>
                    </div>
                  </div>

                  <div className="pt-3 border-t flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => handleEditClick(car)}
                    >
                      <Edit2 className="h-4 w-4 mr-2" />
                      Edit
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      className="flex-1"
                      onClick={() => setDeletingCarId(car.id)}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={!!editingCar} onOpenChange={(open) => !open && setEditingCar(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Listing</DialogTitle>
            <DialogDescription>Update your car listing details</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="brand">Brand</Label>
                <Input
                  id="brand"
                  value={editFormData.brand || ""}
                  onChange={(e) => handleEditChange("brand", e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="model">Model</Label>
                <Input
                  id="model"
                  value={editFormData.model || ""}
                  onChange={(e) => handleEditChange("model", e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="year">Year</Label>
                <Input
                  id="year"
                  type="number"
                  value={editFormData.year || ""}
                  onChange={(e) => handleEditChange("year", parseInt(e.target.value))}
                />
              </div>
              <div>
                <Label htmlFor="color">Color</Label>
                <Input
                  id="color"
                  value={editFormData.color || ""}
                  onChange={(e) => handleEditChange("color", e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="price">Price</Label>
                <Input
                  id="price"
                  type="number"
                  value={editFormData.price || ""}
                  onChange={(e) => handleEditChange("price", e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="transmission">Transmission</Label>
                <Input
                  id="transmission"
                  value={editFormData.transmission || ""}
                  onChange={(e) => handleEditChange("transmission", e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="fuelType">Fuel Type</Label>
                <Input
                  id="fuelType"
                  value={editFormData.fuelType || ""}
                  onChange={(e) => handleEditChange("fuelType", e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="engineSize">Engine Size</Label>
                <Input
                  id="engineSize"
                  value={editFormData.engineSize || ""}
                  onChange={(e) => handleEditChange("engineSize", e.target.value)}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={editFormData.description || ""}
                onChange={(e) => handleEditChange("description", e.target.value)}
                rows={4}
              />
            </div>



            <div className="border-t pt-4">
              <h3 className="font-semibold mb-3">Seller Information</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="sellerName">Name</Label>
                  <Input
                    id="sellerName"
                    value={editFormData.sellerName || ""}
                    onChange={(e) => handleEditChange("sellerName", e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sellerPhone">Phone</Label>
                  <Input
                    id="sellerPhone"
                    value={editFormData.sellerPhone || ""}
                    onChange={(e) => handleEditChange("sellerPhone", e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sellerEmail">Email</Label>
                  <Input
                    id="sellerEmail"
                    type="email"
                    value={editFormData.sellerEmail || ""}
                    onChange={(e) => handleEditChange("sellerEmail", e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sellerLocation">Location</Label>
                  <Input
                    id="sellerLocation"
                    value={editFormData.sellerLocation || ""}
                    onChange={(e) => handleEditChange("sellerLocation", e.target.value)}
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                variant="outline"
                onClick={() => setEditingCar(null)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSaveEdit}
                disabled={updateMutation.isPending}
                className="flex-1 gradient-gold"
              >
                {updateMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  "Save Changes"
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!deletingCarId} onOpenChange={(open) => !open && setDeletingCarId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Listing</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this listing? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>

          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => setDeletingCarId(null)}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleDeleteConfirm}
              disabled={deleteMutation.isPending}
              className="flex-1"
            >
              {deleteMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
