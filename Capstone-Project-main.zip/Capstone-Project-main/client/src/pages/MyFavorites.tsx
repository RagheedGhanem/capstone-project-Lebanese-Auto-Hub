import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Heart, AlertCircle, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";

export default function MyFavorites() {
  const [, setLocation] = useLocation();

  // Fetch user's favorites
  const { data: favorites, isLoading, refetch } = trpc.favorites.getMyFavorites.useQuery();

  // Remove favorite mutation
  const removeMutation = trpc.favorites.remove.useMutation({
    onSuccess: () => {
      toast.success("Removed from favorites");
      refetch();
    },
    onError: (error: any) => {
      toast.error(error.message || "Failed to remove from favorites");
    },
  });

  const handleRemoveFavorite = async (carId: number) => {
    await removeMutation.mutateAsync({ carId });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-2 text-primary hover:text-primary/80 transition mb-4"
          >
            <ArrowLeft size={18} />
            <span>Back to Home</span>
          </button>
          <h1 className="text-4xl font-bold mb-2">My Favorites</h1>
          <p className="text-muted-foreground">Your saved car listings</p>
        </div>

        {!favorites || favorites.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-lg font-semibold mb-2">No favorites yet</p>
              <p className="text-muted-foreground mb-6">Start by adding cars to your favorites</p>
              <Button onClick={() => setLocation("/browse")} className="gradient-gold">
                Browse Cars
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {favorites.map((car: any) => (
              <Card key={car.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <CardTitle className="text-xl">
                    {car.year} {car.brand} {car.model}
                  </CardTitle>
                  <CardDescription>{car.carType}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="text-muted-foreground">Color:</span>
                      <p className="font-semibold">{car.color}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Price:</span>
                      <p className="font-semibold">${car.price}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Transmission:</span>
                      <p className="font-semibold">{car.transmission || "N/A"}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Fuel:</span>
                      <p className="font-semibold">{car.fuelType || "N/A"}</p>
                    </div>
                  </div>

                  {car.sellerName && (
                    <div className="border-t pt-3">
                      <p className="text-sm text-muted-foreground">Seller</p>
                      <p className="font-semibold">{car.sellerName}</p>
                      {car.sellerPhone && <p className="text-sm">{car.sellerPhone}</p>}
                    </div>
                  )}

                  <div className="pt-3 border-t flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => setLocation(`/car/${car.id}`)}
                    >
                      View Details
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="flex-1"
                      onClick={() => handleRemoveFavorite(car.id)}
                      disabled={removeMutation.isPending}
                    >
                      <Heart className="h-4 w-4 mr-2 fill-red-500 text-red-500" />
                      Remove
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
