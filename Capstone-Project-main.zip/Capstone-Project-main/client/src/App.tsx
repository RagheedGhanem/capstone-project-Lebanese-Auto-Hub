import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { AuthProvider } from "./contexts/AuthContext";
import Home from "./pages/Home";
import Browse from "./pages/Browse";
import SellCar from "./pages/SellCar";
import ChatAssistant from "./pages/ChatAssistant";
import Valuation from "./pages/Valuation";
import Dealers from "./pages/Dealers";
import Inquiry from "./pages/Inquiry";
import Auth from "./pages/Auth";
import Profile from "./pages/Profile";
import CarDetail from "./pages/CarDetail";
import MyListings from "./pages/MyListings";
import MyFavorites from "./pages/MyFavorites";
import SellerInquiries from "./pages/SellerInquiries";
import AdminDashboard from "./pages/AdminDashboard";
import AdminUsers from "./pages/AdminUsers";
import AdminListings from "./pages/AdminListings";
import AdminListingDetail from "./pages/AdminListingDetail";
import ProtectedRoute from "./components/ProtectedRoute";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/browse" component={Browse} />
      <Route path="/dealers" component={Dealers} />
      <Route path="/car/:id" component={CarDetail} />
      <Route path="/auth" component={Auth} />
      <Route path="/profile">
        {() => (
          <ProtectedRoute>
            <Profile />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/change-password">
        {() => (
          <ProtectedRoute>
            <Profile />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/my-listings">
        {() => (
          <ProtectedRoute>
            <MyListings />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/my-favorites">
        {() => (
          <ProtectedRoute>
            <MyFavorites />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/seller-inquiries">
        {() => (
          <ProtectedRoute>
            <SellerInquiries />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin">
        {() => (
          <ProtectedRoute>
            <AdminDashboard />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/users">
        {() => (
          <ProtectedRoute>
            <AdminUsers />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/listings">
        {() => (
          <ProtectedRoute>
            <AdminListings />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/listings/:id">
        {() => (
          <ProtectedRoute>
            <AdminListingDetail />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/sell">
        {() => (
          <ProtectedRoute>
            <SellCar />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/chat">
        {() => (
          <ProtectedRoute>
            <ChatAssistant />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/valuation">
        {() => (
          <ProtectedRoute>
            <Valuation />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/inquiry">
        {() => (
          <ProtectedRoute>
            <Inquiry />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="{/404}" component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <AuthProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </AuthProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
