ALTER TABLE `inquiries` ADD `carId` int;--> statement-breakpoint
ALTER TABLE `inquiries` ADD `sellerEmail` varchar(320);