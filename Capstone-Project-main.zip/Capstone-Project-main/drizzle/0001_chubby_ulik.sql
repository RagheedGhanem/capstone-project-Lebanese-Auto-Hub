CREATE TABLE `carImages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`carId` int NOT NULL,
	`imageUrl` varchar(500) NOT NULL,
	`imageKey` varchar(500) NOT NULL,
	`isPrimary` boolean NOT NULL DEFAULT false,
	`order` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `carImages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cars` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`dealerId` int,
	`brand` varchar(100) NOT NULL,
	`model` varchar(100) NOT NULL,
	`carType` varchar(50) NOT NULL,
	`year` int NOT NULL,
	`color` varchar(50) NOT NULL,
	`kilometers` int,
	`condition` enum('new','excellent','good','fair','poor'),
	`price` decimal(12,2),
	`currency` varchar(10) NOT NULL DEFAULT 'USD',
	`description` text,
	`transmission` varchar(50),
	`fuelType` varchar(50),
	`engineSize` varchar(50),
	`features` text,
	`status` enum('available','sold','pending','reserved') NOT NULL DEFAULT 'available',
	`isExternal` boolean NOT NULL DEFAULT false,
	`externalId` varchar(255),
	`externalUrl` varchar(500),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cars_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `chatConversations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`sessionId` varchar(255) NOT NULL,
	`status` enum('active','completed') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `chatConversations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `chatMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`conversationId` int NOT NULL,
	`role` enum('user','assistant') NOT NULL,
	`content` text NOT NULL,
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chatMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `dealers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`address` text,
	`city` varchar(100),
	`latitude` decimal(10,7),
	`longitude` decimal(10,7),
	`phone` varchar(50),
	`email` varchar(320),
	`website` varchar(500),
	`apiEndpoint` varchar(500),
	`apiKey` varchar(255),
	`logoUrl` varchar(500),
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dealers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `inquiries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`name` varchar(255),
	`email` varchar(320),
	`phone` varchar(50),
	`brand` varchar(100),
	`model` varchar(100),
	`carType` varchar(50),
	`year` int,
	`color` varchar(50),
	`minPrice` decimal(12,2),
	`maxPrice` decimal(12,2),
	`additionalNotes` text,
	`status` enum('new','contacted','completed','cancelled') NOT NULL DEFAULT 'new',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `inquiries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tradeInRecommendations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`valuationId` int NOT NULL,
	`recommendedCarId` int NOT NULL,
	`matchScore` decimal(5,2),
	`reasoning` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `tradeInRecommendations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `valuations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`carId` int,
	`brand` varchar(100) NOT NULL,
	`model` varchar(100) NOT NULL,
	`year` int NOT NULL,
	`kilometers` int NOT NULL,
	`condition` varchar(50) NOT NULL,
	`estimatedValue` decimal(12,2) NOT NULL,
	`currency` varchar(10) NOT NULL DEFAULT 'USD',
	`valuationDetails` text,
	`imageAnalysis` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `valuations_id` PRIMARY KEY(`id`)
);
