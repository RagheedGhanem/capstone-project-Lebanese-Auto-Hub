ALTER TABLE `cars` ADD `sellerName` varchar(255);--> statement-breakpoint
ALTER TABLE `cars` ADD `sellerPhone` varchar(50);--> statement-breakpoint
ALTER TABLE `cars` ADD `sellerEmail` varchar(320);--> statement-breakpoint
ALTER TABLE `cars` ADD `sellerLocation` varchar(255);