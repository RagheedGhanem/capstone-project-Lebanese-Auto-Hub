import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }).unique(),
  passwordHash: varchar("passwordHash", { length: 255 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type UserWithoutPassword = Omit<User, "passwordHash">;

/**
 * Car dealerships in Lebanon
 */
export const dealers = mysqlTable("dealers", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  address: text("address"),
  city: varchar("city", { length: 100 }),
  latitude: decimal("latitude", { precision: 10, scale: 7 }),
  longitude: decimal("longitude", { precision: 10, scale: 7 }),
  phone: varchar("phone", { length: 50 }),
  email: varchar("email", { length: 320 }),
  website: varchar("website", { length: 500 }),
  apiEndpoint: varchar("apiEndpoint", { length: 500 }),
  apiKey: varchar("apiKey", { length: 255 }),
  logoUrl: varchar("logoUrl", { length: 500 }),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Dealer = typeof dealers.$inferSelect;
export type InsertDealer = typeof dealers.$inferInsert;

/**
 * Cars listed for sale (both user listings and dealer inventory)
 */
export const cars = mysqlTable("cars", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  dealerId: int("dealerId"),
  brand: varchar("brand", { length: 100 }).notNull(),
  model: varchar("model", { length: 100 }).notNull(),
  carType: varchar("carType", { length: 50 }).notNull(),
  year: int("year").notNull(),
  color: varchar("color", { length: 50 }).notNull(),
  kilometers: int("kilometers"),
  condition: mysqlEnum("condition", ["new", "excellent", "good", "fair", "poor"]),
  price: decimal("price", { precision: 12, scale: 2 }),
  currency: varchar("currency", { length: 10 }).default("USD").notNull(),
  description: text("description"),
  transmission: varchar("transmission", { length: 50 }),
  fuelType: varchar("fuelType", { length: 50 }),
  engineSize: varchar("engineSize", { length: 50 }),
  features: text("features"),
  sellerName: varchar("sellerName", { length: 255 }),
  sellerPhone: varchar("sellerPhone", { length: 50 }),
  sellerEmail: varchar("sellerEmail", { length: 320 }),
  sellerLocation: varchar("sellerLocation", { length: 255 }),
  status: mysqlEnum("status", ["available", "sold", "pending", "reserved"]).default("available").notNull(),
  isExternal: boolean("isExternal").default(false).notNull(),
  externalId: varchar("externalId", { length: 255 }),
  externalUrl: varchar("externalUrl", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Car = typeof cars.$inferSelect;
export type InsertCar = typeof cars.$inferInsert;

/**
 * Car images
 */
export const carImages = mysqlTable("carImages", {
  id: int("id").autoincrement().primaryKey(),
  carId: int("carId").notNull(),
  imageUrl: varchar("imageUrl", { length: 500 }).notNull(),
  imageKey: varchar("imageKey", { length: 500 }).notNull(),
  isPrimary: boolean("isPrimary").default(false).notNull(),
  order: int("order").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CarImage = typeof carImages.$inferSelect;
export type InsertCarImage = typeof carImages.$inferInsert;

/**
 * Car buying inquiries from users
 */
export const inquiries = mysqlTable("inquiries", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  carId: int("carId"),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 50 }),
  brand: varchar("brand", { length: 100 }),
  model: varchar("model", { length: 100 }),
  carType: varchar("carType", { length: 50 }),
  year: int("year"),
  color: varchar("color", { length: 50 }),
  minPrice: decimal("minPrice", { precision: 12, scale: 2 }),
  maxPrice: decimal("maxPrice", { precision: 12, scale: 2 }),
  additionalNotes: text("additionalNotes"),
  sellerEmail: varchar("sellerEmail", { length: 320 }),
  status: mysqlEnum("status", ["new", "contacted", "completed", "cancelled"]).default("new").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Inquiry = typeof inquiries.$inferSelect;
export type InsertInquiry = typeof inquiries.$inferInsert;

/**
 * AI car valuations
 */
export const valuations = mysqlTable("valuations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  carId: int("carId"),
  brand: varchar("brand", { length: 100 }).notNull(),
  model: varchar("model", { length: 100 }).notNull(),
  year: int("year").notNull(),
  kilometers: int("kilometers").notNull(),
  condition: varchar("condition", { length: 50 }).notNull(),
  estimatedValue: decimal("estimatedValue", { precision: 12, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 10 }).default("USD").notNull(),
  valuationDetails: text("valuationDetails"),
  imageAnalysis: text("imageAnalysis"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Valuation = typeof valuations.$inferSelect;
export type InsertValuation = typeof valuations.$inferInsert;

/**
 * Trade-in recommendations
 */
export const tradeInRecommendations = mysqlTable("tradeInRecommendations", {
  id: int("id").autoincrement().primaryKey(),
  valuationId: int("valuationId").notNull(),
  recommendedCarId: int("recommendedCarId").notNull(),
  matchScore: decimal("matchScore", { precision: 5, scale: 2 }),
  reasoning: text("reasoning"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TradeInRecommendation = typeof tradeInRecommendations.$inferSelect;
export type InsertTradeInRecommendation = typeof tradeInRecommendations.$inferInsert;

/**
 * AI chatbot conversations
 */
export const chatConversations = mysqlTable("chatConversations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  sessionId: varchar("sessionId", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["active", "completed"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ChatConversation = typeof chatConversations.$inferSelect;
export type InsertChatConversation = typeof chatConversations.$inferInsert;

/**
 * User favorites (saved cars)
 */
export const favorites = mysqlTable("favorites", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  carId: int("carId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Favorite = typeof favorites.$inferSelect;
export type InsertFavorite = typeof favorites.$inferInsert;

/**
 * Chat messages
 */
export const chatMessages = mysqlTable("chatMessages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  content: text("content").notNull(),
  metadata: text("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = typeof chatMessages.$inferInsert;
