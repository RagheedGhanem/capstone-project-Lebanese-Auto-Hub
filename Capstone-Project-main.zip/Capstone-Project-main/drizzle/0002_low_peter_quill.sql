ALTER TABLE `users` MODIFY COLUMN `openId` varchar(64);
